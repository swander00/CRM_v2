import React, { useState } from 'react';
import { Calendar as BigCalendar, dateFnsLocalizer } from 'react-big-calendar';
import format from 'date-fns/format';
import parse from 'date-fns/parse';
import startOfWeek from 'date-fns/startOfWeek';
import getDay from 'date-fns/getDay';
import enUS from 'date-fns/locale/en-US';
import { Plus, Calendar as CalendarIcon, X, Check } from 'lucide-react';
import CalendarSyncModal from '../components/calendar/CalendarSyncModal';
import CalendarSidebar from '../components/calendar/CalendarSidebar';
import 'react-big-calendar/lib/css/react-big-calendar.css';

const locales = {
  'en-US': enUS
};

const localizer = dateFnsLocalizer({
  format,
  parse,
  startOfWeek,
  getDay,
  locales,
});

const mockEvents = [
  {
    id: 1,
    title: 'Property Viewing - 123 Main St',
    start: new Date(2024, 2, 15, 10, 0),
    end: new Date(2024, 2, 15, 11, 0),
    type: 'viewing',
    client: 'John Smith'
  },
  {
    id: 2,
    title: 'Client Meeting - Emma Davis',
    start: new Date(2024, 2, 16, 14, 0),
    end: new Date(2024, 2, 16, 15, 0),
    type: 'meeting',
    client: 'Emma Davis'
  }
];

export default function Calendar() {
  const [events, setEvents] = useState(mockEvents);
  const [showSyncModal, setShowSyncModal] = useState(false);
  const [selectedCalendars, setSelectedCalendars] = useState<string[]>([]);
  const [view, setView] = useState('month');

  const handleSelectEvent = (event: any) => {
    console.log('Selected event:', event);
  };

  const handleSelectSlot = (slotInfo: any) => {
    console.log('Selected slot:', slotInfo);
  };

  const eventStyleGetter = (event: any) => {
    let backgroundColor = '#1563df';
    let borderColor = '#0c4da3';

    switch (event.type) {
      case 'viewing':
        backgroundColor = '#10B981';
        borderColor = '#059669';
        break;
      case 'meeting':
        backgroundColor = '#6366F1';
        borderColor = '#4F46E5';
        break;
      case 'task':
        backgroundColor = '#F59E0B';
        borderColor = '#D97706';
        break;
    }

    return {
      style: {
        backgroundColor,
        borderColor,
        borderRadius: '4px',
        opacity: 0.8,
        color: 'white',
        border: 'none',
        display: 'block'
      }
    };
  };

  return (
    <div className="min-h-screen bg-dark-900">
      <div className="flex h-[calc(100vh-theme(spacing.16))]">
        <CalendarSidebar
          selectedCalendars={selectedCalendars}
          onCalendarToggle={(calendar) => {
            setSelectedCalendars(prev =>
              prev.includes(calendar)
                ? prev.filter(c => c !== calendar)
                : [...prev, calendar]
            );
          }}
          onSyncClick={() => setShowSyncModal(true)}
        />

        <div className="flex-1 p-6">
          {/* Header */}
          <div className="flex items-center justify-between mb-6">
            <h1 className="text-2xl font-bold text-gray-100">Calendar</h1>
            <div className="flex items-center gap-3">
              <select
                value={view}
                onChange={(e) => setView(e.target.value)}
                className="bg-dark-800 border border-dark-700 rounded-lg px-3 py-2 text-gray-200"
              >
                <option value="month">Month</option>
                <option value="week">Week</option>
                <option value="day">Day</option>
                <option value="agenda">Agenda</option>
              </select>
              <button className="btn-primary flex items-center gap-2">
                <Plus className="w-4 h-4" />
                Add Event
              </button>
            </div>
          </div>

          {/* Calendar */}
          <div className="bg-dark-800 rounded-lg border border-dark-700 p-6">
            <BigCalendar
              localizer={localizer}
              events={events}
              startAccessor="start"
              endAccessor="end"
              style={{ height: 'calc(100vh - 240px)' }}
              onSelectEvent={handleSelectEvent}
              onSelectSlot={handleSelectSlot}
              selectable
              eventPropGetter={eventStyleGetter}
              view={view as any}
              onView={(view) => setView(view)}
              className="custom-calendar"
            />
          </div>
        </div>
      </div>

      {/* Calendar Sync Modal */}
      {showSyncModal && (
        <CalendarSyncModal onClose={() => setShowSyncModal(false)} />
      )}
    </div>
  );
}