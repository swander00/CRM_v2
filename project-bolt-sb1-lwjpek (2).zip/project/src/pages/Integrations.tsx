import React from 'react';
import { 
  Link2, 
  Mail, 
  MessageSquare, 
  Video, 
  Facebook, 
  FolderOpen,
  Cloud,
  Check,
  AlertCircle,
  Settings,
  ExternalLink,
  MessageCircle
} from 'lucide-react';

const integrations = [
  {
    id: 'zapier',
    name: 'Zapier',
    description: 'Automate workflows between your favorite apps',
    icon: '/zapier.svg',
    status: 'connected',
    lastSync: '2 hours ago'
  },
  {
    id: 'mailchimp',
    name: 'MailChimp',
    description: 'Email marketing and automation platform',
    icon: '/mailchimp.svg',
    status: 'connected',
    lastSync: '1 day ago'
  },
  {
    id: 'facebook',
    name: 'Facebook',
    description: 'Social media marketing and lead generation',
    icon: Facebook,
    status: 'disconnected'
  },
  {
    id: 'twilio',
    name: 'Twilio',
    description: 'SMS and voice communication platform',
    icon: MessageSquare,
    status: 'connected',
    lastSync: '30 minutes ago'
  },
  {
    id: 'whatsapp',
    name: 'WhatsApp Business',
    description: 'Business messaging and customer communication',
    icon: MessageCircle,
    status: 'disconnected'
  },
  {
    id: 'bombbomb',
    name: 'BombBomb',
    description: 'Video email and messaging platform',
    icon: Video,
    status: 'disconnected'
  },
  {
    id: 'dropbox',
    name: 'Dropbox',
    description: 'Cloud storage and file sharing',
    icon: FolderOpen,
    status: 'connected',
    lastSync: '1 hour ago'
  },
  {
    id: 'google-drive',
    name: 'Google Drive',
    description: 'Cloud storage and collaboration',
    icon: Cloud,
    status: 'connected',
    lastSync: '45 minutes ago'
  }
];

export default function Integrations() {
  return (
    <div className="min-h-screen bg-dark-900 p-6">
      <div className="max-w-[1600px] mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold text-gray-100">Integrations</h1>
            <p className="text-gray-400 mt-1">Connect and manage your third-party integrations</p>
          </div>
          <button className="btn-primary flex items-center gap-2">
            <Link2 className="w-4 h-4" />
            Add Integration
          </button>
        </div>

        {/* Integration Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {integrations.map((integration) => {
            const Icon = integration.icon;
            return (
              <div key={integration.id} className="bg-dark-800 rounded-lg border border-dark-700 p-6 hover:border-dark-600 transition-colors">
                <div className="flex items-start justify-between mb-6">
                  <div className="flex items-center gap-3">
                    {typeof Icon === 'string' ? (
                      <img src={Icon} alt={integration.name} className="w-10 h-10" />
                    ) : (
                      <div className="w-10 h-10 rounded-lg bg-primary-500/10 flex items-center justify-center">
                        <Icon className="w-6 h-6 text-primary-400" />
                      </div>
                    )}
                    <div>
                      <h3 className="font-medium text-gray-200">{integration.name}</h3>
                      <p className="text-sm text-gray-400">{integration.description}</p>
                    </div>
                  </div>
                  {integration.status === 'connected' ? (
                    <span className="flex items-center gap-1 text-green-400 text-sm">
                      <Check className="w-4 h-4" />
                      Connected
                    </span>
                  ) : (
                    <span className="flex items-center gap-1 text-gray-400 text-sm">
                      <AlertCircle className="w-4 h-4" />
                      Not Connected
                    </span>
                  )}
                </div>

                {integration.status === 'connected' && (
                  <div className="flex items-center justify-between text-sm text-gray-400 mb-4">
                    <span>Last synced: {integration.lastSync}</span>
                    <button className="text-primary-400 hover:text-primary-300">
                      Sync Now
                    </button>
                  </div>
                )}

                <div className="flex items-center gap-2">
                  {integration.status === 'connected' ? (
                    <>
                      <button className="flex-1 btn-secondary flex items-center justify-center gap-2">
                        <Settings className="w-4 h-4" />
                        Configure
                      </button>
                      <button className="flex-1 btn-secondary flex items-center justify-center gap-2 text-red-400 hover:text-red-300">
                        Disconnect
                      </button>
                    </>
                  ) : (
                    <button className="w-full btn-primary flex items-center justify-center gap-2">
                      <Link2 className="w-4 h-4" />
                      Connect
                    </button>
                  )}
                </div>

                <a 
                  href="#" 
                  className="mt-4 flex items-center gap-1 text-sm text-gray-400 hover:text-gray-300"
                >
                  Learn More
                  <ExternalLink className="w-4 h-4" />
                </a>
              </div>
            );
          })}
        </div>

        {/* Documentation Section */}
        <div className="mt-8 bg-dark-800 rounded-lg border border-dark-700 p-6">
          <h2 className="text-lg font-semibold text-gray-100 mb-4">Integration Documentation</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <a href="#" className="p-4 bg-dark-700/50 rounded-lg hover:bg-dark-700 transition-colors">
              <h3 className="font-medium text-gray-200 mb-2">Getting Started</h3>
              <p className="text-sm text-gray-400">Learn how to set up and configure integrations</p>
            </a>
            <a href="#" className="p-4 bg-dark-700/50 rounded-lg hover:bg-dark-700 transition-colors">
              <h3 className="font-medium text-gray-200 mb-2">API Documentation</h3>
              <p className="text-sm text-gray-400">Explore our API endpoints and documentation</p>
            </a>
            <a href="#" className="p-4 bg-dark-700/50 rounded-lg hover:bg-dark-700 transition-colors">
              <h3 className="font-medium text-gray-200 mb-2">Troubleshooting</h3>
              <p className="text-sm text-gray-400">Find solutions to common integration issues</p>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}