import React from 'react';
import Header from '../components/Header';
import SearchFilters from '../components/SearchFilters';
import LeadStats from '../components/LeadStats';
import LeadTable from '../components/LeadTable';
import FloatingActions from '../components/FloatingActions';
import { LeadProvider } from '../contexts/LeadContext';

export default function LeadManagement() {
  return (
    <LeadProvider>
      <Header />
      <main className="max-w-[1600px] mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <SearchFilters />
        <LeadStats />
        <LeadTable />
        <FloatingActions />
      </main>
    </LeadProvider>
  );
}