import React from 'react';
import TaskHeader from '../components/tasks/TaskHeader';
import TaskStats from '../components/tasks/TaskStats';
import TaskBoard from '../components/tasks/TaskBoard';

export default function Tasks() {
  return (
    <div className="h-screen flex flex-col">
      <TaskHeader />
      <div className="flex-1 overflow-hidden p-6">
        <TaskStats />
        <TaskBoard />
      </div>
    </div>
  );
}