import React from 'react';
import { 
  User, 
  Building, 
  Bell, 
  Lock,
  Mail,
  MessageSquare,
  Globe,
  Palette,
  Database,
  CreditCard,
  Users,
  Sliders
} from 'lucide-react';
import ProfileSettings from '../components/settings/ProfileSettings';
import CompanySettings from '../components/settings/CompanySettings';
import NotificationSettings from '../components/settings/NotificationSettings';
import SecuritySettings from '../components/settings/SecuritySettings';
import EmailSettings from '../components/settings/EmailSettings';
import SMSSettings from '../components/settings/SMSSettings';
import IntegrationSettings from '../components/settings/IntegrationSettings';
import AppearanceSettings from '../components/settings/AppearanceSettings';
import DataSettings from '../components/settings/DataSettings';
import BillingSettings from '../components/settings/BillingSettings';
import TeamSettings from '../components/settings/TeamSettings';
import SystemSettings from '../components/settings/SystemSettings';

const settingsSections = [
  { id: 'profile', icon: User, label: 'Profile', component: ProfileSettings },
  { id: 'company', icon: Building, label: 'Company', component: CompanySettings },
  { id: 'notifications', icon: Bell, label: 'Notifications', component: NotificationSettings },
  { id: 'security', icon: Lock, label: 'Security', component: SecuritySettings },
  { id: 'email', icon: Mail, label: 'Email', component: EmailSettings },
  { id: 'sms', icon: MessageSquare, label: 'SMS', component: SMSSettings },
  { id: 'integrations', icon: Globe, label: 'Integrations', component: IntegrationSettings },
  { id: 'appearance', icon: Palette, label: 'Appearance', component: AppearanceSettings },
  { id: 'data', icon: Database, label: 'Data Management', component: DataSettings },
  { id: 'billing', icon: CreditCard, label: 'Billing', component: BillingSettings },
  { id: 'team', icon: Users, label: 'Team', component: TeamSettings },
  { id: 'system', icon: Sliders, label: 'System', component: SystemSettings }
];

export default function Settings() {
  const [activeSection, setActiveSection] = React.useState('profile');

  const ActiveComponent = settingsSections.find(section => section.id === activeSection)?.component;

  return (
    <div className="min-h-screen bg-dark-900 p-6">
      <div className="max-w-[1600px] mx-auto">
        <h1 className="text-2xl font-bold text-gray-100 mb-6">Settings</h1>

        <div className="flex gap-6">
          {/* Settings Navigation */}
          <div className="w-64 bg-dark-800 rounded-lg border border-dark-700 p-4">
            <nav className="space-y-1">
              {settingsSections.map((section) => (
                <button
                  key={section.id}
                  onClick={() => setActiveSection(section.id)}
                  className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition-colors ${
                    activeSection === section.id
                      ? 'bg-primary-500/10 text-primary-400'
                      : 'text-gray-400 hover:bg-dark-700 hover:text-gray-300'
                  }`}
                >
                  <section.icon className="w-5 h-5" />
                  <span>{section.label}</span>
                </button>
              ))}
            </nav>
          </div>

          {/* Settings Content */}
          <div className="flex-1 bg-dark-800 rounded-lg border border-dark-700 p-6">
            {ActiveComponent && <ActiveComponent />}
          </div>
        </div>
      </div>
    </div>
  );
}