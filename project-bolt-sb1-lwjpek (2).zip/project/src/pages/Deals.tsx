import React, { useState } from 'react';
import { Plus, Search, Filter, ChevronDown, X } from 'lucide-react';
import { DragDropContext, Droppable, Draggable, DropResult } from '@hello-pangea/dnd';
import AddDealModal from '../components/deals/AddDealModal';
import DealDetails from '../components/deals/DealDetails';

const initialStages = [
  { 
    id: 'contract-signed', 
    label: 'Contract Signed',
    color: 'bg-blue-500/10 border-blue-500/20 text-blue-400'
  },
  { 
    id: 'waiting-preapproval', 
    label: 'Waiting for Preapproval',
    color: 'bg-yellow-500/10 border-yellow-500/20 text-yellow-400'
  },
  { 
    id: 'sold-conditional', 
    label: 'Sold Conditional',
    color: 'bg-purple-500/10 border-purple-500/20 text-purple-400'
  },
  { 
    id: 'sold', 
    label: 'Sold',
    color: 'bg-green-500/10 border-green-500/20 text-green-400'
  },
  { 
    id: 'closed', 
    label: 'Closed',
    color: 'bg-indigo-500/10 border-indigo-500/20 text-indigo-400'
  },
  { 
    id: 'commission-paid', 
    label: 'Commission Paid',
    color: 'bg-pink-500/10 border-pink-500/20 text-pink-400'
  }
];

const initialDeals = [
  {
    id: '1',
    title: 'Beverly Hills Mansion',
    client: 'John Smith',
    value: '$2.5M',
    dueDate: '2024-03-01',
    agent: 'Sarah Wilson',
    stage: 'contract-signed',
    type: 'Residential Sale'
  },
  {
    id: '2',
    title: 'Downtown Penthouse',
    client: 'Emma Davis',
    value: '$1.8M',
    dueDate: '2024-03-15',
    agent: 'Mike Johnson',
    stage: 'waiting-preapproval',
    type: 'Luxury Condo'
  },
  {
    id: '3',
    title: 'Beachfront Villa',
    client: 'Robert Brown',
    value: '$3.2M',
    dueDate: '2024-03-10',
    agent: 'David Lee',
    stage: 'sold-conditional',
    type: 'Residential Sale'
  }
];

export default function Deals() {
  const [deals, setDeals] = useState(initialDeals);
  const [stages, setStages] = useState(initialStages);
  const [showAddModal, setShowAddModal] = useState(false);
  const [selectedDeal, setSelectedDeal] = useState<any>(null);
  const [showAddStage, setShowAddStage] = useState(false);
  const [newStageName, setNewStageName] = useState('');

  const handleDragEnd = (result: DropResult) => {
    const { source, destination, type } = result;

    if (!destination) return;

    // Handle stage reordering
    if (type === 'stage') {
      const newStages = Array.from(stages);
      const [removed] = newStages.splice(source.index, 1);
      newStages.splice(destination.index, 0, removed);
      setStages(newStages);
      return;
    }

    // Handle deal movement
    if (source.droppableId !== destination.droppableId) {
      // Moving between stages
      const updatedDeals = deals.map(deal => {
        if (deal.id === result.draggableId) {
          return { ...deal, stage: destination.droppableId };
        }
        return deal;
      });
      setDeals(updatedDeals);
    } else {
      // Reordering within the same stage
      const stageDeals = deals.filter(deal => deal.stage === source.droppableId);
      const otherDeals = deals.filter(deal => deal.stage !== source.droppableId);
      const [removed] = stageDeals.splice(source.index, 1);
      stageDeals.splice(destination.index, 0, removed);
      setDeals([...otherDeals, ...stageDeals]);
    }
  };

  const handleAddDeal = (newDeal: any) => {
    setDeals([...deals, { ...newDeal, stage: 'contract-signed' }]);
  };

  const handleMoveToNextStage = () => {
    if (!selectedDeal) return;

    const currentStageIndex = stages.findIndex(stage => stage.id === selectedDeal.stage);
    if (currentStageIndex < stages.length - 1) {
      const nextStage = stages[currentStageIndex + 1].id;
      setDeals(deals.map(deal => 
        deal.id === selectedDeal.id 
          ? { ...deal, stage: nextStage }
          : deal
      ));
      setSelectedDeal({ ...selectedDeal, stage: nextStage });
    }
  };

  const handleAddStage = () => {
    if (newStageName.trim()) {
      const newStage = {
        id: newStageName.toLowerCase().replace(/\s+/g, '-'),
        label: newStageName.trim(),
        color: 'bg-gray-500/10 border-gray-500/20 text-gray-400'
      };
      setStages([...stages, newStage]);
      setNewStageName('');
      setShowAddStage(false);
    }
  };

  const handleRemoveStage = (stageId: string) => {
    // Move deals in this stage to the first stage
    const updatedDeals = deals.map(deal => 
      deal.stage === stageId 
        ? { ...deal, stage: stages[0].id }
        : deal
    );
    setDeals(updatedDeals);
    setStages(stages.filter(stage => stage.id !== stageId));
  };

  return (
    <div className="min-h-screen bg-dark-900 p-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-100">Deal Pipeline</h1>
          <p className="text-gray-400 mt-1">Manage and track your real estate deals</p>
        </div>
        <button
          onClick={() => setShowAddModal(true)}
          className="btn-primary flex items-center gap-2"
        >
          <Plus className="w-4 h-4" />
          Add Deal
        </button>
      </div>

      {/* Filters */}
      <div className="flex flex-col lg:flex-row gap-4 mb-6">
        <div className="flex-1">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="text"
              placeholder="Search deals by title, client, or agent..."
              className="w-full pl-10 pr-4 py-2.5 bg-dark-800 border border-dark-700 text-gray-200 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
            />
          </div>
        </div>
        
        <div className="flex items-center gap-3">
          <select className="bg-dark-800 border border-dark-700 rounded-lg px-3 py-2 text-gray-200">
            <option>All Agents</option>
            <option>My Deals</option>
            <option>Team Deals</option>
          </select>

          <select className="bg-dark-800 border border-dark-700 rounded-lg px-3 py-2 text-gray-200">
            <option>All Types</option>
            <option>Residential</option>
            <option>Commercial</option>
            <option>Land</option>
          </select>

          <button className="btn-secondary flex items-center gap-2">
            <Filter className="w-4 h-4" />
            More Filters
            <ChevronDown className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Deal Stages */}
      <DragDropContext onDragEnd={handleDragEnd}>
        <Droppable droppableId="stages" type="stage" direction="vertical">
          {(provided) => (
            <div 
              ref={provided.innerRef}
              {...provided.droppableProps}
              className="space-y-8"
            >
              {stages.map((stage, stageIndex) => {
                const stageDeals = deals.filter(deal => deal.stage === stage.id);
                return (
                  <Draggable 
                    key={stage.id} 
                    draggableId={`stage-${stage.id}`} 
                    index={stageIndex}
                  >
                    {(provided) => (
                      <div
                        ref={provided.innerRef}
                        {...provided.draggableProps}
                      >
                        <div className="bg-dark-800 rounded-lg border border-dark-700 p-6">
                          <div 
                            className="flex items-center justify-between mb-4"
                            {...provided.dragHandleProps}
                          >
                            <div className="flex items-center gap-3">
                              <h3 className="text-lg font-semibold text-gray-100">{stage.label}</h3>
                              <span className={`px-2 py-1 rounded-full text-sm ${stage.color}`}>
                                {stageDeals.length}
                              </span>
                            </div>
                            <button
                              onClick={() => handleRemoveStage(stage.id)}
                              className="text-gray-400 hover:text-red-400 transition-colors"
                            >
                              <X className="w-4 h-4" />
                            </button>
                          </div>

                          <Droppable droppableId={stage.id} type="deal" direction="horizontal">
                            {(provided, snapshot) => (
                              <div
                                ref={provided.innerRef}
                                {...provided.droppableProps}
                                className={`grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 ${
                                  snapshot.isDraggingOver ? 'bg-dark-700/50 rounded-lg' : ''
                                }`}
                              >
                                {stageDeals.map((deal, index) => (
                                  <Draggable
                                    key={deal.id}
                                    draggableId={deal.id}
                                    index={index}
                                  >
                                    {(provided, snapshot) => (
                                      <div
                                        ref={provided.innerRef}
                                        {...provided.draggableProps}
                                        {...provided.dragHandleProps}
                                        className={`${stage.color} border rounded-lg p-4 cursor-move transition-all ${
                                          snapshot.isDragging ? 'shadow-lg scale-105' : ''
                                        }`}
                                        onClick={() => setSelectedDeal(deal)}
                                      >
                                        <div className="flex items-center justify-between mb-2">
                                          <h4 className="font-medium text-gray-200 truncate">{deal.title}</h4>
                                          <span className="text-primary-400 font-medium">{deal.value}</span>
                                        </div>
                                        <div className="space-y-1 text-sm">
                                          <div className="text-gray-400">Client: {deal.client}</div>
                                          <div className="text-gray-400">Agent: {deal.agent}</div>
                                          <div className="text-gray-400">Due: {deal.dueDate}</div>
                                        </div>
                                      </div>
                                    )}
                                  </Draggable>
                                ))}
                                {provided.placeholder}
                              </div>
                            )}
                          </Droppable>
                        </div>
                      </div>
                    )}
                  </Draggable>
                );
              })}
              {provided.placeholder}
            </div>
          )}
        </Droppable>
      </DragDropContext>

      {/* Add New Stage Button */}
      {showAddStage ? (
        <div className="flex items-center gap-2 mt-8">
          <input
            type="text"
            value={newStageName}
            onChange={(e) => setNewStageName(e.target.value)}
            className="flex-1 px-4 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200"
            placeholder="Enter stage name..."
          />
          <button
            onClick={handleAddStage}
            className="btn-primary"
          >
            Add Stage
          </button>
          <button
            onClick={() => {
              setShowAddStage(false);
              setNewStageName('');
            }}
            className="btn-secondary"
          >
            Cancel
          </button>
        </div>
      ) : (
        <button
          onClick={() => setShowAddStage(true)}
          className="w-full py-3 mt-8 border-2 border-dashed border-dark-600 rounded-lg text-gray-400 hover:text-gray-300 hover:border-dark-500 transition-colors"
        >
          <Plus className="w-6 h-6 mx-auto" />
        </button>
      )}

      {/* Modals */}
      {showAddModal && (
        <AddDealModal
          onClose={() => setShowAddModal(false)}
          onAdd={handleAddDeal}
        />
      )}

      {selectedDeal && (
        <DealDetails
          deal={selectedDeal}
          onClose={() => setSelectedDeal(null)}
          onMoveToNextStage={handleMoveToNextStage}
          currentStage={selectedDeal.stage}
        />
      )}
    </div>
  );
}