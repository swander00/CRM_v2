import React, { useState } from 'react';
import WorkflowHeader from '../components/drip-campaign/WorkflowHeader';
import ElementsSidebar from '../components/drip-campaign/ElementsSidebar';
import WorkflowCanvas from '../components/drip-campaign/WorkflowCanvas';
import SettingsPanel from '../components/drip-campaign/SettingsPanel';
import TimelineView from '../components/drip-campaign/TimelineView';

interface Block {
  id: string;
  type: 'email' | 'sms' | 'task' | 'wait' | 'branch';
  content?: {
    subject?: string;
    body?: string;
    delay?: number;
    delayUnit?: 'hours' | 'days' | 'weeks';
  };
}

export default function DripCampaignBuilder() {
  const [blocks, setBlocks] = useState<Block[]>([]);
  const [selectedBlock, setSelectedBlock] = useState<Block | undefined>();

  const handleBlockUpdate = (id: string, updates: Partial<Block['content']>) => {
    setBlocks(blocks.map(block => 
      block.id === id 
        ? { ...block, content: { ...block.content, ...updates } }
        : block
    ));
  };

  return (
    <div className="min-h-screen bg-dark-900">
      <WorkflowHeader />
      <div className="flex h-[calc(100vh-64px)]">
        <ElementsSidebar />
        <WorkflowCanvas
          blocks={blocks}
          setBlocks={setBlocks}
          selectedBlock={selectedBlock}
          onSelectBlock={setSelectedBlock}
        />
        <SettingsPanel
          selectedBlock={selectedBlock}
          onUpdate={handleBlockUpdate}
        />
      </div>
      <TimelineView />
    </div>
  );
}