import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import { mockLeads } from '../data/mockLeads';
import LeadOverview from '../components/lead-profile/LeadOverview';
import ContactInformation from '../components/lead-profile/ContactInformation';
import CommunicationLog from '../components/lead-profile/CommunicationLog';
import LeadActivityTimeline from '../components/lead-profile/LeadActivityTimeline';
import LeadPreferences from '../components/lead-profile/LeadPreferences';
import LeadTasks from '../components/lead-profile/LeadTasks';
import PropertyMatches from '../components/lead-profile/PropertyMatches';
import NotesAttachments from '../components/lead-profile/NotesAttachments';
import PerformanceMetrics from '../components/lead-profile/PerformanceMetrics';
import FinancialInformation from '../components/lead-profile/FinancialInformation';
import SavedSearches from '../components/lead-profile/SavedSearches';

export default function LeadProfile() {
  const { id } = useParams();
  const lead = mockLeads.find(l => l.id === Number(id));

  if (!lead) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-200">Lead not found</h2>
          <Link to="/" className="text-primary-400 hover:text-primary-300 mt-4 inline-block">
            Return to Lead Management
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-dark-900">
      <header className="bg-dark-800 border-b border-dark-700">
        <div className="w-full px-4 sm:px-6">
          <div className="py-4">
            <div className="flex items-center gap-4">
              <Link to="/" className="text-gray-400 hover:text-gray-300">
                <ArrowLeft className="w-5 h-5" />
              </Link>
              <h1 className="text-xl font-semibold text-gray-100">Lead Profile</h1>
            </div>
          </div>
        </div>
      </header>

      <main className="w-full px-4 sm:px-6 py-8">
        <div className="space-y-6">
          <LeadOverview lead={lead} />
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <ContactInformation lead={lead} />
            <CommunicationLog lead={lead} />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <LeadActivityTimeline lead={lead} />
            <LeadTasks lead={lead} />
          </div>

          <LeadPreferences lead={lead} />
          <SavedSearches leadId={lead.id} />
          <PropertyMatches lead={lead} />
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <NotesAttachments lead={lead} />
            <PerformanceMetrics lead={lead} />
          </div>

          <FinancialInformation lead={lead} />
        </div>
      </main>
    </div>
  );
}