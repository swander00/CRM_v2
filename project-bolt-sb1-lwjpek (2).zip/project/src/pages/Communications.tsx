import React, { useState } from 'react';
import CommunicationsSidebar from '../components/communications/CommunicationsSidebar';
import EmailList from '../components/communications/EmailList';
import EmailComposer from '../components/communications/EmailComposer';
import EmailView from '../components/communications/EmailView';

type ViewMode = 'list' | 'view' | 'compose';

export default function Communications() {
  const [viewMode, setViewMode] = useState<ViewMode>('list');
  const [selectedEmail, setSelectedEmail] = useState<any>(null);

  const handleCompose = () => {
    setViewMode('compose');
    setSelectedEmail(null);
  };

  const handleEmailSelect = (email: any) => {
    setSelectedEmail(email);
    setViewMode('view');
  };

  const handleBack = () => {
    setViewMode('list');
    setSelectedEmail(null);
  };

  return (
    <div className="h-[calc(100vh-theme(spacing.16)-theme(spacing.12))]">
      <div className="flex h-full bg-dark-800 rounded-lg border border-dark-700">
        <CommunicationsSidebar onCompose={handleCompose} />
        
        <div className="flex-1 flex flex-col">
          {viewMode === 'list' && (
            <EmailList onEmailSelect={handleEmailSelect} />
          )}
          
          {viewMode === 'view' && selectedEmail && (
            <EmailView email={selectedEmail} onBack={handleBack} />
          )}
          
          {viewMode === 'compose' && (
            <EmailComposer onCancel={handleBack} />
          )}
        </div>
      </div>
    </div>
  );
}