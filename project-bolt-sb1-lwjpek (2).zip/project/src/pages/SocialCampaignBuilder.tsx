import React, { useState } from 'react';
import { Save, Play } from 'lucide-react';
import PlatformSelector from '../components/social-campaign/PlatformSelector';
import PostEditor from '../components/social-campaign/PostEditor';
import PostPreview from '../components/social-campaign/PostPreview';
import SettingsPanel from '../components/social-campaign/SettingsPanel';
import { Post } from '../components/social-campaign/types';

export default function SocialCampaignBuilder() {
  const [selectedPlatforms, setSelectedPlatforms] = useState<string[]>([]);
  const [posts, setPosts] = useState<Post[]>([]);
  const [selectedPost, setSelectedPost] = useState<Post | undefined>();
  const [currentPost, setCurrentPost] = useState<Post>({
    id: '1',
    content: '',
    platforms: [],
    media: [],
    hashtags: []
  });

  const handlePlatformToggle = (platformId: string) => {
    setSelectedPlatforms(prev =>
      prev.includes(platformId)
        ? prev.filter(id => id !== platformId)
        : [...prev, platformId]
    );
    setCurrentPost(prev => ({
      ...prev,
      platforms: prev.platforms.includes(platformId)
        ? prev.platforms.filter(id => id !== platformId)
        : [...prev.platforms, platformId]
    }));
  };

  const handleAddPost = () => {
    const newPost = { ...currentPost, id: Date.now().toString() };
    setPosts(prev => [...prev, newPost]);
    setSelectedPost(newPost);
    setCurrentPost({
      id: (Date.now() + 1).toString(),
      content: '',
      platforms: selectedPlatforms,
      media: [],
      hashtags: []
    });
  };

  const handleRemovePost = (postId: string) => {
    setPosts(prev => prev.filter(post => post.id !== postId));
    if (selectedPost?.id === postId) {
      setSelectedPost(undefined);
    }
  };

  return (
    <div className="min-h-screen bg-dark-900 flex flex-col">
      {/* Header */}
      <div className="h-16 bg-dark-800 border-b border-dark-700 px-6">
        <div className="h-full flex items-center justify-between">
          <div>
            <h1 className="text-xl font-semibold text-gray-100">Social Campaign Builder</h1>
          </div>

          <div className="flex items-center gap-3">
            <button className="btn-secondary flex items-center gap-2">
              <Save className="w-4 h-4" />
              Save as Draft
            </button>
            <button className="btn-primary flex items-center gap-2">
              <Play className="w-4 h-4" />
              Launch Campaign
            </button>
          </div>
        </div>
      </div>

      <div className="flex-1 flex">
        <div className="flex-1 p-6 overflow-auto">
          <div className="max-w-[1200px] mx-auto space-y-8">
            <PlatformSelector
              selectedPlatforms={selectedPlatforms}
              onPlatformToggle={handlePlatformToggle}
            />

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <PostEditor
                currentPost={currentPost}
                onPostChange={setCurrentPost}
                onAddPost={handleAddPost}
              />
              <PostPreview
                posts={posts}
                onRemovePost={handleRemovePost}
              />
            </div>
          </div>
        </div>

        <SettingsPanel
          selectedPost={selectedPost}
          onUpdate={(updates) => {
            if (selectedPost) {
              setPosts(prev =>
                prev.map(post =>
                  post.id === selectedPost.id
                    ? { ...post, ...updates }
                    : post
                )
              );
            }
          }}
        />
      </div>
    </div>
  );
}