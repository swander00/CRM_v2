import React from 'react';
import PipelineHeader from '../components/pipeline/PipelineHeader';
import PipelineBoard from '../components/pipeline/PipelineBoard';
import PipelineStats from '../components/pipeline/PipelineStats';

export default function Pipeline() {
  return (
    <div className="h-screen flex flex-col">
      <PipelineHeader />
      <div className="flex-1 overflow-hidden p-6">
        <PipelineStats />
        <PipelineBoard />
      </div>
    </div>
  );
}