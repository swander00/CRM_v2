import React, { useState } from 'react';
import { Plus } from 'lucide-react';
import TopFilters from '../components/properties/TopFilters';
import PropertyTypeButtons from '../components/properties/PropertyTypeButtons';
import FilterOptions from '../components/properties/FilterOptions';
import PropertyGrid from '../components/properties/PropertyGrid';

export default function Properties() {
  const [selectedType, setSelectedType] = useState('all');
  const [showFilterOptions, setShowFilterOptions] = useState(false);

  return (
    <div className="min-h-screen bg-dark-900 p-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold text-gray-100">Property Listings</h1>
        <button className="btn-primary flex items-center gap-2">
          <Plus className="w-4 h-4" />
          Add Property
        </button>
      </div>

      {/* Filters */}
      <div className="space-y-6 mb-8 relative">
        <TopFilters onFilterClick={() => setShowFilterOptions(!showFilterOptions)} />
        <PropertyTypeButtons selectedType={selectedType} onTypeSelect={setSelectedType} />
        <FilterOptions isOpen={showFilterOptions} onClose={() => setShowFilterOptions(false)} />
      </div>

      {/* Property Grid */}
      <PropertyGrid />
    </div>
  );
}