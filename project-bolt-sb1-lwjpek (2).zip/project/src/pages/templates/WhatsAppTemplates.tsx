import React, { useState } from 'react';
import { Search, Plus, Phone, Edit2, Trash2, Copy } from 'lucide-react';

interface Template {
  id: string;
  name: string;
  body: string;
  category: string;
  lastModified: string;
  hasMedia: boolean;
}

const mockTemplates: Template[] = [
  {
    id: '1',
    name: 'Follow-up Message',
    body: 'Hi {name}, just checking in to see if you're interested in scheduling a showing for {property}. Let me know if you'd like to proceed!',
    category: 'Follow-up',
    lastModified: '2024-02-10',
    hasMedia: false,
  },
  {
    id: '2',
    name: 'Viewing Schedule',
    body: 'Hello {name}! Your viewing for {address} is confirmed for {date} at {time}. I\'ll meet you there!',
    category: 'Viewings',
    lastModified: '2024-02-14',
    hasMedia: true,
  },
  {
    id: '3',
    name: 'Thank You Message',
    body: 'Hi {name}, thank you for visiting {property} today. Please let me know if you have any questions or if you'd like to schedule another visit!',
    category: 'Follow-up',
    lastModified: '2024-02-15',
    hasMedia: false,
  },
  {
    id: '4',
    name: 'New Listing Announcement',
    body: 'Exciting news, {name}! A new property at {address} has just been listed. Check it out here: {link}',
    category: 'Announcements',
    lastModified: '2024-02-20',
    hasMedia: true,
  },
  {
    id: '5',
    name: 'Offer Reminder',
    body: 'Hi {name}, just a quick reminder that the offer deadline for {property} is {date}. Let me know if you have any questions or need assistance!',
    category: 'Reminders',
    lastModified: '2024-02-18',
    hasMedia: false,
  },
];

export default function WhatsAppTemplates() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  const categories = ['all', 'Follow-up', 'Viewings', 'Announcements', 'Reminders'];

  const filteredTemplates = mockTemplates.filter(template => {
    const matchesSearch = template.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         template.body.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || template.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="min-h-screen bg-dark-900 p-6">
      <div className="max-w-[1600px] mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold text-gray-100">WhatsApp Templates</h1>
            <p className="text-gray-400 mt-1">Manage and create WhatsApp templates for your campaigns</p>
          </div>
          <button className="btn-primary flex items-center gap-2">
            <Plus className="w-4 h-4" />
            Create Template
          </button>
        </div>

        {/* Search and Filters */}
        <div className="flex flex-col md:flex-row gap-4 mb-6">
          <div className="flex-1">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="text"
                placeholder="Search templates..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2 bg-dark-800 border border-dark-700 rounded-lg text-gray-200"
              />
            </div>
          </div>
          <div className="flex gap-2">
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => setSelectedCategory(category)}
                className={`px-4 py-2 rounded-lg transition-colors ${
                  selectedCategory === category
                    ? 'bg-primary-500 text-white'
                    : 'bg-dark-800 text-gray-400 hover:bg-dark-700'
                }`}
              >
                {category.charAt(0).toUpperCase() + category.slice(1)}
              </button>
            ))}
          </div>
        </div>

        {/* Templates Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredTemplates.map((template) => (
            <div
              key={template.id}
              className="bg-dark-800 border border-dark-700 rounded-lg p-6 hover:border-dark-600 transition-colors"
            >
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-emerald-500/10 rounded-lg">
                    <Phone className="w-5 h-5 text-emerald-400" />
                  </div>
                  <div>
                    <h3 className="font-medium text-gray-200">{template.name}</h3>
                    <p className="text-sm text-gray-400">{template.category}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <button className="p-1 text-gray-400 hover:text-gray-300">
                    <Copy className="w-4 h-4" />
                  </button>
                  <button className="p-1 text-gray-400 hover:text-gray-300">
                    <Edit2 className="w-4 h-4" />
                  </button>
                  <button className="p-1 text-red-400 hover:text-red-300">
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-xs text-gray-400 mb-1">Message</label>
                <p className="text-sm text-gray-300">{template.body}</p>
              </div>

              <div className="mt-4 pt-4 border-t border-dark-700 flex items-center justify-between">
                <p className="text-xs text-gray-500">
                  Last modified: {new Date(template.lastModified).toLocaleDateString()}
                </p>
                {template.hasMedia && (
                  <span className="text-xs text-emerald-400">
                    Includes media
                  </span>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}