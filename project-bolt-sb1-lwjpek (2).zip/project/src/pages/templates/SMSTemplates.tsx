import React, { useState } from 'react';
import { Search, Plus, MessageSquare, Edit2, Trash2, Copy } from 'lucide-react';

interface Template {
  id: string;
  name: string;
  body: string;
  category: string;
  lastModified: string;
  characterCount: number;
}

const mockTemplates: Template[] = [
  {
    id: '1',
    name: 'Viewing Confirmation',
    body: 'Your property viewing at {address} is confirmed for {time}. Reply YES to confirm or NO to reschedule.',
    category: 'Viewings',
    lastModified: '2024-02-15',
    characterCount: 98
  },
  {
    id: '2',
    name: 'Follow-up',
    body: 'Hi {name}, following up on your property search. Would you like to schedule a call to discuss your requirements?',
    category: 'Follow-up',
    lastModified: '2024-02-14',
    characterCount: 110
  },
  {
    id: '3',
    name: 'Price Update',
    body: 'Price update for {address}: Now listed at {price}. Interested in viewing? Reply YES for available times.',
    category: 'Updates',
    lastModified: '2024-02-13',
    characterCount: 102
  }
];

export default function SMSTemplates() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  const categories = ['all', 'Viewings', 'Follow-up', 'Updates', 'Reminders'];

  const filteredTemplates = mockTemplates.filter(template => {
    const matchesSearch = template.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         template.body.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || template.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="min-h-screen bg-dark-900 p-6">
      <div className="max-w-[1600px] mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold text-gray-100">SMS Templates</h1>
            <p className="text-gray-400 mt-1">Manage and create SMS templates for your campaigns</p>
          </div>
          <button className="btn-primary flex items-center gap-2">
            <Plus className="w-4 h-4" />
            Create Template
          </button>
        </div>

        {/* Search and Filters */}
        <div className="flex flex-col md:flex-row gap-4 mb-6">
          <div className="flex-1">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="text"
                placeholder="Search templates..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2 bg-dark-800 border border-dark-700 rounded-lg text-gray-200"
              />
            </div>
          </div>
          <div className="flex gap-2">
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => setSelectedCategory(category)}
                className={`px-4 py-2 rounded-lg transition-colors ${
                  selectedCategory === category
                    ? 'bg-primary-500 text-white'
                    : 'bg-dark-800 text-gray-400 hover:bg-dark-700'
                }`}
              >
                {category.charAt(0).toUpperCase() + category.slice(1)}
              </button>
            ))}
          </div>
        </div>

        {/* Templates Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredTemplates.map((template) => (
            <div
              key={template.id}
              className="bg-dark-800 border border-dark-700 rounded-lg p-6 hover:border-dark-600 transition-colors"
            >
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-green-500/10 rounded-lg">
                    <MessageSquare className="w-5 h-5 text-green-400" />
                  </div>
                  <div>
                    <h3 className="font-medium text-gray-200">{template.name}</h3>
                    <p className="text-sm text-gray-400">{template.category}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <button className="p-1 text-gray-400 hover:text-gray-300">
                    <Copy className="w-4 h-4" />
                  </button>
                  <button className="p-1 text-gray-400 hover:text-gray-300">
                    <Edit2 className="w-4 h-4" />
                  </button>
                  <button className="p-1 text-red-400 hover:text-red-300">
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-xs text-gray-400 mb-1">Message</label>
                <p className="text-sm text-gray-300">{template.body}</p>
              </div>

              <div className="mt-4 pt-4 border-t border-dark-700 flex items-center justify-between">
                <p className="text-xs text-gray-500">
                  Last modified: {new Date(template.lastModified).toLocaleDateString()}
                </p>
                <p className="text-xs text-gray-400">
                  {template.characterCount}/160 characters
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}