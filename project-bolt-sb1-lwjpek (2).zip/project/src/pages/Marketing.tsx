import React, { useState } from 'react';
import MarketingHeader from '../components/marketing/MarketingHeader';
import MarketingOverview from '../components/marketing/MarketingOverview';
import RecentCampaigns from '../components/marketing/RecentCampaigns';
import CampaignBuilder from '../components/marketing/CampaignBuilder';
import CampaignAnalytics from '../components/marketing/CampaignAnalytics';
import AssetLibrary from '../components/marketing/AssetLibrary';
import CampaignSelectionModal from '../components/marketing/CampaignSelectionModal';
import EmailBuilder from '../components/marketing/EmailBuilder';
import { useNavigate } from 'react-router-dom';

export default function Marketing() {
  const [showCampaignModal, setShowCampaignModal] = useState(false);
  const [showEmailBuilder, setShowEmailBuilder] = useState(false);
  const navigate = useNavigate();

  const handleCampaignSelect = (type: string) => {
    setShowCampaignModal(false);
    switch (type) {
      case 'drip':
        navigate('/campaigns/drip');
        break;
      case 'email':
        navigate('/campaigns/email');
        break;
      case 'sms':
        navigate('/campaigns/sms');
        break;
      case 'social':
        navigate('/campaigns/social');
        break;
    }
  };

  return (
    <div className="min-h-screen bg-dark-900">
      <MarketingHeader 
        onCreateClick={() => setShowCampaignModal(true)}
        onCreateEmail={() => setShowEmailBuilder(true)}
      />
      <div className="max-w-[1600px] mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <h1 className="text-3xl font-bold text-gray-100 mb-8">Marketing Hub</h1>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
          <MarketingOverview />
          <RecentCampaigns />
        </div>
        <div className="grid grid-cols-1 xl:grid-cols-4 gap-6">
          <div className="xl:col-span-3">
            <CampaignBuilder />
            <CampaignAnalytics />
          </div>
          <div className="xl:col-span-1">
            <AssetLibrary />
          </div>
        </div>
      </div>

      {showCampaignModal && (
        <CampaignSelectionModal
          onClose={() => setShowCampaignModal(false)}
          onSelect={handleCampaignSelect}
        />
      )}

      {showEmailBuilder && (
        <EmailBuilder onClose={() => setShowEmailBuilder(false)} />
      )}
    </div>
  );
}