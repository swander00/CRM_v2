import React from 'react';
import { Zap, Search, Filter, ChevronDown, Calendar, ArrowRight } from 'lucide-react';

export default function DripCampaignHistory() {
  return (
    <div className="min-h-screen bg-dark-900 p-6">
      <div className="max-w-[1600px] mx-auto">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold text-gray-100">Drip Campaigns</h1>
            <p className="text-gray-400 mt-1">View and manage your automated drip campaigns</p>
          </div>
          <button className="btn-primary flex items-center gap-2">
            <Zap className="w-4 h-4" />
            Create Drip Campaign
          </button>
        </div>

        <div className="flex flex-col lg:flex-row gap-4 mb-6">
          <div className="flex-1">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="text"
                placeholder="Search campaigns..."
                className="w-full pl-10 pr-4 py-2.5 bg-dark-800 border border-dark-700 text-gray-200 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
              />
            </div>
          </div>
          
          <div className="flex items-center gap-3">
            <select className="bg-dark-800 border border-dark-700 rounded-lg px-3 py-2 text-gray-200">
              <option>All Status</option>
              <option>Active</option>
              <option>Paused</option>
              <option>Completed</option>
            </select>

            <select className="bg-dark-800 border border-dark-700 rounded-lg px-3 py-2 text-gray-200">
              <option>All Types</option>
              <option>Welcome Series</option>
              <option>Follow-up</option>
              <option>Nurture</option>
            </select>

            <button className="btn-secondary flex items-center gap-2">
              <Filter className="w-4 h-4" />
              More Filters
              <ChevronDown className="w-4 h-4" />
            </button>
          </div>
        </div>

        <div className="space-y-4">
          {/* Example Campaign Card */}
          <div className="bg-dark-800 rounded-lg border border-dark-700 p-6">
            <div className="flex items-start justify-between mb-4">
              <div>
                <h3 className="text-lg font-semibold text-gray-100">Welcome Series Campaign</h3>
                <p className="text-sm text-gray-400 mt-1">Automated welcome series for new leads</p>
              </div>
              <span className="px-3 py-1 bg-green-500/10 text-green-400 rounded-full text-sm">
                Active
              </span>
            </div>

            <div className="grid grid-cols-4 gap-6 mb-4">
              <div>
                <p className="text-sm text-gray-400">Total Leads</p>
                <p className="text-xl font-semibold text-gray-100 mt-1">1,234</p>
              </div>
              <div>
                <p className="text-sm text-gray-400">Completion Rate</p>
                <p className="text-xl font-semibold text-gray-100 mt-1">85%</p>
              </div>
              <div>
                <p className="text-sm text-gray-400">Engagement Rate</p>
                <p className="text-xl font-semibold text-gray-100 mt-1">72%</p>
              </div>
              <div>
                <p className="text-sm text-gray-400">Last Modified</p>
                <p className="text-xl font-semibold text-gray-100 mt-1">2 days ago</p>
              </div>
            </div>

            <div className="flex items-center justify-between pt-4 border-t border-dark-700">
              <div className="flex items-center gap-4">
                <Calendar className="w-4 h-4 text-gray-400" />
                <span className="text-sm text-gray-400">Created on Feb 15, 2024</span>
              </div>
              <button className="text-primary-400 hover:text-primary-300 flex items-center gap-1">
                View Details
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}