import React from 'react';
import { 
  CircleDollarSign, 
  BarChart2, 
  Trophy, 
  TrendingUp,
  ArrowUp
} from 'lucide-react';
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer
} from 'recharts';

const revenueData = [
  { month: 'Jan', current: 1500000, previous: 1200000, best: 1800000 },
  { month: 'Feb', current: 1800000, previous: 1400000, best: 2000000 },
  { month: 'Mar', current: 2200000, previous: 1600000, best: 2100000 },
  { month: 'Apr', current: 2500000, previous: 1900000, best: 2300000 },
  { month: 'May', current: 2800000, previous: 2100000, best: 2600000 },
  { month: 'Jun', current: 3100000, previous: 2400000, best: 2900000 }
];

const yearlyRevenue = {
  current: 15900000,
  previous: 12600000,
  best: 16800000,
  projectedTotal: 18500000,
  percentageGrowth: 26.2
};

export default function Revenue() {
  return (
    <div className="min-h-screen bg-dark-900 p-6">
      <div className="max-w-[1600px] mx-auto">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold text-gray-100">Revenue Analytics</h1>
            <p className="text-gray-400 mt-1">Track and analyze your revenue performance</p>
          </div>
          <div className="flex gap-3">
            <select className="bg-dark-800 border border-dark-700 rounded-lg px-3 py-2 text-gray-200">
              <option>Last 7 days</option>
              <option>Last 30 days</option>
              <option>Last 90 days</option>
              <option>Last 12 months</option>
              <option>Custom Range</option>
            </select>
          </div>
        </div>

        {/* Revenue Overview */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <div className="bg-dark-800 rounded-lg border border-dark-700 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-400">Current Revenue</p>
                <p className="text-2xl font-semibold text-gray-100 mt-1">
                  ${(yearlyRevenue.current / 1000000).toFixed(1)}M
                </p>
              </div>
              <div className="p-3 bg-green-500/10 rounded-full">
                <CircleDollarSign className="w-6 h-6 text-green-400" />
              </div>
            </div>
            <div className="mt-4 flex items-center gap-1">
              <ArrowUp className="w-4 h-4 text-green-400" />
              <span className="text-sm text-green-400">{yearlyRevenue.percentageGrowth}%</span>
              <span className="text-sm text-gray-400 ml-1">vs last year</span>
            </div>
          </div>

          <div className="bg-dark-800 rounded-lg border border-dark-700 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-400">Previous Year</p>
                <p className="text-2xl font-semibold text-gray-100 mt-1">
                  ${(yearlyRevenue.previous / 1000000).toFixed(1)}M
                </p>
              </div>
              <div className="p-3 bg-blue-500/10 rounded-full">
                <BarChart2 className="w-6 h-6 text-blue-400" />
              </div>
            </div>
            <div className="mt-4 flex items-center gap-1">
              <span className="text-sm text-gray-400">Total revenue in 2023</span>
            </div>
          </div>

          <div className="bg-dark-800 rounded-lg border border-dark-700 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-400">Best Year</p>
                <p className="text-2xl font-semibold text-gray-100 mt-1">
                  ${(yearlyRevenue.best / 1000000).toFixed(1)}M
                </p>
              </div>
              <div className="p-3 bg-yellow-500/10 rounded-full">
                <Trophy className="w-6 h-6 text-yellow-400" />
              </div>
            </div>
            <div className="mt-4 flex items-center gap-1">
              <span className="text-sm text-gray-400">Record set in 2022</span>
            </div>
          </div>

          <div className="bg-dark-800 rounded-lg border border-dark-700 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-400">Projected Total</p>
                <p className="text-2xl font-semibold text-gray-100 mt-1">
                  ${(yearlyRevenue.projectedTotal / 1000000).toFixed(1)}M
                </p>
              </div>
              <div className="p-3 bg-purple-500/10 rounded-full">
                <TrendingUp className="w-6 h-6 text-purple-400" />
              </div>
            </div>
            <div className="mt-4 flex items-center gap-1">
              <ArrowUp className="w-4 h-4 text-green-400" />
              <span className="text-sm text-green-400">16.4%</span>
              <span className="text-sm text-gray-400 ml-1">vs best year</span>
            </div>
          </div>
        </div>

        {/* Revenue Comparison Chart */}
        <div className="bg-dark-800 rounded-lg border border-dark-700 p-6 mb-8">
          <h3 className="text-lg font-semibold text-gray-100 mb-6">Revenue Comparison</h3>
          <ResponsiveContainer width="100%" height={400}>
            <AreaChart data={revenueData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
              <XAxis dataKey="month" stroke="#9CA3AF" />
              <YAxis 
                stroke="#9CA3AF"
                tickFormatter={(value) => `$${(value / 1000000).toFixed(1)}M`}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: '#1F2937',
                  border: '1px solid #374151'
                }}
                formatter={(value: any) => [`$${(value / 1000000).toFixed(1)}M`]}
              />
              <Legend />
              <Area
                type="monotone"
                dataKey="current"
                name="Current Year"
                stroke="#1563df"
                fill="#1563df"
                fillOpacity={0.1}
                strokeWidth={2}
              />
              <Area
                type="monotone"
                dataKey="previous"
                name="Previous Year"
                stroke="#10B981"
                fill="#10B981"
                fillOpacity={0.1}
                strokeWidth={2}
              />
              <Area
                type="monotone"
                dataKey="best"
                name="Best Year"
                stroke="#F59E0B"
                fill="#F59E0B"
                fillOpacity={0.1}
                strokeWidth={2}
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}