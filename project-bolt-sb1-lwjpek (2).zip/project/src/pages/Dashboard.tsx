import React from 'react';
import { 
  Home, Users, Calendar, TrendingUp, DollarSign, 
  Mail, MessageSquare, Phone, Bell, Search, Plus,
  MapPin, BarChart2, ArrowUp, ArrowDown, Clock,
  Target, Star, Trophy, CircleDollarSign, Eye,
  CheckCircle, AlertCircle, FileText, ArrowRight
} from 'lucide-react';
import { format } from 'date-fns';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  ResponsiveContainer,
  Area,
  AreaChart
} from 'recharts';

const salesData = [
  { month: 'Jan', sales: 1500000, leads: 45 },
  { month: 'Feb', sales: 1800000, leads: 52 },
  { month: 'Mar', sales: 1400000, leads: 48 },
  { month: 'Apr', sales: 2200000, leads: 65 },
  { month: 'May', sales: 1600000, leads: 55 },
  { month: 'Jun', sales: 2400000, leads: 72 }
];

const leadSourceData = [
  { name: 'Website', value: 35 },
  { name: 'Referral', value: 25 },
  { name: 'Social Media', value: 20 },
  { name: 'Direct', value: 15 },
  { name: 'Other', value: 5 }
];

const pipelineData = [
  { stage: 'New Leads', count: 45, value: 2500000 },
  { stage: 'Contacted', count: 38, value: 2100000 },
  { stage: 'Qualified', count: 25, value: 1800000 },
  { stage: 'Proposal', count: 15, value: 1200000 },
  { stage: 'Negotiating', count: 8, value: 900000 },
  { stage: 'Closed', count: 5, value: 600000 }
];

const COLORS = ['#1563df', '#10B981', '#6366F1', '#F59E0B', '#EF4444'];

export default function Dashboard() {
  return (
    <div className="min-h-screen bg-dark-900 p-6">
      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <div className="bg-dark-800 rounded-lg border border-dark-700 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-400">Active Listings</p>
              <p className="text-2xl font-semibold text-gray-100 mt-1">156</p>
            </div>
            <div className="p-3 bg-primary-500/10 rounded-full">
              <Home className="w-6 h-6 text-primary-400" />
            </div>
          </div>
          <div className="mt-4 flex items-center gap-1">
            <TrendingUp className="w-4 h-4 text-green-400" />
            <span className="text-sm text-green-400">12%</span>
            <span className="text-sm text-gray-400 ml-1">vs last month</span>
          </div>
        </div>

        <div className="bg-dark-800 rounded-lg border border-dark-700 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-400">New Leads</p>
              <p className="text-2xl font-semibold text-gray-100 mt-1">247</p>
            </div>
            <div className="p-3 bg-green-500/10 rounded-full">
              <Users className="w-6 h-6 text-green-400" />
            </div>
          </div>
          <div className="mt-4 flex items-center gap-1">
            <TrendingUp className="w-4 h-4 text-green-400" />
            <span className="text-sm text-green-400">8%</span>
            <span className="text-sm text-gray-400 ml-1">vs last month</span>
          </div>
        </div>

        <div className="bg-dark-800 rounded-lg border border-dark-700 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-400">Appointments</p>
              <p className="text-2xl font-semibold text-gray-100 mt-1">32</p>
            </div>
            <div className="p-3 bg-blue-500/10 rounded-full">
              <Calendar className="w-6 h-6 text-blue-400" />
            </div>
          </div>
          <div className="mt-4 flex items-center gap-1">
            <TrendingUp className="w-4 h-4 text-green-400" />
            <span className="text-sm text-green-400">5%</span>
            <span className="text-sm text-gray-400 ml-1">vs last month</span>
          </div>
        </div>

        <div className="bg-dark-800 rounded-lg border border-dark-700 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-400">Closed Deals</p>
              <p className="text-2xl font-semibold text-gray-100 mt-1">18</p>
            </div>
            <div className="p-3 bg-purple-500/10 rounded-full">
              <CheckCircle className="w-6 h-6 text-purple-400" />
            </div>
          </div>
          <div className="mt-4 flex items-center gap-1">
            <TrendingUp className="w-4 h-4 text-green-400" />
            <span className="text-sm text-green-400">15%</span>
            <span className="text-sm text-gray-400 ml-1">vs last month</span>
          </div>
        </div>
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        {/* Sales & Leads Trend */}
        <div className="bg-dark-800 rounded-lg border border-dark-700 p-6">
          <h3 className="text-lg font-semibold text-gray-100 mb-6">Sales & Leads Trend</h3>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={salesData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
              <XAxis dataKey="month" stroke="#9CA3AF" />
              <YAxis yAxisId="left" stroke="#9CA3AF" />
              <YAxis yAxisId="right" orientation="right" stroke="#9CA3AF" />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: '#1F2937',
                  border: '1px solid #374151'
                }}
              />
              <Legend />
              <Line
                yAxisId="left"
                type="monotone"
                dataKey="sales"
                stroke="#1563df"
                name="Sales ($)"
              />
              <Line
                yAxisId="right"
                type="monotone"
                dataKey="leads"
                stroke="#10B981"
                name="Leads"
              />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* Lead Sources */}
        <div className="bg-dark-800 rounded-lg border border-dark-700 p-6">
          <h3 className="text-lg font-semibold text-gray-100 mb-6">Lead Sources</h3>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={leadSourceData}
                cx="50%"
                cy="50%"
                labelLine={false}
                outerRadius={100}
                fill="#8884d8"
                dataKey="value"
                label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
              >
                {leadSourceData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: '#1F2937',
                  border: '1px solid #374151'
                }}
              />
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Recent Activity & Tasks */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
        {/* Recent Activity */}
        <div className="lg:col-span-2 bg-dark-800 rounded-lg border border-dark-700 p-6">
          <h3 className="text-lg font-semibold text-gray-100 mb-6">Recent Activity</h3>
          <div className="space-y-4">
            <div className="flex items-start gap-4">
              <div className="p-2 bg-primary-500/10 rounded-lg">
                <Eye className="w-5 h-5 text-primary-400" />
              </div>
              <div>
                <div className="font-medium text-gray-200">Property Viewing</div>
                <div className="text-sm text-gray-400">John Smith viewed 123 Main Street</div>
                <div className="text-xs text-gray-500 mt-1">2 hours ago</div>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="p-2 bg-green-500/10 rounded-lg">
                <Mail className="w-5 h-5 text-green-400" />
              </div>
              <div>
                <div className="font-medium text-gray-200">Email Campaign</div>
                <div className="text-sm text-gray-400">Spring Listings Newsletter sent to 856 subscribers</div>
                <div className="text-xs text-gray-500 mt-1">5 hours ago</div>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="p-2 bg-yellow-500/10 rounded-lg">
                <Phone className="w-5 h-5 text-yellow-400" />
              </div>
              <div>
                <div className="font-medium text-gray-200">Client Call</div>
                <div className="text-sm text-gray-400">Follow-up call with Emma Davis</div>
                <div className="text-xs text-gray-500 mt-1">Yesterday</div>
              </div>
            </div>
          </div>
        </div>

        {/* Tasks Overview */}
        <div className="bg-dark-800 rounded-lg border border-dark-700 p-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-semibold text-gray-100">Tasks Overview</h3>
            <button className="btn-primary flex items-center gap-2">
              <Plus className="w-4 h-4" />
              Add Task
            </button>
          </div>
          <div className="space-y-4">
            <div className="flex items-center justify-between p-3 bg-dark-700/50 rounded-lg">
              <div className="flex items-center gap-3">
                <AlertCircle className="w-5 h-5 text-red-400" />
                <div>
                  <div className="text-sm font-medium text-gray-200">Follow up with leads</div>
                  <div className="text-xs text-gray-400">Due in 2 hours</div>
                </div>
              </div>
              <span className="px-2 py-1 text-xs bg-red-500/10 text-red-400 rounded-full">High</span>
            </div>

            <div className="flex items-center justify-between p-3 bg-dark-700/50 rounded-lg">
              <div className="flex items-center gap-3">
                <FileText className="w-5 h-5 text-yellow-400" />
                <div>
                  <div className="text-sm font-medium text-gray-200">Update listing details</div>
                  <div className="text-xs text-gray-400">Due tomorrow</div>
                </div>
              </div>
              <span className="px-2 py-1 text-xs bg-yellow-500/10 text-yellow-400 rounded-full">Medium</span>
            </div>

            <div className="flex items-center justify-between p-3 bg-dark-700/50 rounded-lg">
              <div className="flex items-center gap-3">
                <Calendar className="w-5 h-5 text-green-400" />
                <div>
                  <div className="text-sm font-medium text-gray-200">Schedule property viewing</div>
                  <div className="text-xs text-gray-400">Due in 3 days</div>
                </div>
              </div>
              <span className="px-2 py-1 text-xs bg-green-500/10 text-green-400 rounded-full">Low</span>
            </div>
          </div>
        </div>
      </div>

      {/* Pipeline Overview */}
      <div className="bg-dark-800 rounded-lg border border-dark-700 p-6">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h3 className="text-lg font-semibold text-gray-100">Pipeline Overview</h3>
            <p className="text-sm text-gray-400 mt-1">Current deals by stage</p>
          </div>
          <button className="btn-secondary flex items-center gap-2">
            <ArrowRight className="w-4 h-4" />
            View Pipeline
          </button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-6 gap-4">
          {pipelineData.map((stage, index) => (
            <div key={stage.stage} className="bg-dark-700/50 rounded-lg p-4">
              <div className="flex items-center justify-between mb-2">
                <h4 className="text-sm font-medium text-gray-200">{stage.stage}</h4>
                <span className={`px-2 py-1 text-xs rounded-full ${
                  index === 0 ? 'bg-blue-500/10 text-blue-400' :
                  index === 1 ? 'bg-purple-500/10 text-purple-400' :
                  index === 2 ? 'bg-green-500/10 text-green-400' :
                  index === 3 ? 'bg-yellow-500/10 text-yellow-400' :
                  index === 4 ? 'bg-orange-500/10 text-orange-400' :
                  'bg-primary-500/10 text-primary-400'
                }`}>
                  {stage.count}
                </span>
              </div>
              <div className="text-lg font-semibold text-gray-100">
                ${(stage.value / 1000000).toFixed(1)}M
              </div>
              <div className="mt-2 w-full bg-dark-600 rounded-full h-1">
                <div 
                  className={`h-full rounded-full ${
                    index === 0 ? 'bg-blue-500' :
                    index === 1 ? 'bg-purple-500' :
                    index === 2 ? 'bg-green-500' :
                    index === 3 ? 'bg-yellow-500' :
                    index === 4 ? 'bg-orange-500' :
                    'bg-primary-500'
                  }`}
                  style={{ width: `${(stage.count / 45 * 100)}%` }}
                />
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}