import React from 'react';

export default function Documents() {
  return (
    <div>
      <h1 className="text-2xl font-bold text-gray-100 mb-6">Document Management</h1>
      <div className="bg-dark-800 rounded-lg border border-dark-700 p-6">
        <p className="text-gray-400">Document management content will go here</p>
      </div>
    </div>
  );
}