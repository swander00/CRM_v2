import React from 'react';
import { 
  Search, 
  Globe, 
  Mail, 
  Camera, 
  Users, 
  BarChart2,
  Share2,
  Database,
  Video,
  Megaphone,
  MessageSquare,
  Smartphone
} from 'lucide-react';

const services = [
  {
    id: 'google-ads',
    title: 'Google Ads Management',
    description: 'Professional Google Ads management to drive quality leads',
    icon: Search,
    color: 'bg-blue-500/10 text-blue-500 border-blue-500/20',
    price: 'From $299/mo'
  },
  {
    id: 'social-ads',
    title: 'Social Media Advertising',
    description: 'Facebook, Instagram, and LinkedIn ad campaigns',
    icon: Share2,
    color: 'bg-purple-500/10 text-purple-500 border-purple-500/20',
    price: 'From $249/mo'
  },
  {
    id: 'website',
    title: 'Website Services',
    description: 'Custom real estate websites and landing pages',
    icon: Globe,
    color: 'bg-indigo-500/10 text-indigo-500 border-indigo-500/20',
    price: 'From $999'
  },
  {
    id: 'email-marketing',
    title: 'Email Marketing',
    description: 'Automated email campaigns and newsletters',
    icon: Mail,
    color: 'bg-green-500/10 text-green-500 border-green-500/20',
    price: 'From $149/mo'
  },
  {
    id: 'photography',
    title: 'Professional Photography',
    description: 'High-quality property photography services',
    icon: Camera,
    color: 'bg-pink-500/10 text-pink-500 border-pink-500/20',
    price: 'From $299'
  },
  {
    id: 'virtual-tours',
    title: 'Virtual Tours',
    description: '3D virtual tours and property walkthroughs',
    icon: Video,
    color: 'bg-yellow-500/10 text-yellow-500 border-yellow-500/20',
    price: 'From $399'
  },
  {
    id: 'crm',
    title: 'CRM Integration',
    description: 'Seamless integration with popular CRM platforms',
    icon: Database,
    color: 'bg-red-500/10 text-red-500 border-red-500/20',
    price: 'From $199/mo'
  },
  {
    id: 'lead-generation',
    title: 'Lead Generation',
    description: 'Advanced lead generation and qualification tools',
    icon: Users,
    color: 'bg-teal-500/10 text-teal-500 border-teal-500/20',
    price: 'From $349/mo'
  },
  {
    id: 'analytics',
    title: 'Marketing Analytics',
    description: 'Comprehensive marketing performance tracking',
    icon: BarChart2,
    color: 'bg-orange-500/10 text-orange-500 border-orange-500/20',
    price: 'From $199/mo'
  },
  {
    id: 'seo',
    title: 'SEO Services',
    description: 'Search engine optimization for real estate',
    icon: Globe,
    color: 'bg-cyan-500/10 text-cyan-500 border-cyan-500/20',
    price: 'From $499/mo'
  },
  {
    id: 'social-media',
    title: 'Social Media Management',
    description: 'Professional social media content and management',
    icon: Megaphone,
    color: 'bg-rose-500/10 text-rose-500 border-rose-500/20',
    price: 'From $299/mo'
  },
  {
    id: 'chatbot',
    title: 'AI Chatbot',
    description: '24/7 lead engagement and qualification',
    icon: MessageSquare,
    color: 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20',
    price: 'From $99/mo'
  }
];

export default function Marketplace() {
  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-[1600px] mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-2xl font-bold text-gray-900">Marketing Services Marketplace</h1>
          <p className="text-gray-600 mt-2">
            Boost your real estate business with our premium marketing services and tools
          </p>
        </div>

        {/* Service Categories */}
        <div className="flex gap-4 mb-8 overflow-x-auto pb-2">
          {['All Services', 'Advertising', 'Content', 'Analytics', 'Lead Generation', 'Integration'].map((category) => (
            <button
              key={category}
              className="px-4 py-2 rounded-full bg-white border border-gray-200 text-gray-600 hover:bg-gray-50 whitespace-nowrap"
            >
              {category}
            </button>
          ))}
        </div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {services.map((service) => {
            const Icon = service.icon;
            return (
              <div
                key={service.id}
                className="bg-white rounded-xl border border-gray-200 overflow-hidden hover:shadow-lg transition-shadow"
              >
                <div className="p-6">
                  <div className={`w-12 h-12 rounded-lg ${service.color} flex items-center justify-center mb-4`}>
                    <Icon className="w-6 h-6" />
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">
                    {service.title}
                  </h3>
                  <p className="text-gray-600 mb-4">
                    {service.description}
                  </p>
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium text-gray-900">
                      {service.price}
                    </span>
                    <button className="px-4 py-2 bg-primary-500 text-white rounded-lg hover:bg-primary-600 transition-colors">
                      Learn More
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Contact Section */}
        <div className="mt-12 bg-white rounded-xl border border-gray-200 p-8">
          <div className="text-center max-w-2xl mx-auto">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">
              Need a Custom Solution?
            </h2>
            <p className="text-gray-600 mb-6">
              Contact our team to discuss custom marketing packages tailored to your specific needs
            </p>
            <button className="px-6 py-3 bg-primary-500 text-white rounded-lg hover:bg-primary-600 transition-colors">
              Contact Sales Team
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}