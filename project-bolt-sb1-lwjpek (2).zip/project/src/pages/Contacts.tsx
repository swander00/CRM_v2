import React from 'react';
import Header from '../components/contacts/Header';
import SearchFilters from '../components/contacts/SearchFilters';
import ContactStats from '../components/contacts/ContactStats';
import ContactTable from '../components/contacts/ContactTable';
import FloatingActions from '../components/FloatingActions';

export default function Contacts() {
  return (
    <>
      <Header />
      <main className="max-w-[1600px] mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <SearchFilters />
        <ContactStats />
        <ContactTable />
        <FloatingActions />
      </main>
    </>
  );
}