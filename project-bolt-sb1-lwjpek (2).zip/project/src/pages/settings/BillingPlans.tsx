import React, { useState } from 'react';
import { Check, CreditCard, Download, AlertCircle } from 'lucide-react';

const plans = [
  {
    name: 'Starter',
    price: 29,
    description: 'Perfect for individual agents',
    features: [
      'Up to 100 leads',
      'Basic CRM features',
      'Email & SMS campaigns',
      'Standard support'
    ]
  },
  {
    name: 'Professional',
    price: 79,
    description: 'Ideal for growing teams',
    popular: true,
    features: [
      'Up to 1,000 leads',
      'Advanced CRM features',
      'Marketing automation',
      'Priority support',
      'Team collaboration',
      'Custom reports'
    ]
  },
  {
    name: 'Enterprise',
    price: 199,
    description: 'For large organizations',
    features: [
      'Unlimited leads',
      'Enterprise features',
      'White-label options',
      'Dedicated support',
      'API access',
      'Custom integrations',
      'Advanced analytics'
    ]
  }
];

export default function BillingPlans() {
  const [currentPlan, setCurrentPlan] = useState('professional');
  const [billingCycle, setBillingCycle] = useState('monthly');
  const [showCancelModal, setShowCancelModal] = useState(false);

  const CancelSubscriptionModal = () => (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-dark-800 rounded-lg w-full max-w-md p-6">
        <div className="flex items-center gap-3 mb-4">
          <AlertCircle className="w-6 h-6 text-red-400" />
          <h3 className="text-lg font-semibold text-gray-100">Cancel Subscription</h3>
        </div>

        <p className="text-gray-300 mb-4">
          Are you sure you want to cancel your subscription? You'll lose access to premium features at the end of your current billing period.
        </p>

        <div className="flex justify-end gap-3">
          <button
            onClick={() => setShowCancelModal(false)}
            className="btn-secondary"
          >
            Keep Subscription
          </button>
          <button
            onClick={() => setShowCancelModal(false)}
            className="px-4 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600"
          >
            Cancel Subscription
          </button>
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-dark-900 p-6">
      <div className="max-w-[1600px] mx-auto">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold text-gray-100">Billing & Plans</h1>
            <p className="text-gray-400 mt-1">Manage your subscription and billing details</p>
          </div>
          <div className="flex items-center gap-3">
            <button className="btn-secondary flex items-center gap-2">
              <Download className="w-4 h-4" />
              Download Invoices
            </button>
            <button className="btn-primary flex items-center gap-2">
              <CreditCard className="w-4 h-4" />
              Update Payment Method
            </button>
          </div>
        </div>

        {/* Current Plan */}
        <div className="bg-dark-800 rounded-lg border border-dark-700 p-6 mb-8">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-lg font-semibold text-gray-100">Current Plan</h2>
              <p className="text-gray-400 mt-1">You are currently on the Professional plan</p>
            </div>
            <button
              onClick={() => setShowCancelModal(true)}
              className="text-red-400 hover:text-red-300"
            >
              Cancel Subscription
            </button>
          </div>

          <div className="grid grid-cols-2 gap-6">
            <div className="space-y-4">
              <div>
                <div className="text-sm text-gray-400">Next billing date</div>
                <div className="text-lg font-medium text-gray-200">March 1, 2024</div>
              </div>
              <div>
                <div className="text-sm text-gray-400">Billing cycle</div>
                <select
                  value={billingCycle}
                  onChange={(e) => setBillingCycle(e.target.value)}
                  className="mt-1 bg-dark-700 border border-dark-600 rounded-lg px-3 py-2 text-gray-200"
                >
                  <option value="monthly">Monthly</option>
                  <option value="annual">Annual (Save 20%)</option>
                </select>
              </div>
            </div>

            <div className="space-y-4">
              <div>
                <div className="text-sm text-gray-400">Payment method</div>
                <div className="flex items-center gap-3 mt-1">
                  <div className="w-12 h-8 bg-gray-600 rounded"></div>
                  <div className="text-gray-200">•••• •••• •••• 4242</div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Available Plans */}
        <div>
          <h2 className="text-lg font-semibold text-gray-100 mb-6">Available Plans</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {plans.map((plan) => (
              <div
                key={plan.name.toLowerCase()}
                className={`bg-dark-800 rounded-lg border ${
                  plan.popular
                    ? 'border-primary-500'
                    : 'border-dark-700'
                } p-6 relative`}
              >
                {plan.popular && (
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                    <span className="px-3 py-1 bg-primary-500 text-white text-sm rounded-full">
                      Most Popular
                    </span>
                  </div>
                )}

                <div className="text-center mb-6">
                  <h3 className="text-xl font-semibold text-gray-100">{plan.name}</h3>
                  <div className="mt-2">
                    <span className="text-3xl font-bold text-gray-100">${plan.price}</span>
                    <span className="text-gray-400">/month</span>
                  </div>
                  <p className="text-sm text-gray-400 mt-2">{plan.description}</p>
                </div>

                <ul className="space-y-3 mb-6">
                  {plan.features.map((feature, index) => (
                    <li key={index} className="flex items-center gap-2 text-sm text-gray-300">
                      <Check className="w-4 h-4 text-green-400" />
                      {feature}
                    </li>
                  ))}
                </ul>

                <button
                  className={`w-full py-2 rounded-lg ${
                    currentPlan === plan.name.toLowerCase()
                      ? 'bg-primary-500 text-white'
                      : 'bg-dark-700 text-gray-200 hover:bg-dark-600'
                  }`}
                >
                  {currentPlan === plan.name.toLowerCase() ? 'Current Plan' : 'Upgrade'}
                </button>
              </div>
            ))}
          </div>
        </div>
      </div>

      {showCancelModal && <CancelSubscriptionModal />}
    </div>
  );
}