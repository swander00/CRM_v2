import React, { useState } from 'react';
import { 
  BarChart2, 
  TrendingUp, 
  Users, 
  DollarSign, 
  Download,
  Calendar,
  Filter,
  ChevronDown,
  ArrowUp,
  ArrowDown,
  Clock
} from 'lucide-react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  ResponsiveContainer
} from 'recharts';

const salesData = [
  { month: 'Jan', sales: 1200000, leads: 45 },
  { month: 'Feb', sales: 1800000, leads: 52 },
  { month: 'Mar', sales: 1400000, leads: 48 },
  { month: 'Apr', sales: 2200000, leads: 65 },
  { month: 'May', sales: 1600000, leads: 55 },
  { month: 'Jun', sales: 2400000, leads: 72 }
];

const leadSourceData = [
  { name: 'Website', value: 35 },
  { name: 'Referral', value: 25 },
  { name: 'Social Media', value: 20 },
  { name: 'Direct', value: 15 },
  { name: 'Other', value: 5 }
];

const COLORS = ['#1563df', '#10B981', '#6366F1', '#F59E0B', '#EF4444'];

export default function Analytics() {
  const [dateRange, setDateRange] = useState('7d');
  const [showFilters, setShowFilters] = useState(false);

  return (
    <div className="min-h-screen bg-dark-900 p-6">
      <div className="max-w-[1600px] mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold text-gray-100">Analytics & Reports</h1>
            <p className="text-gray-400 mt-1">Track your performance and insights</p>
          </div>
          <div className="flex items-center gap-3">
            <select 
              value={dateRange}
              onChange={(e) => setDateRange(e.target.value)}
              className="bg-dark-800 border border-dark-700 rounded-lg px-3 py-2 text-gray-200"
            >
              <option value="7d">Last 7 days</option>
              <option value="30d">Last 30 days</option>
              <option value="90d">Last 90 days</option>
              <option value="12m">Last 12 months</option>
            </select>
            <button className="btn-secondary flex items-center gap-2">
              <Filter className="w-4 h-4" />
              Filters
              <ChevronDown className="w-4 h-4" />
            </button>
            <button className="btn-primary flex items-center gap-2">
              <Download className="w-4 h-4" />
              Export Report
            </button>
          </div>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
          <div className="bg-dark-800 rounded-lg border border-dark-700 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-400">Total Revenue</p>
                <p className="text-2xl font-semibold text-gray-100 mt-1">$2.4M</p>
              </div>
              <div className="p-3 bg-primary-500/10 rounded-full">
                <DollarSign className="w-6 h-6 text-primary-400" />
              </div>
            </div>
            <div className="mt-4 flex items-center gap-1">
              <ArrowUp className="w-4 h-4 text-green-400" />
              <span className="text-sm text-green-400">12%</span>
              <span className="text-sm text-gray-400 ml-1">vs last period</span>
            </div>
          </div>

          <div className="bg-dark-800 rounded-lg border border-dark-700 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-400">Total Leads</p>
                <p className="text-2xl font-semibold text-gray-100 mt-1">337</p>
              </div>
              <div className="p-3 bg-blue-500/10 rounded-full">
                <Users className="w-6 h-6 text-blue-400" />
              </div>
            </div>
            <div className="mt-4 flex items-center gap-1">
              <ArrowUp className="w-4 h-4 text-green-400" />
              <span className="text-sm text-green-400">8%</span>
              <span className="text-sm text-gray-400 ml-1">vs last period</span>
            </div>
          </div>

          <div className="bg-dark-800 rounded-lg border border-dark-700 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-400">Conversion Rate</p>
                <p className="text-2xl font-semibold text-gray-100 mt-1">24.8%</p>
              </div>
              <div className="p-3 bg-green-500/10 rounded-full">
                <TrendingUp className="w-6 h-6 text-green-400" />
              </div>
            </div>
            <div className="mt-4 flex items-center gap-1">
              <ArrowDown className="w-4 h-4 text-red-400" />
              <span className="text-sm text-red-400">2%</span>
              <span className="text-sm text-gray-400 ml-1">vs last period</span>
            </div>
          </div>

          <div className="bg-dark-800 rounded-lg border border-dark-700 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-400">Avg. Response Time</p>
                <p className="text-2xl font-semibold text-gray-100 mt-1">2.5h</p>
              </div>
              <div className="p-3 bg-purple-500/10 rounded-full">
                <Clock className="w-6 h-6 text-purple-400" />
              </div>
            </div>
            <div className="mt-4 flex items-center gap-1">
              <ArrowUp className="w-4 h-4 text-green-400" />
              <span className="text-sm text-green-400">15%</span>
              <span className="text-sm text-gray-400 ml-1">faster</span>
            </div>
          </div>
        </div>

        {/* Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
          {/* Sales & Leads Trend */}
          <div className="bg-dark-800 rounded-lg border border-dark-700 p-6">
            <h3 className="text-lg font-semibold text-gray-100 mb-6">Sales & Leads Trend</h3>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={salesData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                <XAxis dataKey="month" stroke="#9CA3AF" />
                <YAxis yAxisId="left" stroke="#9CA3AF" />
                <YAxis yAxisId="right" orientation="right" stroke="#9CA3AF" />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: '#1F2937',
                    border: '1px solid #374151'
                  }}
                />
                <Legend />
                <Line
                  yAxisId="left"
                  type="monotone"
                  dataKey="sales"
                  stroke="#1563df"
                  name="Sales ($)"
                />
                <Line
                  yAxisId="right"
                  type="monotone"
                  dataKey="leads"
                  stroke="#10B981"
                  name="Leads"
                />
              </LineChart>
            </ResponsiveContainer>
          </div>

          {/* Lead Sources */}
          <div className="bg-dark-800 rounded-lg border border-dark-700 p-6">
            <h3 className="text-lg font-semibold text-gray-100 mb-6">Lead Sources</h3>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={leadSourceData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  outerRadius={100}
                  fill="#8884d8"
                  dataKey="value"
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                >
                  {leadSourceData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: '#1F2937',
                    border: '1px solid #374151'
                  }}
                />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Performance Metrics */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Lead Status */}
          <div className="bg-dark-800 rounded-lg border border-dark-700 p-6">
            <h3 className="text-lg font-semibold text-gray-100 mb-4">Lead Status</h3>
            <div className="space-y-4">
              <div>
                <div className="flex items-center justify-between text-sm mb-2">
                  <span className="text-gray-400">New</span>
                  <span className="text-gray-200">45</span>
                </div>
                <div className="w-full bg-dark-700 rounded-full h-2">
                  <div className="bg-primary-500 h-2 rounded-full" style={{ width: '45%' }}></div>
                </div>
              </div>
              <div>
                <div className="flex items-center justify-between text-sm mb-2">
                  <span className="text-gray-400">Qualified</span>
                  <span className="text-gray-200">28</span>
                </div>
                <div className="w-full bg-dark-700 rounded-full h-2">
                  <div className="bg-green-500 h-2 rounded-full" style={{ width: '28%' }}></div>
                </div>
              </div>
              <div>
                <div className="flex items-center justify-between text-sm mb-2">
                  <span className="text-gray-400">Negotiating</span>
                  <span className="text-gray-200">15</span>
                </div>
                <div className="w-full bg-dark-700 rounded-full h-2">
                  <div className="bg-yellow-500 h-2 rounded-full" style={{ width: '15%' }}></div>
                </div>
              </div>
              <div>
                <div className="flex items-center justify-between text-sm mb-2">
                  <span className="text-gray-400">Closed</span>
                  <span className="text-gray-200">12</span>
                </div>
                <div className="w-full bg-dark-700 rounded-full h-2">
                  <div className="bg-blue-500 h-2 rounded-full" style={{ width: '12%' }}></div>
                </div>
              </div>
            </div>
          </div>

          {/* Top Performing Agents */}
          <div className="bg-dark-800 rounded-lg border border-dark-700 p-6">
            <h3 className="text-lg font-semibold text-gray-100 mb-4">Top Performing Agents</h3>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-primary-500/10 flex items-center justify-center text-primary-400">
                    SW
                  </div>
                  <div>
                    <div className="text-gray-200">Sarah Wilson</div>
                    <div className="text-sm text-gray-400">$1.2M in sales</div>
                  </div>
                </div>
                <div className="text-green-400">+12%</div>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-primary-500/10 flex items-center justify-center text-primary-400">
                    JD
                  </div>
                  <div>
                    <div className="text-gray-200">John Davis</div>
                    <div className="text-sm text-gray-400">$980K in sales</div>
                  </div>
                </div>
                <div className="text-green-400">+8%</div>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-primary-500/10 flex items-center justify-center text-primary-400">
                    MB
                  </div>
                  <div>
                    <div className="text-gray-200">Mike Brown</div>
                    <div className="text-sm text-gray-400">$850K in sales</div>
                  </div>
                </div>
                <div className="text-red-400">-3%</div>
              </div>
            </div>
          </div>

          {/* Recent Activity */}
          <div className="bg-dark-800 rounded-lg border border-dark-700 p-6">
            <h3 className="text-lg font-semibold text-gray-100 mb-4">Recent Activity</h3>
            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-full bg-green-500/10 flex items-center justify-center">
                  <DollarSign className="w-4 h-4 text-green-400" />
                </div>
                <div>
                  <div className="text-gray-200">New Deal Closed</div>
                  <div className="text-sm text-gray-400">Sarah closed a $450K deal</div>
                  <div className="text-xs text-gray-500 mt-1">2 hours ago</div>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-full bg-blue-500/10 flex items-center justify-center">
                  <Users className="w-4 h-4 text-blue-400" />
                </div>
                <div>
                  <div className="text-gray-200">New Lead Assigned</div>
                  <div className="text-sm text-gray-400">John got assigned a new lead</div>
                  <div className="text-xs text-gray-500 mt-1">4 hours ago</div>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-full bg-purple-500/10 flex items-center justify-center">
                  <Calendar className="w-4 h-4 text-purple-400" />
                </div>
                <div>
                  <div className="text-gray-200">Property Viewing Scheduled</div>
                  <div className="text-sm text-gray-400">Mike scheduled a viewing</div>
                  <div className="text-xs text-gray-500 mt-1">6 hours ago</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}