import React, { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { 
  ArrowLeft, 
  Heart, 
  Share2, 
  Printer, 
  MapPin, 
  Bed, 
  Bath, 
  Square, 
  Car, 
  Home,
  Calendar,
  DollarSign,
  Building,
  Clock,
  Hash,
  Box,
  Trees,
  Info,
  CheckCircle,
  Tag
} from 'lucide-react';
import PropertyDetailsSection from '../components/property/PropertyDetails';

const mockProperty = {
  id: 1,
  address: '123 Luxury Lane',
  location: 'Beverly Hills, CA 90210',
  community: 'Credit Valley',
  region: 'Peel',
  price: 2850000,
  description: `Stunning Executive Home! Situated On A Stunning Ravine Lot Overlooking A Tranquil Pond, Located In The Sought-After Credit Valley Community, Two Primary Suites, Perfect Layout For Large Or Growing Families, Enter Stately Double Doors And Be Greeted By An Elegant Foyer Opening Up To A Spacious Open Concept Layout, Family Room With Soaring Vaulted Ceiling, Cozy Gas Fireplace. Beautiful Designer Kitchen Includes Luxury Built-In Appliances, Walk-In Pantry, Quartz Countertops With Custom Backsplash. A Perfect Spot To Relax! This spectacular home simply must be seen!`,
  details: {
    type: 'Single Family',
    yearBuilt: 2020,
    beds: 5,
    baths: 6,
    sqft: 6500,
    basement: 'Finished',
    lotSize: '0.5 acres',
    garage: 3,
    stories: 2
  },
  features: [
    'A/C & Heating',
    'Garden',
    'Refrigerator',
    'Garage',
    'Disabled Access',
    'Fire Place',
    'Swimming Pool',
    'Pet Friendly',
    'Elevator',
    'Wifi',
    'Ceiling Height',
    'Parking'
  ],
  images: [
    'https://images.unsplash.com/photo-1613490493576-7fde63acd811?auto=format&fit=crop&w=1600&q=80',
    'https://images.unsplash.com/photo-1613977257363-707ba9348227?auto=format&fit=crop&w=800&q=80',
    'https://images.unsplash.com/photo-1613977257592-4871e5fcd7c4?auto=format&fit=crop&w=800&q=80',
    'https://images.unsplash.com/photo-1613977257365-aaae5a9817ff?auto=format&fit=crop&w=800&q=80'
  ],
  listingInfo: {
    listed: '03/15/2020',
    lastUpdated: '02/14/2023',
    originalPrice: 1256134,
    mlsNumber: 'W5342689',
    possession: '03/14/2024',
    taxes: 2876.04,
    status: 'Active',
    daysOnMarket: 15,
    listDate: '2024-02-01',
    mls: 'MLS#12345',
    taxYear: 2023
  },
  propertyDetails: {
    bedrooms: 5,
    bathrooms: 4,
    approxAge: '5-10 yr',
    lotSize: '103\' x 200\'',
    sqFootage: '2000-2500',
    propertyType: 'Detached',
    status: 'For Sale'
  },
  basement: {
    status: 'Finished',
    entrance: 'Walkout'
  },
  parking: {
    drive: 2,
    garage: 2
  },
  utilities: {
    ac: 'Yes',
    heatSource: 'Gas / Forced Air',
    water: 'Municipal',
    sewers: 'Septic'
  },
  listingHistory: [
    {
      date: '2024-02-14',
      price: 2850000,
      type: 'increase'
    },
    {
      date: '2024-01-15',
      price: 2650000,
      type: 'decrease'
    },
    {
      date: '2023-12-01',
      price: 2950000,
      type: 'increase'
    },
    {
      date: '2023-11-15',
      price: 2750000,
      type: 'listed'
    }
  ],
  schools: [
    { name: 'Beverly Hills High', rating: 9, distance: '0.8 miles', type: 'Public' },
    { name: 'Beverly Vista Middle', rating: 8, distance: '1.2 miles', type: 'Public' },
    { name: 'Horace Mann Elementary', rating: 9, distance: '0.5 miles', type: 'Public' }
  ]
};

export default function PropertyDetails() {
  const { id } = useParams();
  const [selectedImage, setSelectedImage] = useState(0);
  const [isFavorite, setIsFavorite] = useState(false);

  const propertyAge = new Date().getFullYear() - mockProperty.details.yearBuilt;

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <div className="sticky top-0 z-50 bg-white border-b border-gray-200">
        <div className="max-w-[1600px] mx-auto px-4 sm:px-6 py-4">
          <div className="flex items-center justify-between">
            <Link to="/properties" className="text-gray-600 hover:text-gray-900">
              <ArrowLeft className="w-6 h-6" />
            </Link>
          </div>
        </div>
      </div>

      <div className="max-w-[1600px] mx-auto px-4 sm:px-6 py-8">
        {/* Property Overview */}
        <div className="mb-8">
          {/* Property Header */}
          <div className="flex justify-between items-start mb-8">
            {/* Left Column - Address and Details */}
            <div className="space-y-4">
              <div>
                <h1 className="text-3xl font-bold text-gray-900">{mockProperty.address}</h1>
                <div className="text-lg text-gray-600 mt-1">{mockProperty.location}</div>
              </div>
              
              <div className="flex gap-2">
                <span className="px-3 py-1 bg-gray-100 text-gray-600 rounded-full text-sm">
                  {mockProperty.community}
                </span>
                <span className="px-3 py-1 bg-gray-100 text-gray-600 rounded-full text-sm">
                  {mockProperty.region}
                </span>
              </div>

              <div className="flex items-center gap-2 text-gray-500">
                <Clock className="w-4 h-4" />
                <span className="font-medium">{mockProperty.listingInfo.daysOnMarket} Days on Market</span>
              </div>
            </div>

            {/* Right Column - Price and Actions */}
            <div className="text-right space-y-4">
              <div>
                <div className="flex items-center justify-end gap-3 mb-2">
                  <span className="px-3 py-1 bg-green-100 text-green-800 rounded-full text-sm font-medium">
                    For Sale
                  </span>
                  <div className="text-3xl font-bold text-gray-900">
                    ${mockProperty.price.toLocaleString()}
                  </div>
                </div>
                <div className="text-sm text-gray-500">
                  Property Taxes: ${mockProperty.listingInfo.taxes.toLocaleString()}/year
                </div>
              </div>

              <div className="flex justify-end gap-3">
                <button 
                  onClick={() => setIsFavorite(!isFavorite)}
                  className={`w-10 h-10 rounded-full flex items-center justify-center transition-colors ${
                    isFavorite 
                      ? 'bg-red-50 text-red-500' 
                      : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                  }`}
                >
                  <Heart className="w-5 h-5" fill={isFavorite ? 'currentColor' : 'none'} />
                </button>
                <button className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center text-gray-600 hover:bg-gray-200">
                  <Share2 className="w-5 h-5" />
                </button>
                <button className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center text-gray-600 hover:bg-gray-200">
                  <Printer className="w-5 h-5" />
                </button>
              </div>
            </div>
          </div>

          {/* Image Gallery */}
          <div className="grid grid-cols-4 gap-4 mb-8">
            <div className="col-span-3">
              <img
                src={mockProperty.images[selectedImage]}
                alt={`Property view ${selectedImage + 1}`}
                className="w-full h-[600px] object-cover rounded-lg"
              />
            </div>
            <div className="space-y-4">
              {mockProperty.images.map((image, index) => (
                <img
                  key={index}
                  src={image}
                  alt={`Property view ${index + 1}`}
                  className={`w-full h-[142px] object-cover rounded-lg cursor-pointer transition-opacity ${
                    selectedImage === index ? 'opacity-100 ring-2 ring-blue-500' : 'opacity-80 hover:opacity-100'
                  }`}
                  onClick={() => setSelectedImage(index)}
                />
              ))}
            </div>
          </div>

          {/* Property Details Grid */}
          <div className="grid grid-cols-7 gap-4 bg-gray-50 p-4 rounded-lg">
            <div className="text-center">
              <div className="flex items-center justify-center gap-2 text-gray-600 mb-2">
                <Bed className="w-5 h-5" />
                <span>Beds</span>
              </div>
              <div className="text-lg font-semibold text-gray-900">{mockProperty.details.beds}</div>
            </div>

            <div className="text-center">
              <div className="flex items-center justify-center gap-2 text-gray-600 mb-2">
                <Bath className="w-5 h-5" />
                <span>Baths</span>
              </div>
              <div className="text-lg font-semibold text-gray-900">{mockProperty.details.baths}</div>
            </div>

            <div className="text-center">
              <div className="flex items-center justify-center gap-2 text-gray-600 mb-2">
                <Square className="w-5 h-5" />
                <span>Sq.Ft.</span>
              </div>
              <div className="text-lg font-semibold text-gray-900">{mockProperty.details.sqft.toLocaleString()}</div>
            </div>

            <div className="text-center">
              <div className="flex items-center justify-center gap-2 text-gray-600 mb-2">
                <Box className="w-5 h-5" />
                <span>Basement</span>
              </div>
              <div className="text-lg font-semibold text-gray-900">{mockProperty.details.basement}</div>
            </div>

            <div className="text-center">
              <div className="flex items-center justify-center gap-2 text-gray-600 mb-2">
                <Trees className="w-5 h-5" />
                <span>Lot Size</span>
              </div>
              <div className="text-lg font-semibold text-gray-900">{mockProperty.details.lotSize}</div>
            </div>

            <div className="text-center">
              <div className="flex items-center justify-center gap-2 text-gray-600 mb-2">
                <Calendar className="w-5 h-5" />
                <span>Age</span>
              </div>
              <div className="text-lg font-semibold text-gray-900">{propertyAge} years</div>
            </div>

            <div className="text-center">
              <div className="flex items-center justify-center gap-2 text-gray-600 mb-2">
                <Car className="w-5 h-5" />
                <span>Garage</span>
              </div>
              <div className="text-lg font-semibold text-gray-900">{mockProperty.details.garage}</div>
            </div>
          </div>
        </div>

        {/* Property Information */}
        <div className="grid grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="col-span-2 space-y-8">
            {/* Description */}
            <div>
              <h2 className="text-xl font-semibold text-gray-900 mb-4">Description</h2>
              <p className="text-gray-600 leading-relaxed">{mockProperty.description}</p>
            </div>

            {/* Property Details Sections */}
            <PropertyDetailsSection
              listingInfo={mockProperty.listingInfo}
              propertyDetails={mockProperty.propertyDetails}
              basement={mockProperty.basement}
              parking={mockProperty.parking}
              utilities={mockProperty.utilities}
              features={mockProperty.features}
              listingHistory={mockProperty.listingHistory}
            />

            {/* Schools */}
            <div>
              <h2 className="text-xl font-semibold text-gray-900 mb-4">Nearby Schools</h2>
              <div className="space-y-4">
                {mockProperty.schools.map((school, index) => (
                  <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                    <div>
                      <h3 className="font-medium text-gray-900">{school.name}</h3>
                      <p className="text-sm text-gray-600">{school.type} • {school.distance}</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm">
                        Rating: {school.rating}/10
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Contact Card */}
            <div className="sticky top-24 bg-white rounded-lg border border-gray-200 p-6 shadow-sm">
              <div className="space-y-3">
                <button className="w-full btn-primary">
                  Schedule Viewing
                </button>
                <button className="w-full btn-secondary">
                  Request Information
                </button>
              </div>

              <div className="mt-6 p-4 bg-blue-50 rounded-lg">
                <div className="flex items-start gap-3">
                  <Info className="w-5 h-5 text-blue-500 mt-0.5" />
                  <div>
                    <h4 className="font-medium text-blue-900">Property Alert</h4>
                    <p className="text-sm text-blue-700 mt-1">
                      This is a highly competitive listing. Schedule a viewing soon to avoid missing out.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}