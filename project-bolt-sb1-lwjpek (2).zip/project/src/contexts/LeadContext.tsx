import React, { createContext, useContext, useState } from 'react';
import { mockLeads } from '../data/mockLeads';
import { Lead } from '../types/lead';

interface LeadContextType {
  leads: Lead[];
  addLead: (lead: Partial<Lead>) => void;
  updateLead: (id: number, updates: Partial<Lead>) => void;
  deleteLead: (id: number) => void;
}

const LeadContext = createContext<LeadContextType | undefined>(undefined);

export function LeadProvider({ children }: { children: React.ReactNode }) {
  const [leads, setLeads] = useState<Lead[]>(mockLeads);

  const addLead = (leadData: Partial<Lead>) => {
    const newLead: Lead = {
      id: Math.max(...leads.map(l => l.id)) + 1,
      name: leadData.name || '',
      email: leadData.email || '',
      phone: leadData.phone || '',
      status: leadData.status || 'Active',
      pipelineStatus: leadData.pipelineStatus || 'new',
      source: {
        url: leadData.source?.url || '',
        type: leadData.source?.type || '',
        location: leadData.source?.location || ''
      },
      price: {
        minBuy: leadData.price?.minBuy || '',
        maxBuy: leadData.price?.maxBuy || '',
        buy: 'Yes',
        sell: 'No'
      },
      timeline: {
        date: new Date().toISOString(),
        time: new Date().toLocaleTimeString(),
        intent: 'buying',
        urgency: leadData.timeline?.urgency || 'immediate'
      },
      activity: {
        days: 0,
        calls: 0,
        emails: { total: 0, unread: 0 },
        messages: { total: 0, unread: 0 },
        lastContact: {
          date: new Date().toISOString(),
          method: 'email'
        }
      },
      tasks: {
        completed: 0,
        total: 0
      },
      assigned: {
        name: 'Unassigned',
        completed: 0
      },
      leadType: leadData.leadType || '',
      leadScore: 0,
      propertyPreferences: {
        type: leadData.propertyPreferences?.type || '',
        bedrooms: 0,
        bathrooms: 0,
        squareFootage: '',
      },
      registrationDate: new Date().toISOString(),
      tags: leadData.tags || []
    };

    setLeads(prevLeads => [...prevLeads, newLead]);
  };

  const updateLead = (id: number, updates: Partial<Lead>) => {
    setLeads(prevLeads =>
      prevLeads.map(lead =>
        lead.id === id ? { ...lead, ...updates } : lead
      )
    );
  };

  const deleteLead = (id: number) => {
    setLeads(prevLeads => prevLeads.filter(lead => lead.id !== id));
  };

  return (
    <LeadContext.Provider value={{ leads, addLead, updateLead, deleteLead }}>
      {children}
    </LeadContext.Provider>
  );
}

export function useLeads() {
  const context = useContext(LeadContext);
  if (context === undefined) {
    throw new Error('useLeads must be used within a LeadProvider');
  }
  return context;
}