import React from 'react';
import { Sliders, Globe, Clock, Database } from 'lucide-react';

export default function SystemSettings() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-semibold text-gray-100">System Settings</h2>
        <button className="btn-primary">Save Changes</button>
      </div>

      {/* General Settings */}
      <div className="space-y-4">
        <h3 className="text-sm font-medium text-gray-400">General Settings</h3>
        <div className="space-y-3">
          <div className="flex items-center justify-between p-4 bg-dark-700/50 rounded-lg">
            <div>
              <div className="font-medium text-gray-200">System Language</div>
              <div className="text-sm text-gray-400">Set the default system language</div>
            </div>
            <select className="bg-dark-700 border border-dark-600 rounded-lg px-3 py-2 text-gray-200">
              <option>English (US)</option>
              <option>Spanish</option>
              <option>French</option>
            </select>
          </div>

          <div className="flex items-center justify-between p-4 bg-dark-700/50 rounded-lg">
            <div>
              <div className="font-medium text-gray-200">Time Zone</div>
              <div className="text-sm text-gray-400">Set your local time zone</div>
            </div>
            <select className="bg-dark-700 border border-dark-600 rounded-lg px-3 py-2 text-gray-200">
              <option>Pacific Time (PT)</option>
              <option>Eastern Time (ET)</option>
              <option>UTC</option>
            </select>
          </div>

          <div className="flex items-center justify-between p-4 bg-dark-700/50 rounded-lg">
            <div>
              <div className="font-medium text-gray-200">Date Format</div>
              <div className="text-sm text-gray-400">Set the default date format</div>
            </div>
            <select className="bg-dark-700 border border-dark-600 rounded-lg px-3 py-2 text-gray-200">
              <option>MM/DD/YYYY</option>
              <option>DD/MM/YYYY</option>
              <option>YYYY-MM-DD</option>
            </select>
          </div>
        </div>
      </div>

      {/* Performance Settings */}
      <div className="space-y-4 pt-6 border-t border-dark-700">
        <h3 className="text-sm font-medium text-gray-400">Performance Settings</h3>
        <div className="space-y-3">
          <div className="flex items-center justify-between p-4 bg-dark-700/50 rounded-lg">
            <div>
              <div className="font-medium text-gray-200">Cache Duration</div>
              <div className="text-sm text-gray-400">Set how long to cache data</div>
            </div>
            <select className="bg-dark-700 border border-dark-600 rounded-lg px-3 py-2 text-gray-200">
              <option>1 hour</option>
              <option>6 hours</option>
              <option>24 hours</option>
            </select>
          </div>

          <div className="flex items-center justify-between p-4 bg-dark-700/50 rounded-lg">
            <div>
              <div className="font-medium text-gray-200">Auto Refresh</div>
              <div className="text-sm text-gray-400">Automatically refresh data</div>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input type="checkbox" className="sr-only peer" defaultChecked />
              <div className="w-11 h-6 bg-dark-600 peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-primary-500 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary-500"></div>
            </label>
          </div>
        </div>
      </div>

      {/* System Maintenance */}
      <div className="space-y-4 pt-6 border-t border-dark-700">
        <h3 className="text-sm font-medium text-gray-400">System Maintenance</h3>
        <div className="space-y-3">
          <div className="p-4 bg-dark-700/50 rounded-lg">
            <div className="flex items-center justify-between mb-3">
              <div>
                <div className="font-medium text-gray-200">Clear Cache</div>
                <div className="text-sm text-gray-400">Clear system cache data</div>
              </div>
              <button className="btn-secondary">Clear Now</button>
            </div>
          </div>

          <div className="p-4 bg-dark-700/50 rounded-lg">
            <div className="flex items-center justify-between mb-3">
              <div>
                <div className="font-medium text-gray-200">System Logs</div>
                <div className="text-sm text-gray-400">View and download system logs</div>
              </div>
              <button className="btn-secondary">View Logs</button>
            </div>
          </div>
        </div>
      </div>

      {/* API Settings */}
      <div className="space-y-4 pt-6 border-t border-dark-700">
        <h3 className="text-sm font-medium text-gray-400">API Settings</h3>
        <div className="space-y-3">
          <div className="flex items-center justify-between p-4 bg-dark-700/50 rounded-lg">
            <div>
              <div className="font-medium text-gray-200">API Rate Limiting</div>
              <div className="text-sm text-gray-400">Set API request limits</div>
            </div>
            <select className="bg-dark-700 border border-dark-600 rounded-lg px-3 py-2 text-gray-200">
              <option>100 requests/min</option>
              <option>500 requests/min</option>
              <option>1000 requests/min</option>
            </select>
          </div>

          <div className="flex items-center justify-between p-4 bg-dark-700/50 rounded-lg">
            <div>
              <div className="font-medium text-gray-200">API Timeout</div>
              <div className="text-sm text-gray-400">Set API request timeout</div>
            </div>
            <select className="bg-dark-700 border border-dark-600 rounded-lg px-3 py-2 text-gray-200">
              <option>30 seconds</option>
              <option>60 seconds</option>
              <option>120 seconds</option>
            </select>
          </div>
        </div>
      </div>
    </div>
  );
}