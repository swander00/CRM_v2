import React from 'react';
import { Palette, Moon, Sun, Monitor } from 'lucide-react';
import { useTheme } from '../../contexts/ThemeContext';

export default function AppearanceSettings() {
  const { theme, toggleTheme } = useTheme();

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-semibold text-gray-100">Appearance Settings</h2>
        <button className="btn-primary">Save Changes</button>
      </div>

      {/* Theme Selection */}
      <div className="space-y-4">
        <h3 className="text-sm font-medium text-gray-400">Theme</h3>
        <div className="grid grid-cols-3 gap-4">
          <button
            className={`p-4 bg-dark-700/50 rounded-lg border-2 ${
              theme === 'light' ? 'border-primary-500' : 'border-transparent'
            }`}
            onClick={() => theme !== 'light' && toggleTheme()}
          >
            <Sun className="w-6 h-6 text-primary-400 mx-auto mb-2" />
            <div className="text-sm font-medium text-gray-200">Light</div>
          </button>

          <button
            className={`p-4 bg-dark-700/50 rounded-lg border-2 ${
              theme === 'dark' ? 'border-primary-500' : 'border-transparent'
            }`}
            onClick={() => theme !== 'dark' && toggleTheme()}
          >
            <Moon className="w-6 h-6 text-primary-400 mx-auto mb-2" />
            <div className="text-sm font-medium text-gray-200">Dark</div>
          </button>

          <button
            className="p-4 bg-dark-700/50 rounded-lg border-2 border-transparent"
          >
            <Monitor className="w-6 h-6 text-primary-400 mx-auto mb-2" />
            <div className="text-sm font-medium text-gray-200">System</div>
          </button>
        </div>
      </div>

      {/* Color Scheme */}
      <div className="space-y-4 pt-6 border-t border-dark-700">
        <h3 className="text-sm font-medium text-gray-400">Color Scheme</h3>
        <div className="grid grid-cols-6 gap-4">
          <button className="w-12 h-12 rounded-lg bg-blue-500 ring-2 ring-offset-2 ring-offset-dark-800 ring-blue-500" />
          <button className="w-12 h-12 rounded-lg bg-purple-500" />
          <button className="w-12 h-12 rounded-lg bg-green-500" />
          <button className="w-12 h-12 rounded-lg bg-red-500" />
          <button className="w-12 h-12 rounded-lg bg-yellow-500" />
          <button className="w-12 h-12 rounded-lg bg-pink-500" />
        </div>
      </div>

      {/* Font Settings */}
      <div className="space-y-4 pt-6 border-t border-dark-700">
        <h3 className="text-sm font-medium text-gray-400">Font Settings</h3>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm text-gray-400 mb-2">Font Family</label>
            <select className="w-full px-4 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200">
              <option>Inter</option>
              <option>Roboto</option>
              <option>Open Sans</option>
            </select>
          </div>
          <div>
            <label className="block text-sm text-gray-400 mb-2">Font Size</label>
            <select className="w-full px-4 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200">
              <option>Small</option>
              <option>Medium</option>
              <option>Large</option>
            </select>
          </div>
        </div>
      </div>

      {/* Layout Settings */}
      <div className="space-y-4 pt-6 border-t border-dark-700">
        <h3 className="text-sm font-medium text-gray-400">Layout Settings</h3>
        <div className="space-y-3">
          <div className="flex items-center justify-between p-4 bg-dark-700/50 rounded-lg">
            <div>
              <div className="font-medium text-gray-200">Compact Mode</div>
              <div className="text-sm text-gray-400">Reduce spacing between elements</div>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input type="checkbox" className="sr-only peer" />
              <div className="w-11 h-6 bg-dark-600 peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-primary-500 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary-500"></div>
            </label>
          </div>

          <div className="flex items-center justify-between p-4 bg-dark-700/50 rounded-lg">
            <div>
              <div className="font-medium text-gray-200">Show Animations</div>
              <div className="text-sm text-gray-400">Enable interface animations</div>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input type="checkbox" className="sr-only peer" defaultChecked />
              <div className="w-11 h-6 bg-dark-600 peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-primary-500 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary-500"></div>
            </label>
          </div>
        </div>
      </div>
    </div>
  );
}