import React from 'react';
import { CreditCard, DollarSign, Download, Clock } from 'lucide-react';

export default function BillingSettings() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-semibold text-gray-100">Billing Settings</h2>
        <button className="btn-primary">Update Payment Method</button>
      </div>

      {/* Current Plan */}
      <div className="space-y-4">
        <h3 className="text-sm font-medium text-gray-400">Current Plan</h3>
        <div className="p-4 bg-dark-700/50 rounded-lg">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h4 className="font-medium text-gray-200">Professional Plan</h4>
              <p className="text-sm text-gray-400">$49/month • Billed monthly</p>
            </div>
            <span className="px-3 py-1 bg-green-500/10 text-green-400 text-sm rounded-full">Active</span>
          </div>
          <div className="space-y-2 text-sm text-gray-400">
            <div className="flex items-center gap-2">
              <DollarSign className="w-4 h-4" />
              <span>Next billing date: March 15, 2024</span>
            </div>
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4" />
              <span>Renewal is automatic</span>
            </div>
          </div>
        </div>
      </div>

      {/* Payment Method */}
      <div className="space-y-4 pt-6 border-t border-dark-700">
        <h3 className="text-sm font-medium text-gray-400">Payment Method</h3>
        <div className="p-4 bg-dark-700/50 rounded-lg">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-8 bg-gray-600 rounded"></div>
              <div>
                <div className="font-medium text-gray-200">•••• •••• •••• 4242</div>
                <div className="text-sm text-gray-400">Expires 12/24</div>
              </div>
            </div>
            <button className="text-sm text-primary-400 hover:text-primary-300">Edit</button>
          </div>
        </div>
      </div>

      {/* Billing History */}
      <div className="space-y-4 pt-6 border-t border-dark-700">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-medium text-gray-400">Billing History</h3>
          <button className="text-sm text-primary-400 hover:text-primary-300 flex items-center gap-2">
            <Download className="w-4 h-4" />
            Download All
          </button>
        </div>
        <div className="space-y-3">
          <div className="flex items-center justify-between p-4 bg-dark-700/50 rounded-lg">
            <div>
              <div className="font-medium text-gray-200">February 2024</div>
              <div className="text-sm text-gray-400">Professional Plan</div>
            </div>
            <div className="flex items-center gap-4">
              <span className="text-gray-200">$49.00</span>
              <button className="text-sm text-primary-400 hover:text-primary-300">
                Download
              </button>
            </div>
          </div>
          <div className="flex items-center justify-between p-4 bg-dark-700/50 rounded-lg">
            <div>
              <div className="font-medium text-gray-200">January 2024</div>
              <div className="text-sm text-gray-400">Professional Plan</div>
            </div>
            <div className="flex items-center gap-4">
              <span className="text-gray-200">$49.00</span>
              <button className="text-sm text-primary-400 hover:text-primary-300">
                Download
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Billing Address */}
      <div className="space-y-4 pt-6 border-t border-dark-700">
        <h3 className="text-sm font-medium text-gray-400">Billing Address</h3>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm text-gray-400 mb-2">Full Name</label>
            <input
              type="text"
              defaultValue="John Doe"
              className="w-full px-4 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200"
            />
          </div>
          <div>
            <label className="block text-sm text-gray-400 mb-2">Company Name</label>
            <input
              type="text"
              defaultValue="Real Estate Pro"
              className="w-full px-4 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200"
            />
          </div>
          <div className="col-span-2">
            <label className="block text-sm text-gray-400 mb-2">Address</label>
            <input
              type="text"
              defaultValue="123 Business Ave, Suite 100"
              className="w-full px-4 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200"
            />
          </div>
          <div>
            <label className="block text-sm text-gray-400 mb-2">City</label>
            <input
              type="text"
              defaultValue="Los Angeles"
              className="w-full px-4 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200"
            />
          </div>
          <div>
            <label className="block text-sm text-gray-400 mb-2">ZIP Code</label>
            <input
              type="text"
              defaultValue="90012"
              className="w-full px-4 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200"
            />
          </div>
        </div>
      </div>
    </div>
  );
}