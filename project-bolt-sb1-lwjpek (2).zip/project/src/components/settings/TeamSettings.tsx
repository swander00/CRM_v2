import React from 'react';
import { Users, UserPlus, Settings, Shield } from 'lucide-react';

export default function TeamSettings() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-semibold text-gray-100">Team Settings</h2>
        <button className="btn-primary flex items-center gap-2">
          <UserPlus className="w-4 h-4" />
          Invite Member
        </button>
      </div>

      {/* Team Members */}
      <div className="space-y-4">
        <h3 className="text-sm font-medium text-gray-400">Team Members</h3>
        <div className="space-y-3">
          <div className="flex items-center justify-between p-4 bg-dark-700/50 rounded-lg">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-primary-500/10 flex items-center justify-center text-primary-400">
                JD
              </div>
              <div>
                <div className="font-medium text-gray-200">John Doe</div>
                <div className="text-sm text-gray-400">john.doe@example.com</div>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <span className="px-3 py-1 bg-primary-500/10 text-primary-400 text-sm rounded-full">
                Admin
              </span>
              <button className="text-gray-400 hover:text-gray-300">
                <Settings className="w-4 h-4" />
              </button>
            </div>
          </div>

          <div className="flex items-center justify-between p-4 bg-dark-700/50 rounded-lg">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-primary-500/10 flex items-center justify-center text-primary-400">
                SW
              </div>
              <div>
                <div className="font-medium text-gray-200">Sarah Wilson</div>
                <div className="text-sm text-gray-400">sarah.wilson@example.com</div>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <span className="px-3 py-1 bg-green-500/10 text-green-400 text-sm rounded-full">
                Member
              </span>
              <button className="text-gray-400 hover:text-gray-300">
                <Settings className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Roles & Permissions */}
      <div className="space-y-4 pt-6 border-t border-dark-700">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-medium text-gray-400">Roles & Permissions</h3>
          <button className="text-sm text-primary-400 hover:text-primary-300">Manage Roles</button>
        </div>
        <div className="space-y-3">
          <div className="p-4 bg-dark-700/50 rounded-lg">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Shield className="w-4 h-4 text-primary-400" />
                <h4 className="font-medium text-gray-200">Admin</h4>
              </div>
              <span className="text-sm text-gray-400">1 member</span>
            </div>
            <p className="text-sm text-gray-400">Full access to all features and settings</p>
          </div>

          <div className="p-4 bg-dark-700/50 rounded-lg">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Shield className="w-4 h-4 text-green-400" />
                <h4 className="font-medium text-gray-200">Member</h4>
              </div>
              <span className="text-sm text-gray-400">1 member</span>
            </div>
            <p className="text-sm text-gray-400">Limited access to features and settings</p>
          </div>
        </div>
      </div>

      {/* Team Settings */}
      <div className="space-y-4 pt-6 border-t border-dark-700">
        <h3 className="text-sm font-medium text-gray-400">Team Settings</h3>
        <div className="space-y-3">
          <div className="flex items-center justify-between p-4 bg-dark-700/50 rounded-lg">
            <div>
              <div className="font-medium text-gray-200">Member Invitations</div>
              <div className="text-sm text-gray-400">Allow team members to invite others</div>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input type="checkbox" className="sr-only peer" />
              <div className="w-11 h-6 bg-dark-600 peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-primary-500 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary-500"></div>
            </label>
          </div>

          <div className="flex items-center justify-between p-4 bg-dark-700/50 rounded-lg">
            <div>
              <div className="font-medium text-gray-200">Resource Access</div>
              <div className="text-sm text-gray-400">Allow members to access all resources</div>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input type="checkbox" className="sr-only peer" defaultChecked />
              <div className="w-11 h-6 bg-dark-600 peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-primary-500 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary-500"></div>
            </label>
          </div>
        </div>
      </div>
    </div>
  );
}