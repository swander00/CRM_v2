import React from 'react';
import { Building2, MapPin, Globe, Phone, Mail, FileText, Upload } from 'lucide-react';

export default function CompanySettings() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-semibold text-gray-100">Company Settings</h2>
        <button className="btn-primary">Save Changes</button>
      </div>

      {/* Company Logo */}
      <div className="flex items-center gap-6">
        <div className="relative">
          <div className="w-24 h-24 rounded-lg bg-primary-500/10 flex items-center justify-center text-primary-400">
            <Building2 className="w-12 h-12" />
          </div>
          <button className="absolute bottom-0 right-0 p-2 bg-dark-700 rounded-full border border-dark-600 text-gray-400 hover:text-gray-300">
            <Upload className="w-4 h-4" />
          </button>
        </div>
        <div>
          <h3 className="font-medium text-gray-200">Company Logo</h3>
          <p className="text-sm text-gray-400">Upload your company logo</p>
        </div>
      </div>

      {/* Basic Information */}
      <div className="space-y-4">
        <h3 className="text-sm font-medium text-gray-400">Basic Information</h3>
        
        <div>
          <label className="block text-sm font-medium text-gray-400 mb-2">
            Company Name
          </label>
          <input
            type="text"
            defaultValue="Real Estate Pro"
            className="w-full px-4 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-400 mb-2">
            Website
          </label>
          <div className="relative">
            <Globe className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="url"
              defaultValue="https://www.realestatepro.com"
              className="w-full pl-10 pr-4 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200"
            />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-400 mb-2">
              Phone Number
            </label>
            <div className="relative">
              <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="tel"
                defaultValue="+1 (555) 123-4567"
                className="w-full pl-10 pr-4 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200"
              />
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-400 mb-2">
              Email Address
            </label>
            <div className="relative">
              <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="email"
                defaultValue="contact@realestatepro.com"
                className="w-full pl-10 pr-4 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Address */}
      <div className="space-y-4 pt-6 border-t border-dark-700">
        <h3 className="text-sm font-medium text-gray-400">Address</h3>
        
        <div>
          <label className="block text-sm font-medium text-gray-400 mb-2">
            Street Address
          </label>
          <div className="relative">
            <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="text"
              defaultValue="123 Business Ave, Suite 100"
              className="w-full pl-10 pr-4 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200"
            />
          </div>
        </div>

        <div className="grid grid-cols-3 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-400 mb-2">
              City
            </label>
            <input
              type="text"
              defaultValue="Los Angeles"
              className="w-full px-4 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-400 mb-2">
              State
            </label>
            <input
              type="text"
              defaultValue="California"
              className="w-full px-4 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-400 mb-2">
              ZIP Code
            </label>
            <input
              type="text"
              defaultValue="90012"
              className="w-full px-4 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200"
            />
          </div>
        </div>
      </div>

      {/* Business Information */}
      <div className="space-y-4 pt-6 border-t border-dark-700">
        <h3 className="text-sm font-medium text-gray-400">Business Information</h3>
        
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-400 mb-2">
              Tax ID / EIN
            </label>
            <input
              type="text"
              defaultValue="12-3456789"
              className="w-full px-4 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-400 mb-2">
              Business License
            </label>
            <input
              type="text"
              defaultValue="BL-987654321"
              className="w-full px-4 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200"
            />
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-400 mb-2">
            Company Description
          </label>
          <textarea
            rows={4}
            defaultValue="Leading real estate agency specializing in luxury properties and commercial real estate..."
            className="w-full px-4 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200 resize-none"
          />
        </div>
      </div>

      {/* Legal Documents */}
      <div className="space-y-4 pt-6 border-t border-dark-700">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-medium text-gray-400">Legal Documents</h3>
          <button className="text-sm text-primary-400 hover:text-primary-300 flex items-center gap-2">
            <Upload className="w-4 h-4" />
            Upload Document
          </button>
        </div>
        
        <div className="space-y-2">
          <div className="flex items-center justify-between p-3 bg-dark-700/50 rounded-lg">
            <div className="flex items-center gap-3">
              <FileText className="w-5 h-5 text-primary-400" />
              <div>
                <div className="text-sm font-medium text-gray-200">Business License</div>
                <div className="text-xs text-gray-400">PDF • 2.4 MB • Uploaded 3 months ago</div>
              </div>
            </div>
            <button className="text-sm text-red-400 hover:text-red-300">Remove</button>
          </div>
        </div>
      </div>
    </div>
  );
}