import React from 'react';
import { Mail, Settings, RefreshCw, Key } from 'lucide-react';

export default function EmailSettings() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-semibold text-gray-100">Email Settings</h2>
        <button className="btn-primary">Save Changes</button>
      </div>

      {/* SMTP Configuration */}
      <div className="space-y-4">
        <h3 className="text-sm font-medium text-gray-400">SMTP Configuration</h3>
        <div className="space-y-4 p-4 bg-dark-700/50 rounded-lg">
          <div>
            <label className="block text-sm text-gray-400 mb-2">SMTP Server</label>
            <input
              type="text"
              defaultValue="smtp.gmail.com"
              className="w-full px-4 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200"
            />
          </div>
          <div>
            <label className="block text-sm text-gray-400 mb-2">Port</label>
            <input
              type="number"
              defaultValue="587"
              className="w-full px-4 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200"
            />
          </div>
          <div>
            <label className="block text-sm text-gray-400 mb-2">Username</label>
            <input
              type="text"
              defaultValue="your-email@gmail.com"
              className="w-full px-4 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200"
            />
          </div>
          <div>
            <label className="block text-sm text-gray-400 mb-2">Password</label>
            <input
              type="password"
              className="w-full px-4 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200"
            />
          </div>
          <div className="flex items-center gap-2">
            <input type="checkbox" className="rounded border-dark-600" defaultChecked />
            <label className="text-sm text-gray-400">Use SSL/TLS</label>
          </div>
        </div>
      </div>

      {/* Email Templates */}
      <div className="space-y-4 pt-6 border-t border-dark-700">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-medium text-gray-400">Email Templates</h3>
          <button className="text-sm text-primary-400 hover:text-primary-300">Manage Templates</button>
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div className="p-4 bg-dark-700/50 rounded-lg">
            <div className="flex items-center gap-2 mb-2">
              <Mail className="w-4 h-4 text-primary-400" />
              <h4 className="font-medium text-gray-200">Welcome Email</h4>
            </div>
            <p className="text-sm text-gray-400">Sent to new leads when they register</p>
          </div>
          <div className="p-4 bg-dark-700/50 rounded-lg">
            <div className="flex items-center gap-2 mb-2">
              <Mail className="w-4 h-4 text-primary-400" />
              <h4 className="font-medium text-gray-200">Property Update</h4>
            </div>
            <p className="text-sm text-gray-400">Sent when property details are updated</p>
          </div>
        </div>
      </div>

      {/* Email Signature */}
      <div className="space-y-4 pt-6 border-t border-dark-700">
        <h3 className="text-sm font-medium text-gray-400">Email Signature</h3>
        <div className="p-4 bg-dark-700/50 rounded-lg">
          <textarea
            rows={4}
            defaultValue="Best regards,&#10;John Doe&#10;Real Estate Professional&#10;+1 (555) 123-4567"
            className="w-full px-4 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200 resize-none"
          />
        </div>
      </div>

      {/* Test Configuration */}
      <div className="flex items-center justify-between pt-6 border-t border-dark-700">
        <div>
          <h3 className="font-medium text-gray-200">Test Configuration</h3>
          <p className="text-sm text-gray-400">Send a test email to verify settings</p>
        </div>
        <button className="btn-secondary flex items-center gap-2">
          <Mail className="w-4 h-4" />
          Send Test Email
        </button>
      </div>
    </div>
  );
}