import React from 'react';
import { Globe, Link, Check, AlertCircle } from 'lucide-react';

export default function IntegrationSettings() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-semibold text-gray-100">Integration Settings</h2>
        <button className="btn-primary">Save Changes</button>
      </div>

      {/* API Keys */}
      <div className="space-y-4">
        <h3 className="text-sm font-medium text-gray-400">API Keys</h3>
        <div className="space-y-4 p-4 bg-dark-700/50 rounded-lg">
          <div>
            <label className="block text-sm text-gray-400 mb-2">API Key</label>
            <div className="flex gap-2">
              <input
                type="password"
                defaultValue="sk_test_123456789"
                className="flex-1 px-4 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200"
              />
              <button className="btn-secondary">Regenerate</button>
            </div>
          </div>
          <div>
            <label className="block text-sm text-gray-400 mb-2">API Secret</label>
            <div className="flex gap-2">
              <input
                type="password"
                defaultValue="sk_secret_987654321"
                className="flex-1 px-4 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200"
              />
              <button className="btn-secondary">Regenerate</button>
            </div>
          </div>
        </div>
      </div>

      {/* Connected Services */}
      <div className="space-y-4 pt-6 border-t border-dark-700">
        <h3 className="text-sm font-medium text-gray-400">Connected Services</h3>
        <div className="space-y-3">
          <div className="flex items-center justify-between p-4 bg-dark-700/50 rounded-lg">
            <div className="flex items-center gap-3">
              <img src="/google-calendar.svg" alt="Google Calendar" className="w-6 h-6" />
              <div>
                <div className="font-medium text-gray-200">Google Calendar</div>
                <div className="text-sm text-gray-400">Calendar sync enabled</div>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <span className="flex items-center gap-1 text-green-400 text-sm">
                <Check className="w-4 h-4" />
                Connected
              </span>
              <button className="btn-secondary text-sm">Configure</button>
            </div>
          </div>

          <div className="flex items-center justify-between p-4 bg-dark-700/50 rounded-lg">
            <div className="flex items-center gap-3">
              <img src="/dropbox.svg" alt="Dropbox" className="w-6 h-6" />
              <div>
                <div className="font-medium text-gray-200">Dropbox</div>
                <div className="text-sm text-gray-400">File storage integration</div>
              </div>
            </div>
            <button className="btn-primary text-sm">Connect</button>
          </div>

          <div className="flex items-center justify-between p-4 bg-dark-700/50 rounded-lg">
            <div className="flex items-center gap-3">
              <img src="/zapier.svg" alt="Zapier" className="w-6 h-6" />
              <div>
                <div className="font-medium text-gray-200">Zapier</div>
                <div className="text-sm text-gray-400">Workflow automation</div>
              </div>
            </div>
            <button className="btn-primary text-sm">Connect</button>
          </div>
        </div>
      </div>

      {/* Webhooks */}
      <div className="space-y-4 pt-6 border-t border-dark-700">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-medium text-gray-400">Webhooks</h3>
          <button className="text-sm text-primary-400 hover:text-primary-300">Add Webhook</button>
        </div>
        <div className="space-y-3">
          <div className="p-4 bg-dark-700/50 rounded-lg">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <Link className="w-4 h-4 text-primary-400" />
                <h4 className="font-medium text-gray-200">Lead Created</h4>
              </div>
              <span className="px-2 py-1 bg-green-500/10 text-green-400 text-xs rounded-full">Active</span>
            </div>
            <p className="text-sm text-gray-400 mb-3">https://api.example.com/webhooks/leads</p>
            <div className="flex items-center gap-2">
              <button className="text-sm text-gray-400 hover:text-gray-300">Edit</button>
              <button className="text-sm text-red-400 hover:text-red-300">Delete</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}