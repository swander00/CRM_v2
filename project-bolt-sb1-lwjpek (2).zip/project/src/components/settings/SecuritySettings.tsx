import React from 'react';
import { Key, Shield, Smartphone, History } from 'lucide-react';

export default function SecuritySettings() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-semibold text-gray-100">Security Settings</h2>
        <button className="btn-primary">Save Changes</button>
      </div>

      {/* Password Settings */}
      <div className="space-y-4">
        <h3 className="text-sm font-medium text-gray-400">Password</h3>
        <div className="space-y-4 p-4 bg-dark-700/50 rounded-lg">
          <div>
            <label className="block text-sm text-gray-400 mb-2">Current Password</label>
            <input
              type="password"
              className="w-full px-4 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200"
            />
          </div>
          <div>
            <label className="block text-sm text-gray-400 mb-2">New Password</label>
            <input
              type="password"
              className="w-full px-4 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200"
            />
          </div>
          <div>
            <label className="block text-sm text-gray-400 mb-2">Confirm New Password</label>
            <input
              type="password"
              className="w-full px-4 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200"
            />
          </div>
        </div>
      </div>

      {/* Two-Factor Authentication */}
      <div className="space-y-4 pt-6 border-t border-dark-700">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Shield className="w-5 h-5 text-primary-400" />
            <div>
              <h3 className="font-medium text-gray-200">Two-Factor Authentication</h3>
              <p className="text-sm text-gray-400">Add an extra layer of security to your account</p>
            </div>
          </div>
          <button className="btn-secondary">Enable 2FA</button>
        </div>
      </div>

      {/* Login Sessions */}
      <div className="space-y-4 pt-6 border-t border-dark-700">
        <h3 className="text-sm font-medium text-gray-400">Active Sessions</h3>
        <div className="space-y-3">
          <div className="flex items-center justify-between p-4 bg-dark-700/50 rounded-lg">
            <div className="flex items-center gap-3">
              <Smartphone className="w-5 h-5 text-primary-400" />
              <div>
                <div className="font-medium text-gray-200">iPhone 13 Pro - Los Angeles</div>
                <div className="text-sm text-gray-400">Last active: 2 minutes ago</div>
              </div>
            </div>
            <button className="text-sm text-red-400 hover:text-red-300">
              Revoke Access
            </button>
          </div>
        </div>
      </div>

      {/* Login History */}
      <div className="space-y-4 pt-6 border-t border-dark-700">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-medium text-gray-400">Login History</h3>
          <button className="text-sm text-primary-400 hover:text-primary-300">View All</button>
        </div>
        <div className="space-y-3">
          <div className="flex items-center gap-3 p-4 bg-dark-700/50 rounded-lg">
            <History className="w-5 h-5 text-primary-400" />
            <div>
              <div className="font-medium text-gray-200">Los Angeles, CA</div>
              <div className="text-sm text-gray-400">Today, 2:30 PM</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}