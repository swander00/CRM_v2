import React from 'react';
import { Camera, Mail, Phone, MapPin } from 'lucide-react';

export default function ProfileSettings() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-semibold text-gray-100">Profile Settings</h2>
        <button className="btn-primary">Save Changes</button>
      </div>

      {/* Profile Picture */}
      <div className="flex items-center gap-6">
        <div className="relative">
          <div className="w-24 h-24 rounded-full bg-primary-500/10 flex items-center justify-center text-primary-400 text-2xl font-semibold">
            JD
          </div>
          <button className="absolute bottom-0 right-0 p-2 bg-dark-700 rounded-full border border-dark-600 text-gray-400 hover:text-gray-300">
            <Camera className="w-4 h-4" />
          </button>
        </div>
        <div>
          <h3 className="font-medium text-gray-200">Profile Picture</h3>
          <p className="text-sm text-gray-400">Upload a new profile picture</p>
        </div>
      </div>

      {/* Personal Information */}
      <div className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-400 mb-2">
              First Name
            </label>
            <input
              type="text"
              defaultValue="John"
              className="w-full px-4 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-400 mb-2">
              Last Name
            </label>
            <input
              type="text"
              defaultValue="Doe"
              className="w-full px-4 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200"
            />
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-400 mb-2">
            Email Address
          </label>
          <div className="flex items-center gap-2">
            <div className="relative flex-1">
              <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="email"
                defaultValue="john.doe@example.com"
                className="w-full pl-10 pr-4 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200"
              />
            </div>
            <button className="btn-secondary">Verify</button>
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-400 mb-2">
            Phone Number
          </label>
          <div className="relative">
            <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="tel"
              defaultValue="+1 (555) 123-4567"
              className="w-full pl-10 pr-4 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200"
            />
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-400 mb-2">
            Office Location
          </label>
          <div className="relative">
            <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="text"
              defaultValue="123 Main St, Los Angeles, CA 90012"
              className="w-full pl-10 pr-4 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200"
            />
          </div>
        </div>
      </div>

      {/* Professional Information */}
      <div className="pt-6 border-t border-dark-700">
        <h3 className="text-sm font-medium text-gray-400 mb-4">Professional Information</h3>
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-400 mb-2">
              License Number
            </label>
            <input
              type="text"
              defaultValue="CA-12345678"
              className="w-full px-4 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-400 mb-2">
              Specializations
            </label>
            <select multiple className="w-full px-4 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200">
              <option>Residential Sales</option>
              <option>Luxury Properties</option>
              <option>Commercial Real Estate</option>
              <option>Property Management</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-400 mb-2">
              Bio
            </label>
            <textarea
              rows={4}
              defaultValue="Experienced real estate agent specializing in luxury properties and commercial real estate..."
              className="w-full px-4 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200 resize-none"
            />
          </div>
        </div>
      </div>
    </div>
  );
}