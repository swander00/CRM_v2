import React from 'react';
import { MessageSquare, Settings, RefreshCw, Key } from 'lucide-react';

export default function SMSSettings() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-semibold text-gray-100">SMS Settings</h2>
        <button className="btn-primary">Save Changes</button>
      </div>

      {/* SMS Provider */}
      <div className="space-y-4">
        <h3 className="text-sm font-medium text-gray-400">SMS Provider</h3>
        <div className="space-y-4 p-4 bg-dark-700/50 rounded-lg">
          <div>
            <label className="block text-sm text-gray-400 mb-2">Provider</label>
            <select className="w-full px-4 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200">
              <option>Twilio</option>
              <option>MessageBird</option>
              <option>Nexmo</option>
            </select>
          </div>
          <div>
            <label className="block text-sm text-gray-400 mb-2">Account SID</label>
            <input
              type="text"
              className="w-full px-4 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200"
            />
          </div>
          <div>
            <label className="block text-sm text-gray-400 mb-2">Auth Token</label>
            <input
              type="password"
              className="w-full px-4 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200"
            />
          </div>
          <div>
            <label className="block text-sm text-gray-400 mb-2">From Number</label>
            <input
              type="text"
              className="w-full px-4 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200"
              placeholder="+1234567890"
            />
          </div>
        </div>
      </div>

      {/* SMS Templates */}
      <div className="space-y-4 pt-6 border-t border-dark-700">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-medium text-gray-400">SMS Templates</h3>
          <button className="text-sm text-primary-400 hover:text-primary-300">Manage Templates</button>
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div className="p-4 bg-dark-700/50 rounded-lg">
            <div className="flex items-center gap-2 mb-2">
              <MessageSquare className="w-4 h-4 text-primary-400" />
              <h4 className="font-medium text-gray-200">Viewing Confirmation</h4>
            </div>
            <p className="text-sm text-gray-400">Sent to confirm property viewings</p>
          </div>
          <div className="p-4 bg-dark-700/50 rounded-lg">
            <div className="flex items-center gap-2 mb-2">
              <MessageSquare className="w-4 h-4 text-primary-400" />
              <h4 className="font-medium text-gray-200">Follow-up</h4>
            </div>
            <p className="text-sm text-gray-400">Sent after property viewings</p>
          </div>
        </div>
      </div>

      {/* SMS Limits */}
      <div className="space-y-4 pt-6 border-t border-dark-700">
        <h3 className="text-sm font-medium text-gray-400">SMS Limits</h3>
        <div className="grid grid-cols-2 gap-4">
          <div className="p-4 bg-dark-700/50 rounded-lg">
            <label className="block text-sm text-gray-400 mb-2">Daily Limit</label>
            <input
              type="number"
              defaultValue="100"
              className="w-full px-4 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200"
            />
          </div>
          <div className="p-4 bg-dark-700/50 rounded-lg">
            <label className="block text-sm text-gray-400 mb-2">Monthly Limit</label>
            <input
              type="number"
              defaultValue="3000"
              className="w-full px-4 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200"
            />
          </div>
        </div>
      </div>

      {/* Test Configuration */}
      <div className="flex items-center justify-between pt-6 border-t border-dark-700">
        <div>
          <h3 className="font-medium text-gray-200">Test Configuration</h3>
          <p className="text-sm text-gray-400">Send a test SMS to verify settings</p>
        </div>
        <button className="btn-secondary flex items-center gap-2">
          <MessageSquare className="w-4 h-4" />
          Send Test SMS
        </button>
      </div>
    </div>
  );
}