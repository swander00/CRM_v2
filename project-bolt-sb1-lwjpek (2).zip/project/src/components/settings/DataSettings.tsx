import React from 'react';
import { Database, Download, Upload, Trash2, AlertCircle } from 'lucide-react';

export default function DataSettings() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-semibold text-gray-100">Data Management</h2>
        <button className="btn-primary">Save Changes</button>
      </div>

      {/* Data Export */}
      <div className="space-y-4">
        <h3 className="text-sm font-medium text-gray-400">Data Export</h3>
        <div className="p-4 bg-dark-700/50 rounded-lg">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h4 className="font-medium text-gray-200">Export Data</h4>
              <p className="text-sm text-gray-400">Download all your data in CSV format</p>
            </div>
            <button className="btn-secondary flex items-center gap-2">
              <Download className="w-4 h-4" />
              Export
            </button>
          </div>
          <div className="space-y-2">
            <label className="flex items-center gap-2">
              <input type="checkbox" className="rounded border-dark-600" defaultChecked />
              <span className="text-sm text-gray-400">Leads</span>
            </label>
            <label className="flex items-center gap-2">
              <input type="checkbox" className="rounded border-dark-600" defaultChecked />
              <span className="text-sm text-gray-400">Properties</span>
            </label>
            <label className="flex items-center gap-2">
              <input type="checkbox" className="rounded border-dark-600" defaultChecked />
              <span className="text-sm text-gray-400">Communications</span>
            </label>
          </div>
        </div>
      </div>

      {/* Data Import */}
      <div className="space-y-4 pt-6 border-t border-dark-700">
        <h3 className="text-sm font-medium text-gray-400">Data Import</h3>
        <div className="p-4 bg-dark-700/50 rounded-lg">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h4 className="font-medium text-gray-200">Import Data</h4>
              <p className="text-sm text-gray-400">Import data from CSV files</p>
            </div>
            <button className="btn-secondary flex items-center gap-2">
              <Upload className="w-4 h-4" />
              Import
            </button>
          </div>
          <div className="text-sm text-gray-400">
            Supported formats: CSV, Excel (.xlsx)
          </div>
        </div>
      </div>

      {/* Data Retention */}
      <div className="space-y-4 pt-6 border-t border-dark-700">
        <h3 className="text-sm font-medium text-gray-400">Data Retention</h3>
        <div className="space-y-4">
          <div className="flex items-center justify-between p-4 bg-dark-700/50 rounded-lg">
            <div>
              <h4 className="font-medium text-gray-200">Archive Old Data</h4>
              <p className="text-sm text-gray-400">Automatically archive data older than:</p>
            </div>
            <select className="bg-dark-700 border border-dark-600 rounded-lg px-3 py-2 text-gray-200">
              <option>6 months</option>
              <option>1 year</option>
              <option>2 years</option>
              <option>Never</option>
            </select>
          </div>
        </div>
      </div>

      {/* Database Backup */}
      <div className="space-y-4 pt-6 border-t border-dark-700">
        <h3 className="text-sm font-medium text-gray-400">Database Backup</h3>
        <div className="p-4 bg-dark-700/50 rounded-lg">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h4 className="font-medium text-gray-200">Automatic Backups</h4>
              <p className="text-sm text-gray-400">Configure automatic database backups</p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input type="checkbox" className="sr-only peer" defaultChecked />
              <div className="w-11 h-6 bg-dark-600 peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-primary-500 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary-500"></div>
            </label>
          </div>
          <div className="space-y-3">
            <div>
              <label className="block text-sm text-gray-400 mb-2">Backup Frequency</label>
              <select className="w-full px-4 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200">
                <option>Daily</option>
                <option>Weekly</option>
                <option>Monthly</option>
              </select>
            </div>
            <div>
              <label className="block text-sm text-gray-400 mb-2">Retention Period</label>
              <select className="w-full px-4 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200">
                <option>30 days</option>
                <option>60 days</option>
                <option>90 days</option>
              </select>
            </div>
          </div>
        </div>
      </div>

      {/* Danger Zone */}
      <div className="space-y-4 pt-6 border-t border-dark-700">
        <div className="flex items-center gap-2">
          <AlertCircle className="w-5 h-5 text-red-400" />
          <h3 className="text-sm font-medium text-red-400">Danger Zone</h3>
        </div>
        <div className="p-4 bg-red-500/10 border border-red-500/20 rounded-lg">
          <div className="flex items-center justify-between">
            <div>
              <h4 className="font-medium text-red-400">Delete All Data</h4>
              <p className="text-sm text-gray-400">Permanently delete all data from the system</p>
            </div>
            <button className="flex items-center gap-2 px-4 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600">
              <Trash2 className="w-4 h-4" />
              Delete All Data
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}