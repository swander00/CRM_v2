import React, { useState } from 'react';
import { 
  PenSquare, 
  Inbox, 
  Send, 
  Archive, 
  Trash2, 
  Star,
  Phone,
  MessageSquare,
  FileText,
  Tag
} from 'lucide-react';

interface CommunicationsSidebarProps {
  onCompose: () => void;
}

const folders = [
  { id: 'inbox', icon: Inbox, label: 'Inbox', count: 12, color: 'text-blue-400' },
  { id: 'sent', icon: Send, label: 'Sent', count: 48, color: 'text-green-400' },
  { id: 'starred', icon: Star, label: 'Starred', count: 6, color: 'text-yellow-400' },
  { id: 'archived', icon: Archive, label: 'Archived', count: 124, color: 'text-gray-400' },
  { id: 'trash', icon: Trash2, label: 'Trash', count: 8, color: 'text-red-400' }
];

const channels = [
  { id: 'calls', icon: Phone, label: 'Calls', count: 15, color: 'text-purple-400' },
  { id: 'sms', icon: MessageSquare, label: 'SMS', count: 34, color: 'text-pink-400' },
  { id: 'templates', icon: FileText, label: 'Templates', count: 12, color: 'text-indigo-400' }
];

const labels = [
  { id: 'leads', icon: Tag, label: 'Leads', color: 'text-green-400' },
  { id: 'important', icon: Tag, label: 'Important', color: 'text-red-400' },
  { id: 'follow-up', icon: Tag, label: 'Follow-up', color: 'text-yellow-400' },
  { id: 'personal', icon: Tag, label: 'Personal', color: 'text-blue-400' }
];

export default function CommunicationsSidebar({ onCompose }: CommunicationsSidebarProps) {
  const [activeFolder, setActiveFolder] = useState('inbox');
  const [activeChannel, setActiveChannel] = useState<string | null>(null);
  const [activeLabel, setActiveLabel] = useState<string | null>(null);
  const [selectedLabels, setSelectedLabels] = useState<string[]>([]);

  const handleFolderClick = (folderId: string) => {
    setActiveFolder(folderId);
    setActiveChannel(null);
    setActiveLabel(null);
  };

  const handleChannelClick = (channelId: string) => {
    setActiveChannel(channelId);
    setActiveFolder('');
    setActiveLabel(null);
  };

  const handleLabelClick = (labelId: string) => {
    setSelectedLabels(prev => {
      if (prev.includes(labelId)) {
        return prev.filter(id => id !== labelId);
      }
      return [...prev, labelId];
    });
    setActiveLabel(labelId);
    setActiveFolder('');
    setActiveChannel(null);
  };

  return (
    <div className="w-64 border-r border-dark-700 p-4">
      <button
        onClick={onCompose}
        className="w-full btn-primary flex items-center justify-center gap-2 mb-6"
      >
        <PenSquare className="w-4 h-4" />
        Compose
      </button>

      <div className="space-y-6">
        {/* Folders Section */}
        <div>
          <h3 className="text-xs font-medium text-gray-400 uppercase mb-2">Folders</h3>
          <nav className="space-y-1">
            {folders.map((folder) => (
              <button
                key={folder.id}
                onClick={() => handleFolderClick(folder.id)}
                className={`w-full flex items-center justify-between px-3 py-2 rounded-lg transition-colors ${
                  activeFolder === folder.id
                    ? 'bg-primary-500/10 text-primary-400'
                    : 'text-gray-400 hover:bg-dark-700 hover:text-gray-300'
                }`}
              >
                <div className="flex items-center gap-3">
                  <folder.icon className={`w-4 h-4 ${folder.color}`} />
                  <span>{folder.label}</span>
                </div>
                <span className={`text-xs px-2 py-1 rounded-full ${
                  activeFolder === folder.id
                    ? 'bg-primary-500/20'
                    : 'bg-dark-700'
                }`}>
                  {folder.count}
                </span>
              </button>
            ))}
          </nav>
        </div>

        {/* Channels Section */}
        <div>
          <h3 className="text-xs font-medium text-gray-400 uppercase mb-2">Channels</h3>
          <nav className="space-y-1">
            {channels.map((channel) => (
              <button
                key={channel.id}
                onClick={() => handleChannelClick(channel.id)}
                className={`w-full flex items-center justify-between px-3 py-2 rounded-lg transition-colors ${
                  activeChannel === channel.id
                    ? 'bg-primary-500/10 text-primary-400'
                    : 'text-gray-400 hover:bg-dark-700 hover:text-gray-300'
                }`}
              >
                <div className="flex items-center gap-3">
                  <channel.icon className={`w-4 h-4 ${channel.color}`} />
                  <span>{channel.label}</span>
                </div>
                <span className={`text-xs px-2 py-1 rounded-full ${
                  activeChannel === channel.id
                    ? 'bg-primary-500/20'
                    : 'bg-dark-700'
                }`}>
                  {channel.count}
                </span>
              </button>
            ))}
          </nav>
        </div>

        {/* Labels Section */}
        <div>
          <h3 className="text-xs font-medium text-gray-400 uppercase mb-2">Labels</h3>
          <nav className="space-y-1">
            {labels.map((label) => (
              <button
                key={label.id}
                onClick={() => handleLabelClick(label.id)}
                className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg transition-colors ${
                  selectedLabels.includes(label.id)
                    ? 'bg-primary-500/10 text-primary-400'
                    : 'text-gray-400 hover:bg-dark-700 hover:text-gray-300'
                }`}
              >
                <label.icon className={`w-4 h-4 ${label.color}`} />
                <span>{label.label}</span>
              </button>
            ))}
          </nav>
        </div>
      </div>
    </div>
  );
}