import React, { useState } from 'react';
import { Search, Filter, Star, Paperclip, MoreHorizontal } from 'lucide-react';
import { format } from 'date-fns';

interface EmailListProps {
  onEmailSelect: (email: any) => void;
}

const mockEmails = [
  {
    id: 1,
    from: 'John Smith',
    subject: 'Property Viewing Confirmation',
    preview: 'I would like to confirm our appointment for...',
    date: new Date(),
    isStarred: true,
    hasAttachment: true,
    isRead: false,
    avatar: 'JS'
  },
  {
    id: 2,
    from: 'Emma Davis',
    subject: 'Questions about 123 Main Street',
    preview: 'Hi, I was wondering about the square footage...',
    date: new Date(Date.now() - 86400000),
    isStarred: false,
    hasAttachment: false,
    isRead: true,
    avatar: 'ED'
  }
];

export default function EmailList({ onEmailSelect }: EmailListProps) {
  const [selectedEmails, setSelectedEmails] = useState<number[]>([]);

  const toggleEmailSelection = (id: number) => {
    setSelectedEmails(prev => 
      prev.includes(id) 
        ? prev.filter(emailId => emailId !== id)
        : [...prev, id]
    );
  };

  return (
    <div className="flex-1 flex flex-col">
      <div className="p-4 border-b border-dark-700">
        <div className="flex items-center gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <input
              type="text"
              placeholder="Search emails..."
              className="w-full pl-9 pr-4 py-2 bg-dark-700 border border-dark-600 rounded-lg text-sm text-gray-200 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-primary-500"
            />
          </div>
          <button className="btn-secondary flex items-center gap-2">
            <Filter className="w-4 h-4" />
            Filter
          </button>
        </div>
      </div>

      <div className="flex-1 overflow-auto">
        {mockEmails.map((email) => (
          <div
            key={email.id}
            className={`group flex items-center gap-4 p-4 border-b border-dark-700 hover:bg-dark-700/50 cursor-pointer ${
              !email.isRead ? 'bg-dark-700/30' : ''
            }`}
            onClick={() => onEmailSelect(email)}
          >
            <div className="flex items-center gap-3">
              <input
                type="checkbox"
                checked={selectedEmails.includes(email.id)}
                onChange={(e) => {
                  e.stopPropagation();
                  toggleEmailSelection(email.id);
                }}
                className="rounded border-dark-600"
              />
              <button 
                onClick={(e) => {
                  e.stopPropagation();
                  // Toggle star
                }}
                className={`text-gray-400 hover:text-yellow-400 ${
                  email.isStarred ? 'text-yellow-400' : ''
                }`}
              >
                <Star className="w-4 h-4" />
              </button>
            </div>

            <div className="w-8 h-8 rounded-full bg-primary-500/10 flex items-center justify-center text-sm font-medium text-primary-400">
              {email.avatar}
            </div>

            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between mb-1">
                <span className={`font-medium ${!email.isRead ? 'text-gray-200' : 'text-gray-400'}`}>
                  {email.from}
                </span>
                <span className="text-sm text-gray-400">
                  {format(email.date, 'MMM dd')}
                </span>
              </div>
              <h4 className={`text-sm mb-1 ${!email.isRead ? 'text-gray-200' : 'text-gray-400'}`}>
                {email.subject}
              </h4>
              <p className="text-sm text-gray-500 truncate">
                {email.preview}
              </p>
            </div>

            <div className="flex items-center gap-2 text-gray-400">
              {email.hasAttachment && (
                <Paperclip className="w-4 h-4" />
              )}
              <button className="opacity-0 group-hover:opacity-100 transition-opacity">
                <MoreHorizontal className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}