import React, { useState } from 'react';
import { X, Paperclip, Image, Link2, ChevronDown } from 'lucide-react';

interface EmailComposerProps {
  onCancel: () => void;
}

export default function EmailComposer({ onCancel }: EmailComposerProps) {
  const [showTemplates, setShowTemplates] = useState(false);

  return (
    <div className="flex-1 flex flex-col p-4">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-semibold text-gray-100">New Message</h2>
        <button onClick={onCancel} className="text-gray-400 hover:text-gray-300">
          <X className="w-5 h-5" />
        </button>
      </div>

      <div className="flex-1 flex flex-col">
        <div className="space-y-4 mb-4">
          <div>
            <input
              type="text"
              placeholder="To"
              className="w-full px-4 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-primary-500"
            />
          </div>

          <div>
            <input
              type="text"
              placeholder="Subject"
              className="w-full px-4 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-primary-500"
            />
          </div>

          <div className="relative">
            <button
              onClick={() => setShowTemplates(!showTemplates)}
              className="w-full flex items-center justify-between px-4 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-400 hover:text-gray-300"
            >
              <span>Select Template</span>
              <ChevronDown className="w-4 h-4" />
            </button>

            {showTemplates && (
              <div className="absolute top-full left-0 right-0 mt-1 bg-dark-700 border border-dark-600 rounded-lg shadow-lg z-10">
                <div className="p-2">
                  <button className="w-full text-left px-3 py-2 rounded hover:bg-dark-600 text-gray-300">
                    Property Viewing Confirmation
                  </button>
                  <button className="w-full text-left px-3 py-2 rounded hover:bg-dark-600 text-gray-300">
                    Follow-up Email
                  </button>
                  <button className="w-full text-left px-3 py-2 rounded hover:bg-dark-600 text-gray-300">
                    Welcome Message
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>

        <div className="flex-1">
          <textarea
            placeholder="Write your message..."
            className="w-full h-full px-4 py-3 bg-dark-700 border border-dark-600 rounded-lg text-gray-200 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-primary-500 resize-none"
          />
        </div>

        <div className="flex items-center justify-between mt-4 pt-4 border-t border-dark-700">
          <div className="flex items-center gap-2">
            <button className="p-2 text-gray-400 hover:text-gray-300 hover:bg-dark-700 rounded">
              <Paperclip className="w-4 h-4" />
            </button>
            <button className="p-2 text-gray-400 hover:text-gray-300 hover:bg-dark-700 rounded">
              <Image className="w-4 h-4" />
            </button>
            <button className="p-2 text-gray-400 hover:text-gray-300 hover:bg-dark-700 rounded">
              <Link2 className="w-4 h-4" />
            </button>
          </div>

          <div className="flex items-center gap-2">
            <button className="btn-secondary">
              Save as Draft
            </button>
            <button className="btn-primary">
              Send Message
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}