import React from 'react';
import { ArrowLeft, Star, Reply, Forward, MoreHorizontal, Download, Paperclip } from 'lucide-react';
import { format } from 'date-fns';

interface EmailViewProps {
  email: any;
  onBack: () => void;
}

export default function EmailView({ email, onBack }: EmailViewProps) {
  return (
    <div className="flex-1 flex flex-col">
      <div className="flex items-center justify-between p-4 border-b border-dark-700">
        <div className="flex items-center gap-4">
          <button onClick={onBack} className="text-gray-400 hover:text-gray-300">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h2 className="text-lg font-semibold text-gray-100">{email.subject}</h2>
        </div>
        <div className="flex items-center gap-2">
          <button className="text-gray-400 hover:text-gray-300">
            <Star className="w-5 h-5" />
          </button>
          <button className="text-gray-400 hover:text-gray-300">
            <MoreHorizontal className="w-5 h-5" />
          </button>
        </div>
      </div>

      <div className="flex-1 overflow-auto p-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-4">
            <div className="w-10 h-10 rounded-full bg-primary-500/10 flex items-center justify-center text-primary-400 font-medium">
              {email.avatar}
            </div>
            <div>
              <div className="font-medium text-gray-200">{email.from}</div>
              <div className="text-sm text-gray-400">
                {format(email.date, 'MMM dd, yyyy h:mm a')}
              </div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button className="btn-secondary flex items-center gap-2">
              <Reply className="w-4 h-4" />
              Reply
            </button>
            <button className="btn-secondary flex items-center gap-2">
              <Forward className="w-4 h-4" />
              Forward
            </button>
          </div>
        </div>

        <div className="prose prose-invert max-w-none">
          <p className="text-gray-300">
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
          </p>
        </div>

        {email.hasAttachment && (
          <div className="mt-6 p-4 bg-dark-700/50 rounded-lg">
            <h4 className="text-sm font-medium text-gray-400 mb-3">Attachments</h4>
            <div className="flex items-center justify-between p-3 bg-dark-700 rounded border border-dark-600">
              <div className="flex items-center gap-3">
                <Paperclip className="w-4 h-4 text-primary-400" />
                <span className="text-sm text-gray-300">document.pdf</span>
                <span className="text-xs text-gray-500">2.4 MB</span>
              </div>
              <button className="text-primary-400 hover:text-primary-300">
                <Download className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}