import React from 'react';
import { formatDistanceToNow } from 'date-fns';
import { Mail, MessageSquare, Phone, Star, MoreHorizontal, MapPin, DollarSign } from 'lucide-react';

interface LeadCardProps {
  lead: {
    name: string;
    email: string;
    phone: string;
    status: string;
    lastContact: Date;
    budget: string;
    location: string;
    propertyType: string;
    priority: 'high' | 'medium' | 'low';
  };
  onSendEmail: () => void;
  onSendSMS: () => void;
}

const priorityColors = {
  high: 'text-red-500',
  medium: 'text-yellow-500',
  low: 'text-blue-500',
};

export default function LeadCard({ lead, onSendEmail, onSendSMS }: LeadCardProps) {
  return (
    <div className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow">
      <div className="flex justify-between items-start mb-4">
        <div>
          <div className="flex items-center gap-2">
            <h3 className="text-lg font-semibold text-gray-900">{lead.name}</h3>
            <Star className={`w-5 h-5 ${priorityColors[lead.priority]}`} fill="currentColor" />
          </div>
          <p className="text-sm text-gray-500 flex items-center gap-1">
            <MapPin className="w-4 h-4" /> {lead.location}
          </p>
        </div>
        <button className="text-gray-400 hover:text-gray-600">
          <MoreHorizontal className="w-5 h-5" />
        </button>
      </div>

      <div className="space-y-3 mb-4">
        <div className="flex items-center gap-2 text-sm text-gray-600">
          <Mail className="w-4 h-4" />
          <span>{lead.email}</span>
        </div>
        <div className="flex items-center gap-2 text-sm text-gray-600">
          <Phone className="w-4 h-4" />
          <span>{lead.phone}</span>
        </div>
        <div className="flex items-center gap-2 text-sm text-gray-600">
          <DollarSign className="w-4 h-4" />
          <span>Budget: {lead.budget}</span>
        </div>
      </div>

      <div className="flex items-center justify-between mb-4">
        <span className={`px-3 py-1 rounded-full text-sm ${
          lead.status === 'Hot' ? 'bg-red-100 text-red-800' :
          lead.status === 'Warm' ? 'bg-yellow-100 text-yellow-800' :
          'bg-blue-100 text-blue-800'
        }`}>
          {lead.status}
        </span>
        <span className="text-sm text-gray-500">
          Last Contact: {formatDistanceToNow(lead.lastContact, { addSuffix: true })}
        </span>
      </div>

      <div className="flex gap-2">
        <button
          onClick={onSendEmail}
          className="flex-1 flex items-center justify-center gap-2 bg-indigo-50 hover:bg-indigo-100 text-indigo-600 px-4 py-2 rounded-md transition-colors"
        >
          <Mail className="w-4 h-4" />
          <span>Email</span>
        </button>
        <button
          onClick={onSendSMS}
          className="flex-1 flex items-center justify-center gap-2 bg-green-50 hover:bg-green-100 text-green-600 px-4 py-2 rounded-md transition-colors"
        >
          <MessageSquare className="w-4 h-4" />
          <span>SMS</span>
        </button>
      </div>
    </div>
  );
}