import React from 'react';
import { Users, Flame, ThumbsUp, Snowflake, TrendingUp, TrendingDown } from 'lucide-react';

export default function LeadStats() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
      <div className="stat-card">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-gray-400">Total Leads</p>
            <p className="text-2xl font-semibold text-gray-100 mt-1">247</p>
          </div>
          <div className="p-3 bg-primary-500/10 rounded-full">
            <Users className="w-6 h-6 text-primary-400" />
          </div>
        </div>
        <div className="mt-4 flex items-center gap-1">
          <TrendingUp className="w-4 h-4 text-green-400" />
          <span className="text-sm text-green-400">12%</span>
          <span className="text-sm text-gray-400 ml-1">vs last month</span>
        </div>
      </div>

      <div className="stat-card">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-gray-400">Hot Leads</p>
            <p className="text-2xl font-semibold text-gray-100 mt-1">64</p>
          </div>
          <div className="p-3 bg-red-500/10 rounded-full">
            <Flame className="w-6 h-6 text-red-400" />
          </div>
        </div>
        <div className="mt-4 flex items-center gap-1">
          <TrendingUp className="w-4 h-4 text-green-400" />
          <span className="text-sm text-green-400">8%</span>
          <span className="text-sm text-gray-400 ml-1">vs last month</span>
        </div>
      </div>

      <div className="stat-card">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-gray-400">Warm Leads</p>
            <p className="text-2xl font-semibold text-gray-100 mt-1">98</p>
          </div>
          <div className="p-3 bg-yellow-500/10 rounded-full">
            <ThumbsUp className="w-6 h-6 text-yellow-400" />
          </div>
        </div>
        <div className="mt-4 flex items-center gap-1">
          <TrendingDown className="w-4 h-4 text-red-400" />
          <span className="text-sm text-red-400">5%</span>
          <span className="text-sm text-gray-400 ml-1">vs last month</span>
        </div>
      </div>

      <div className="stat-card">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-gray-400">Cold Leads</p>
            <p className="text-2xl font-semibold text-gray-100 mt-1">85</p>
          </div>
          <div className="p-3 bg-blue-500/10 rounded-full">
            <Snowflake className="w-6 h-6 text-blue-400" />
          </div>
        </div>
        <div className="mt-4">
          <span className="text-sm text-gray-400">No change</span>
        </div>
      </div>
    </div>
  );
}