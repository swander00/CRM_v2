import React from 'react';
import { Plus, Upload, Download } from 'lucide-react';

export default function FloatingActions() {
  return (
    <div className="fixed bottom-8 right-8 flex flex-col gap-4">
      <button className="w-12 h-12 bg-dark-800 rounded-full flex items-center justify-center text-gray-400 hover:text-gray-300 shadow-glow-sm hover:shadow-glow transition-all">
        <Download className="w-5 h-5" />
      </button>
      <button className="w-12 h-12 bg-dark-800 rounded-full flex items-center justify-center text-gray-400 hover:text-gray-300 shadow-glow-sm hover:shadow-glow transition-all">
        <Upload className="w-5 h-5" />
      </button>
      <button className="w-12 h-12 bg-primary-600 rounded-full flex items-center justify-center text-white shadow-glow hover:shadow-glow-lg transition-all">
        <Plus className="w-5 h-5" />
      </button>
    </div>
  );
}