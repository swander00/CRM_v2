import React from 'react';
import { Search, Filter, ChevronDown } from 'lucide-react';

export default function LeadFilters() {
  return (
    <div className="mb-6 space-y-4">
      <div className="flex flex-col md:flex-row gap-4">
        <div className="flex-1">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="text"
              placeholder="Search by name, phone, email, or tags..."
              className="w-full pl-10 pr-4 py-2 input-dark"
            />
          </div>
        </div>
        
        <div className="flex flex-wrap gap-4">
          <select className="input-dark px-4 py-2">
            <option value="">Pipeline Stage</option>
            <option value="new">New Lead</option>
            <option value="contacted">Contacted</option>
            <option value="qualified">Qualified</option>
            <option value="proposal">Proposal</option>
            <option value="negotiation">Negotiation</option>
            <option value="closed">Closed</option>
          </select>
          
          <select className="input-dark px-4 py-2">
            <option value="">Lead Source</option>
            <option value="website">Website</option>
            <option value="referral">Referral</option>
            <option value="google">Google Ads</option>
            <option value="social">Social Media</option>
          </select>
          
          <select className="input-dark px-4 py-2">
            <option value="">Lead Type</option>
            <option value="buyer">Buyer</option>
            <option value="seller">Seller</option>
            <option value="renter">Renter</option>
            <option value="investor">Investor</option>
          </select>
          
          <button className="btn-secondary flex items-center gap-2">
            <Filter className="w-4 h-4" />
            <span>More Filters</span>
            <ChevronDown className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
}