import React from 'react';
import { X } from 'lucide-react';

interface PipelineSelectionModalProps {
  onClose: () => void;
  onSelect: (pipeline: string) => void;
}

const pipelineStages = [
  { id: 'new', label: 'New Lead', color: 'bg-blue-500/10 text-blue-400 border-blue-500/20' },
  { id: 'contacted', label: 'Tried Contacting', color: 'bg-purple-500/10 text-purple-400 border-purple-500/20' },
  { id: 'qualified', label: 'Qualified', color: 'bg-green-500/10 text-green-400 border-green-500/20' },
  { id: 'warm', label: 'Warm/Nurturing', color: 'bg-yellow-500/10 text-yellow-400 border-yellow-500/20' },
  { id: 'hot', label: 'Hot/Ready', color: 'bg-red-500/10 text-red-400 border-red-500/20' },
  { id: 'showing', label: 'Showing', color: 'bg-pink-500/10 text-pink-400 border-pink-500/20' },
  { id: 'negotiating', label: 'Negotiating', color: 'bg-orange-500/10 text-orange-400 border-orange-500/20' },
  { id: 'pending', label: 'Pending', color: 'bg-indigo-500/10 text-indigo-400 border-indigo-500/20' },
  { id: 'closed', label: 'Closed', color: 'bg-teal-500/10 text-teal-400 border-teal-500/20' }
];

export default function PipelineSelectionModal({ onClose, onSelect }: PipelineSelectionModalProps) {
  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-dark-800 rounded-lg w-full max-w-md p-6">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold text-gray-100">Select Pipeline Stage</h3>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-300"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-3">
          {pipelineStages.map((stage) => (
            <button
              key={stage.id}
              onClick={() => onSelect(stage.id)}
              className={`w-full flex items-center justify-between p-4 rounded-lg border transition-colors ${stage.color}`}
            >
              <span>{stage.label}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}