import React, { useState } from 'react';
import { X } from 'lucide-react';
import Select from 'react-select';
import { Lead } from '../../types/lead';

interface EditProfileModalProps {
  lead: Lead;
  isOpen: boolean;
  onClose: () => void;
  onSave: (updatedLead: Partial<Lead>) => void;
}

const pipelineOptions = [
  { value: 'new', label: 'New Lead', color: '#94A3B8' },
  { value: 'contacted', label: 'Tried Contacting', color: '#60A5FA' },
  { value: 'qualified', label: 'Qualified', color: '#34D399' },
  { value: 'warm', label: 'Warm/Nurturing', color: '#FBBF24' },
  { value: 'hot', label: 'Hot/Ready', color: '#F87171' },
  { value: 'showing', label: 'Showing', color: '#A78BFA' },
  { value: 'negotiating', label: 'Negotiating', color: '#FB923C' },
  { value: 'pending', label: 'Pending', color: '#38BDF8' },
  { value: 'closed', label: 'Closed', color: '#4ADE80' }
];

const leadTypeOptions = [
  {
    label: 'Buyers',
    options: [
      { value: 'first-time-buyer', label: 'First-Time Buyer' },
      { value: 'move-up-buyer', label: 'Move-Up Buyer' },
      { value: 'luxury-buyer', label: 'Luxury Buyer' },
      { value: 'investor-buyer', label: 'Investor Buyer' }
    ]
  },
  {
    label: 'Sellers',
    options: [
      { value: 'homeowner-seller', label: 'Homeowner Seller' },
      { value: 'luxury-seller', label: 'Luxury Seller' },
      { value: 'investor-seller', label: 'Investment Property Seller' }
    ]
  }
];

const sourceOptions = [
  { value: 'website', label: 'Website' },
  { value: 'zillow', label: 'Zillow' },
  { value: 'realtor', label: 'Realtor.com' },
  { value: 'google', label: 'Google Ads' },
  { value: 'facebook', label: 'Facebook' },
  { value: 'instagram', label: 'Instagram' },
  { value: 'referral', label: 'Referral' },
  { value: 'other', label: 'Other' }
];

const priorityOptions = [
  { value: 'high', label: 'High Priority', color: '#EF4444' },
  { value: 'medium', label: 'Medium Priority', color: '#F59E0B' },
  { value: 'low', label: 'Low Priority', color: '#10B981' }
];

const timelineOptions = [
  { value: 'immediate', label: 'Immediate' },
  { value: '1-3-months', label: '1-3 Months' },
  { value: '3-6-months', label: '3-6 Months' },
  { value: '6-plus-months', label: '6+ Months' },
  { value: 'no-timeline', label: 'No Timeline' }
];

const customSelectStyles = {
  control: (base: any) => ({
    ...base,
    background: '#1F2937',
    borderColor: '#374151',
    '&:hover': {
      borderColor: '#4B5563'
    }
  }),
  menu: (base: any) => ({
    ...base,
    background: '#1F2937',
    border: '1px solid #374151',
    zIndex: 100
  }),
  option: (base: any, state: { isSelected: boolean; isFocused: boolean }) => ({
    ...base,
    backgroundColor: state.isSelected ? '#3B82F6' : state.isFocused ? '#374151' : undefined,
    color: '#E5E7EB'
  }),
  singleValue: (base: any) => ({
    ...base,
    color: '#E5E7EB'
  }),
  input: (base: any) => ({
    ...base,
    color: '#E5E7EB'
  }),
  placeholder: (base: any) => ({
    ...base,
    color: '#9CA3AF'
  })
};

export default function EditProfileModal({ lead, isOpen, onClose, onSave }: EditProfileModalProps) {
  const [name, setName] = useState(lead.name);
  const [email, setEmail] = useState(lead.email);
  const [phone, setPhone] = useState(lead.phone);
  const [leadType, setLeadType] = useState(
    leadTypeOptions
      .flatMap(group => group.options)
      .find(option => option.label === lead.leadType)
  );
  const [pipeline, setPipeline] = useState(
    pipelineOptions.find(option => option.value === lead.pipelineStatus)
  );
  const [source, setSource] = useState({ value: lead.source.type.toLowerCase(), label: lead.source.type });
  const [priority, setPriority] = useState(
    priorityOptions[Math.floor(lead.leadScore / 34)] // Divide score by roughly 33 to get 0-2 index
  );
  const [timeline, setTimeline] = useState(
    timelineOptions.find(option => option.label.toLowerCase().includes(lead.timeline.urgency)) || timelineOptions[0]
  );
  const [budget, setBudget] = useState({
    min: lead.price.minBuy,
    max: lead.price.maxBuy
  });
  const [notes, setNotes] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({
      name,
      email,
      phone,
      leadType: leadType?.label || lead.leadType,
      pipelineStatus: pipeline?.value || lead.pipelineStatus,
      source: {
        ...lead.source,
        type: source.label
      },
      leadScore: priorityOptions.findIndex(p => p.value === priority.value) * 34,
      timeline: {
        ...lead.timeline,
        urgency: timeline.label.toLowerCase()
      },
      price: {
        ...lead.price,
        minBuy: budget.min,
        maxBuy: budget.max
      }
    });
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-dark-800 rounded-lg w-full max-w-3xl p-6 shadow-xl max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold text-gray-100">Edit Lead Profile</h3>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-300 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Basic Information */}
            <div className="space-y-4">
              <h4 className="text-sm font-medium text-gray-400">Basic Information</h4>
              
              <div>
                <label htmlFor="name" className="block text-sm font-medium text-gray-400 mb-2">
                  Lead Name
                </label>
                <input
                  type="text"
                  id="name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full bg-dark-700 border border-dark-600 rounded-lg px-4 py-2 text-gray-200 placeholder-gray-500 focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                />
              </div>

              <div>
                <label htmlFor="email" className="block text-sm font-medium text-gray-400 mb-2">
                  Email Address
                </label>
                <input
                  type="email"
                  id="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full bg-dark-700 border border-dark-600 rounded-lg px-4 py-2 text-gray-200 placeholder-gray-500 focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                />
              </div>

              <div>
                <label htmlFor="phone" className="block text-sm font-medium text-gray-400 mb-2">
                  Phone Number
                </label>
                <input
                  type="tel"
                  id="phone"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full bg-dark-700 border border-dark-600 rounded-lg px-4 py-2 text-gray-200 placeholder-gray-500 focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                />
              </div>
            </div>

            {/* Lead Classification */}
            <div className="space-y-4">
              <h4 className="text-sm font-medium text-gray-400">Lead Classification</h4>
              
              <div>
                <label htmlFor="leadType" className="block text-sm font-medium text-gray-400 mb-2">
                  Lead Type
                </label>
                <Select
                  id="leadType"
                  value={leadType}
                  onChange={(option) => setLeadType(option)}
                  options={leadTypeOptions}
                  styles={customSelectStyles}
                  theme={(theme) => ({
                    ...theme,
                    colors: {
                      ...theme.colors,
                      primary: '#3B82F6',
                      primary75: '#60A5FA',
                      primary50: '#93C5FD',
                      primary25: '#BFDBFE'
                    }
                  })}
                />
              </div>

              <div>
                <label htmlFor="pipeline" className="block text-sm font-medium text-gray-400 mb-2">
                  Pipeline Status
                </label>
                <Select
                  id="pipeline"
                  value={pipeline}
                  onChange={(option) => setPipeline(option)}
                  options={pipelineOptions}
                  styles={customSelectStyles}
                  theme={(theme) => ({
                    ...theme,
                    colors: {
                      ...theme.colors,
                      primary: '#3B82F6'
                    }
                  })}
                />
              </div>

              <div>
                <label htmlFor="source" className="block text-sm font-medium text-gray-400 mb-2">
                  Lead Source
                </label>
                <Select
                  id="source"
                  value={source}
                  onChange={(option) => setSource(option)}
                  options={sourceOptions}
                  styles={customSelectStyles}
                  theme={(theme) => ({
                    ...theme,
                    colors: {
                      ...theme.colors,
                      primary: '#3B82F6'
                    }
                  })}
                />
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Lead Details */}
            <div className="space-y-4">
              <h4 className="text-sm font-medium text-gray-400">Lead Details</h4>
              
              <div>
                <label htmlFor="priority" className="block text-sm font-medium text-gray-400 mb-2">
                  Priority Level
                </label>
                <Select
                  id="priority"
                  value={priority}
                  onChange={(option) => setPriority(option)}
                  options={priorityOptions}
                  styles={customSelectStyles}
                  theme={(theme) => ({
                    ...theme,
                    colors: {
                      ...theme.colors,
                      primary: '#3B82F6'
                    }
                  })}
                />
              </div>

              <div>
                <label htmlFor="timeline" className="block text-sm font-medium text-gray-400 mb-2">
                  Timeline
                </label>
                <Select
                  id="timeline"
                  value={timeline}
                  onChange={(option) => setTimeline(option)}
                  options={timelineOptions}
                  styles={customSelectStyles}
                  theme={(theme) => ({
                    ...theme,
                    colors: {
                      ...theme.colors,
                      primary: '#3B82F6'
                    }
                  })}
                />
              </div>
            </div>

            {/* Budget Information */}
            <div className="space-y-4">
              <h4 className="text-sm font-medium text-gray-400">Budget Information</h4>
              
              <div>
                <label htmlFor="minBudget" className="block text-sm font-medium text-gray-400 mb-2">
                  Minimum Budget
                </label>
                <input
                  type="text"
                  id="minBudget"
                  value={budget.min}
                  onChange={(e) => setBudget({ ...budget, min: e.target.value })}
                  className="w-full bg-dark-700 border border-dark-600 rounded-lg px-4 py-2 text-gray-200 placeholder-gray-500 focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                  placeholder="e.g., 500K"
                />
              </div>

              <div>
                <label htmlFor="maxBudget" className="block text-sm font-medium text-gray-400 mb-2">
                  Maximum Budget
                </label>
                <input
                  type="text"
                  id="maxBudget"
                  value={budget.max}
                  onChange={(e) => setBudget({ ...budget, max: e.target.value })}
                  className="w-full bg-dark-700 border border-dark-600 rounded-lg px-4 py-2 text-gray-200 placeholder-gray-500 focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                  placeholder="e.g., 800K"
                />
              </div>
            </div>
          </div>

          {/* Notes */}
          <div>
            <label htmlFor="notes" className="block text-sm font-medium text-gray-400 mb-2">
              Additional Notes
            </label>
            <textarea
              id="notes"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              rows={4}
              className="w-full bg-dark-700 border border-dark-600 rounded-lg px-4 py-2 text-gray-200 placeholder-gray-500 focus:ring-2 focus:ring-primary-500 focus:border-transparent"
              placeholder="Add any additional notes about the lead..."
            />
          </div>

          <div className="flex justify-end gap-3 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="btn-secondary"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="btn-primary"
            >
              Save Changes
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}