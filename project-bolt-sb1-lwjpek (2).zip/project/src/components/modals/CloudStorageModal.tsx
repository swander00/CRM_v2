import React, { useState } from 'react';
import { X, Cloud, Loader, AlertCircle } from 'lucide-react';
import { GoogleLogin } from '@react-oauth/google';
import { Dropbox } from 'dropbox';

interface CloudStorageModalProps {
  provider: 'google' | 'dropbox';
  leadName: string;
  onClose: () => void;
}

const GOOGLE_CLIENT_ID = import.meta.env.VITE_GOOGLE_CLIENT_ID;
const DROPBOX_CLIENT_ID = import.meta.env.VITE_DROPBOX_CLIENT_ID;

export default function CloudStorageModal({ provider, leadName, onClose }: CloudStorageModalProps) {
  const [isAuthenticating, setIsAuthenticating] = useState(false);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleGoogleSuccess = async (response: any) => {
    if (!GOOGLE_CLIENT_ID) {
      setError('Google Client ID is not configured');
      return;
    }

    setIsAuthenticating(true);
    try {
      // Here you would typically send the token to your backend
      const { credential } = response;
      
      // Create a folder for the lead
      const folderName = `${leadName.replace(/[^a-zA-Z0-9]/g, '_')}_${Date.now()}`;
      
      // This is where you'd make the actual API call to create the folder
      console.log('Creating folder:', folderName);
      
      setIsAuthenticated(true);
      
      // Open Google Drive in a new window
      const width = 800;
      const height = 600;
      const left = (window.innerWidth - width) / 2;
      const top = (window.innerHeight - height) / 2;
      
      window.open(
        'https://drive.google.com',
        'googledrive',
        `width=${width},height=${height},left=${left},top=${top}`
      );
    } catch (err) {
      console.error('Google Drive integration error:', err);
      setError('Failed to connect to Google Drive. Please try again.');
    } finally {
      setIsAuthenticating(false);
    }
  };

  const handleDropboxAuth = async () => {
    if (!DROPBOX_CLIENT_ID) {
      setError('Dropbox Client ID is not configured');
      return;
    }

    setIsAuthenticating(true);
    try {
      const dbx = new Dropbox({ clientId: DROPBOX_CLIENT_ID });
      const authUrl = dbx.getAuthenticationUrl(
        `${window.location.origin}/auth/dropbox/callback`
      );
      
      // Open Dropbox auth in a popup
      const width = 800;
      const height = 600;
      const left = (window.innerWidth - width) / 2;
      const top = (window.innerHeight - height) / 2;
      
      const popup = window.open(
        authUrl,
        'dropbox',
        `width=${width},height=${height},left=${left},top=${top}`
      );

      if (!popup) {
        throw new Error('Popup blocked by browser');
      }

      // Handle the OAuth callback
      window.addEventListener('message', async (event) => {
        if (event.data.type === 'DROPBOX_AUTH') {
          const { code } = event.data;
          // Exchange code for access token
          // Create folder with lead name
          setIsAuthenticated(true);
          popup.close();
        }
      });
    } catch (err) {
      console.error('Dropbox integration error:', err);
      setError(err instanceof Error ? err.message : 'Failed to connect to Dropbox');
    } finally {
      setIsAuthenticating(false);
    }
  };

  // Check if client IDs are configured
  const isConfigured = provider === 'google' ? !!GOOGLE_CLIENT_ID : !!DROPBOX_CLIENT_ID;

  if (!isConfigured) {
    return (
      <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
        <div className="bg-dark-800 rounded-lg w-full max-w-md p-6">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <AlertCircle className="w-6 h-6 text-red-400" />
              <h3 className="text-lg font-semibold text-gray-100">Configuration Error</h3>
            </div>
            <button onClick={onClose} className="text-gray-400 hover:text-gray-300">
              <X className="w-5 h-5" />
            </button>
          </div>
          <p className="text-gray-200 mb-4">
            {provider === 'google' ? 'Google Client ID' : 'Dropbox Client ID'} is not configured. 
            Please add it to your environment variables.
          </p>
          <div className="flex justify-end">
            <button onClick={onClose} className="btn-secondary">Close</button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-dark-800 rounded-lg w-full max-w-md p-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <Cloud className="w-6 h-6 text-primary-400" />
            <h3 className="text-lg font-semibold text-gray-100">
              Connect to {provider === 'google' ? 'Google Drive' : 'Dropbox'}
            </h3>
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-300"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {error && (
          <div className="mb-4 p-3 bg-red-500/10 border border-red-500/20 rounded-lg text-red-400">
            {error}
          </div>
        )}

        <div className="text-center">
          {isAuthenticating ? (
            <div className="flex items-center justify-center gap-3">
              <Loader className="w-5 h-5 animate-spin text-primary-400" />
              <span className="text-gray-200">Authenticating...</span>
            </div>
          ) : isAuthenticated ? (
            <div className="text-green-400">
              Successfully connected! You can now browse and upload files.
            </div>
          ) : (
            <div className="space-y-4">
              <p className="text-gray-200 mb-4">
                Connect your {provider === 'google' ? 'Google Drive' : 'Dropbox'} account to manage files for {leadName}
              </p>
              
              {provider === 'google' ? (
                <div className="flex justify-center">
                  <GoogleLogin
                    onSuccess={handleGoogleSuccess}
                    onError={() => setError('Google authentication failed')}
                    useOneTap
                  />
                </div>
              ) : (
                <button
                  onClick={handleDropboxAuth}
                  className="btn-primary w-full"
                >
                  Connect to Dropbox
                </button>
              )}
            </div>
          )}
        </div>

        <div className="mt-6 text-xs text-gray-400">
          <p>By connecting, you agree to our terms of service and privacy policy regarding cloud storage integration.</p>
          <p className="mt-2">Note: Pop-up blockers may prevent the authentication window from opening.</p>
        </div>
      </div>
    </div>
  );
}