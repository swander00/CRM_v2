import React, { useState } from 'react';
import { X, User, Mail, Phone, MapPin, DollarSign, Calendar, Building2, Clock } from 'lucide-react';
import Select from 'react-select';

interface AddLeadModalProps {
  onClose: () => void;
  onAdd: (lead: any) => void;
}

const customSelectStyles = {
  control: (base: any) => ({
    ...base,
    background: '#1F2937',
    borderColor: '#374151',
    '&:hover': {
      borderColor: '#4B5563'
    }
  }),
  menu: (base: any) => ({
    ...base,
    background: '#1F2937',
    border: '1px solid #374151'
  }),
  option: (base: any, state: { isSelected: boolean; isFocused: boolean }) => ({
    ...base,
    backgroundColor: state.isSelected ? '#3B82F6' : state.isFocused ? '#374151' : undefined,
    color: '#E5E7EB'
  }),
  multiValue: (base: any) => ({
    ...base,
    backgroundColor: '#374151'
  }),
  multiValueLabel: (base: any) => ({
    ...base,
    color: '#E5E7EB'
  }),
  multiValueRemove: (base: any) => ({
    ...base,
    color: '#9CA3AF',
    ':hover': {
      backgroundColor: '#4B5563',
      color: '#E5E7EB'
    }
  }),
  input: (base: any) => ({
    ...base,
    color: '#E5E7EB'
  })
};

const leadTypeOptions = [
  {
    label: 'Buyers',
    options: [
      { value: 'first-time-buyer', label: 'First-Time Buyer' },
      { value: 'move-up-buyer', label: 'Move-Up Buyer' },
      { value: 'investor-buyer', label: 'Investor Buyer' },
      { value: 'luxury-buyer', label: 'Luxury Buyer' }
    ]
  },
  {
    label: 'Sellers',
    options: [
      { value: 'homeowner-seller', label: 'Homeowner Seller' },
      { value: 'investor-seller', label: 'Investment Property Seller' },
      { value: 'luxury-seller', label: 'Luxury Seller' }
    ]
  }
];

const sourceOptions = [
  { value: 'website', label: 'Website' },
  { value: 'referral', label: 'Referral' },
  { value: 'zillow', label: 'Zillow' },
  { value: 'google', label: 'Google Ads' },
  { value: 'facebook', label: 'Facebook' },
  { value: 'instagram', label: 'Instagram' }
];

const timelineOptions = [
  { value: 'immediate', label: 'Immediate' },
  { value: '1-3-months', label: '1-3 Months' },
  { value: '3-6-months', label: '3-6 Months' },
  { value: '6-plus-months', label: '6+ Months' }
];

const propertyTypeOptions = [
  { value: 'single-family', label: 'Single Family Home' },
  { value: 'condo', label: 'Condo' },
  { value: 'townhouse', label: 'Townhouse' },
  { value: 'multi-family', label: 'Multi-Family' },
  { value: 'luxury', label: 'Luxury Property' }
];

const tagOptions = [
  { value: 'hot', label: 'Hot Lead' },
  { value: 'vip', label: 'VIP' },
  { value: 'investor', label: 'Investor' },
  { value: 'cash-buyer', label: 'Cash Buyer' },
  { value: 'pre-approved', label: 'Pre-Approved' }
];

export default function AddLeadModal({ onClose, onAdd }: AddLeadModalProps) {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    leadType: null,
    source: null,
    location: '',
    priceMin: '',
    priceMax: '',
    propertyType: null,
    timeline: null,
    tags: [],
    notes: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onAdd({
      ...formData,
      id: Date.now(),
      status: 'new',
      createdAt: new Date().toISOString()
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-dark-800 rounded-lg w-full max-w-3xl max-h-[90vh] overflow-hidden">
        <div className="flex items-center justify-between p-6 border-b border-dark-700">
          <h3 className="text-lg font-semibold text-gray-100">Add New Lead</h3>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-300"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 overflow-y-auto max-h-[calc(90vh-130px)]">
          <div className="space-y-6">
            {/* Basic Information */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-400 mb-2">
                  Full Name
                </label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                  <input
                    type="text"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="w-full pl-10 pr-4 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200"
                    placeholder="Enter full name"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-400 mb-2">
                  Email Address
                </label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                  <input
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="w-full pl-10 pr-4 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200"
                    placeholder="Enter email address"
                    required
                  />
                </div>
              </div>
            </div>

            {/* Contact & Type */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-400 mb-2">
                  Phone Number
                </label>
                <div className="relative">
                  <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                  <input
                    type="tel"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className="w-full pl-10 pr-4 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200"
                    placeholder="Enter phone number"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-400 mb-2">
                  Lead Type
                </label>
                <Select
                  options={leadTypeOptions}
                  value={formData.leadType}
                  onChange={(option) => setFormData({ ...formData, leadType: option })}
                  styles={customSelectStyles}
                  placeholder="Select lead type"
                />
              </div>
            </div>

            {/* Source & Location */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-400 mb-2">
                  Lead Source
                </label>
                <Select
                  options={sourceOptions}
                  value={formData.source}
                  onChange={(option) => setFormData({ ...formData, source: option })}
                  styles={customSelectStyles}
                  placeholder="Select lead source"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-400 mb-2">
                  Location
                </label>
                <div className="relative">
                  <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                  <input
                    type="text"
                    value={formData.location}
                    onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                    className="w-full pl-10 pr-4 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200"
                    placeholder="Enter preferred location"
                  />
                </div>
              </div>
            </div>

            {/* Price Range */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-400 mb-2">
                  Minimum Price
                </label>
                <div className="relative">
                  <DollarSign className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                  <input
                    type="text"
                    value={formData.priceMin}
                    onChange={(e) => setFormData({ ...formData, priceMin: e.target.value })}
                    className="w-full pl-10 pr-4 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200"
                    placeholder="Enter minimum price"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-400 mb-2">
                  Maximum Price
                </label>
                <div className="relative">
                  <DollarSign className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                  <input
                    type="text"
                    value={formData.priceMax}
                    onChange={(e) => setFormData({ ...formData, priceMax: e.target.value })}
                    className="w-full pl-10 pr-4 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200"
                    placeholder="Enter maximum price"
                  />
                </div>
              </div>
            </div>

            {/* Property Type & Timeline */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-400 mb-2">
                  Property Type
                </label>
                <Select
                  options={propertyTypeOptions}
                  value={formData.propertyType}
                  onChange={(option) => setFormData({ ...formData, propertyType: option })}
                  styles={customSelectStyles}
                  placeholder="Select property type"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-400 mb-2">
                  Timeline
                </label>
                <Select
                  options={timelineOptions}
                  value={formData.timeline}
                  onChange={(option) => setFormData({ ...formData, timeline: option })}
                  styles={customSelectStyles}
                  placeholder="Select timeline"
                />
              </div>
            </div>

            {/* Tags */}
            <div>
              <label className="block text-sm font-medium text-gray-400 mb-2">
                Tags
              </label>
              <Select
                isMulti
                options={tagOptions}
                value={formData.tags}
                onChange={(options) => setFormData({ ...formData, tags: options })}
                styles={customSelectStyles}
                placeholder="Select tags"
              />
            </div>

            {/* Notes */}
            <div>
              <label className="block text-sm font-medium text-gray-400 mb-2">
                Notes
              </label>
              <textarea
                value={formData.notes}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                className="w-full px-4 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200 resize-none"
                rows={4}
                placeholder="Enter any additional notes..."
              />
            </div>
          </div>

          <div className="flex justify-end gap-3 mt-6 pt-6 border-t border-dark-700">
            <button
              type="button"
              onClick={onClose}
              className="btn-secondary"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="btn-primary"
            >
              Add Lead
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}