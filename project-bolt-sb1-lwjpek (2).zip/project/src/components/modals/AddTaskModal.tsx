import React, { useState } from 'react';
import { X, Calendar, Clock, User, AlertCircle } from 'lucide-react';
import Select from 'react-select';

interface AddTaskModalProps {
  onClose: () => void;
  onAdd: (task: any) => void;
  leadId: number;
}

const customSelectStyles = {
  control: (base: any) => ({
    ...base,
    background: '#1F2937',
    borderColor: '#374151',
    '&:hover': {
      borderColor: '#4B5563'
    }
  }),
  menu: (base: any) => ({
    ...base,
    background: '#1F2937',
    border: '1px solid #374151'
  }),
  option: (base: any, state: { isSelected: boolean; isFocused: boolean }) => ({
    ...base,
    backgroundColor: state.isSelected ? '#3B82F6' : state.isFocused ? '#374151' : undefined,
    color: '#E5E7EB'
  }),
  input: (base: any) => ({
    ...base,
    color: '#E5E7EB'
  })
};

const taskTypeOptions = [
  { value: 'call', label: 'Phone Call' },
  { value: 'meeting', label: 'Meeting' },
  { value: 'showing', label: 'Property Showing' },
  { value: 'follow_up', label: 'Follow-up' },
  { value: 'document', label: 'Document Review' },
  { value: 'other', label: 'Other' }
];

const priorityOptions = [
  { value: 'high', label: 'High Priority', color: '#EF4444' },
  { value: 'medium', label: 'Medium Priority', color: '#F59E0B' },
  { value: 'low', label: 'Low Priority', color: '#10B981' }
];

const assigneeOptions = [
  { value: 'sarah', label: 'Sarah Wilson' },
  { value: 'mike', label: 'Mike Johnson' },
  { value: 'david', label: 'David Lee' },
  { value: 'emma', label: 'Emma Taylor' }
];

export default function AddTaskModal({ onClose, onAdd, leadId }: AddTaskModalProps) {
  const [formData, setFormData] = useState({
    type: null,
    title: '',
    description: '',
    dueDate: '',
    dueTime: '',
    priority: null,
    assignee: null
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const dueDateTime = `${formData.dueDate}T${formData.dueTime}:00`;
    
    onAdd({
      ...formData,
      leadId,
      dueDate: dueDateTime,
      status: 'pending',
      createdAt: new Date().toISOString()
    });
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-dark-800 rounded-lg w-full max-w-lg p-6">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold text-gray-100">Add New Task</h3>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-300"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Task Type */}
          <div>
            <label className="block text-sm font-medium text-gray-400 mb-2">
              Task Type
            </label>
            <Select
              options={taskTypeOptions}
              value={formData.type}
              onChange={(option) => setFormData({ ...formData, type: option })}
              styles={customSelectStyles}
              placeholder="Select task type"
            />
          </div>

          {/* Task Title */}
          <div>
            <label className="block text-sm font-medium text-gray-400 mb-2">
              Task Title
            </label>
            <input
              type="text"
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              className="w-full px-4 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200"
              placeholder="Enter task title"
              required
            />
          </div>

          {/* Description */}
          <div>
            <label className="block text-sm font-medium text-gray-400 mb-2">
              Description
            </label>
            <textarea
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              className="w-full px-4 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200 resize-none"
              rows={3}
              placeholder="Enter task description"
            />
          </div>

          {/* Due Date and Time */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-400 mb-2">
                Due Date
              </label>
              <div className="relative">
                <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                <input
                  type="date"
                  value={formData.dueDate}
                  onChange={(e) => setFormData({ ...formData, dueDate: e.target.value })}
                  className="w-full pl-10 pr-4 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-400 mb-2">
                Due Time
              </label>
              <div className="relative">
                <Clock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                <input
                  type="time"
                  value={formData.dueTime}
                  onChange={(e) => setFormData({ ...formData, dueTime: e.target.value })}
                  className="w-full pl-10 pr-4 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200"
                  required
                />
              </div>
            </div>
          </div>

          {/* Priority and Assignee */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-400 mb-2">
                Priority
              </label>
              <Select
                options={priorityOptions}
                value={formData.priority}
                onChange={(option) => setFormData({ ...formData, priority: option })}
                styles={customSelectStyles}
                placeholder="Select priority"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-400 mb-2">
                Assignee
              </label>
              <Select
                options={assigneeOptions}
                value={formData.assignee}
                onChange={(option) => setFormData({ ...formData, assignee: option })}
                styles={customSelectStyles}
                placeholder="Select assignee"
              />
            </div>
          </div>

          <div className="flex justify-end gap-3 pt-6 border-t border-dark-700">
            <button
              type="button"
              onClick={onClose}
              className="btn-secondary"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="btn-primary"
            >
              Add Task
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}