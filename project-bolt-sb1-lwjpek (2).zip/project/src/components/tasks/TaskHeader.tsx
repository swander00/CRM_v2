import React, { useState } from 'react';
import { Search, Plus, BarChart2, Calendar } from 'lucide-react';
import AddTaskModal from '../modals/AddTaskModal';

export default function TaskHeader() {
  const [showAddTaskModal, setShowAddTaskModal] = useState(false);

  const handleAddTask = (taskData: any) => {
    // Handle adding the task here
    console.log('New task:', taskData);
    setShowAddTaskModal(false);
  };

  return (
    <div className="bg-dark-800 border-b border-dark-700 p-4">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-100">Tasks</h1>
        <p className="text-gray-400 mt-1">Manage and track your team's tasks</p>
      </div>

      <div className="flex flex-col lg:flex-row gap-4">
        <div className="flex-1">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="text"
              placeholder="Search tasks by title, client, or property..."
              className="w-full pl-10 pr-4 py-2.5 bg-dark-700 border border-dark-700 text-gray-200 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent transition-all"
            />
          </div>
        </div>
        
        <div className="flex items-center gap-3">
          <select className="bg-dark-700 border border-dark-700 rounded-lg px-3 py-2 text-gray-200">
            <option>All Tasks</option>
            <option>My Tasks</option>
            <option>Team Tasks</option>
          </select>

          <select className="bg-dark-700 border border-dark-700 rounded-lg px-3 py-2 text-gray-200">
            <option>All Priorities</option>
            <option>High Priority</option>
            <option>Medium Priority</option>
            <option>Low Priority</option>
          </select>

          <button className="btn-secondary flex items-center gap-2">
            <Calendar className="w-4 h-4" />
            Calendar View
          </button>

          <button 
            onClick={() => setShowAddTaskModal(true)}
            className="btn-primary flex items-center gap-2"
          >
            <Plus className="w-4 h-4" />
            Add Task
          </button>
        </div>
      </div>

      {showAddTaskModal && (
        <AddTaskModal
          onClose={() => setShowAddTaskModal(false)}
          onAdd={handleAddTask}
          leadId={1} // You would typically get this from context or props
        />
      )}
    </div>
  );
}