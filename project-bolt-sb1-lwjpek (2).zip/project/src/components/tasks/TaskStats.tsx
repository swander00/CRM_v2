import React from 'react';
import { CheckCircle, Clock, AlertTriangle, Calendar } from 'lucide-react';

export default function TaskStats() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
      <div className="bg-dark-800 rounded-lg border border-dark-700 p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-gray-400">Total Tasks</p>
            <p className="text-2xl font-semibold text-gray-100 mt-1">156</p>
          </div>
          <div className="p-3 bg-primary-500/10 rounded-full">
            <CheckCircle className="w-6 h-6 text-primary-400" />
          </div>
        </div>
        <div className="mt-4 flex items-center gap-1">
          <span className="text-sm text-gray-400">42 completed this week</span>
        </div>
      </div>

      <div className="bg-dark-800 rounded-lg border border-dark-700 p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-gray-400">In Progress</p>
            <p className="text-2xl font-semibold text-gray-100 mt-1">28</p>
          </div>
          <div className="p-3 bg-blue-500/10 rounded-full">
            <Clock className="w-6 h-6 text-blue-400" />
          </div>
        </div>
        <div className="mt-4 flex items-center gap-1">
          <span className="text-sm text-gray-400">15 due this week</span>
        </div>
      </div>

      <div className="bg-dark-800 rounded-lg border border-dark-700 p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-gray-400">Overdue</p>
            <p className="text-2xl font-semibold text-gray-100 mt-1">8</p>
          </div>
          <div className="p-3 bg-red-500/10 rounded-full">
            <AlertTriangle className="w-6 h-6 text-red-400" />
          </div>
        </div>
        <div className="mt-4 flex items-center gap-1">
          <span className="text-sm text-red-400">Requires attention</span>
        </div>
      </div>

      <div className="bg-dark-800 rounded-lg border border-dark-700 p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-gray-400">Upcoming</p>
            <p className="text-2xl font-semibold text-gray-100 mt-1">24</p>
          </div>
          <div className="p-3 bg-purple-500/10 rounded-full">
            <Calendar className="w-6 h-6 text-purple-400" />
          </div>
        </div>
        <div className="mt-4 flex items-center gap-1">
          <span className="text-sm text-gray-400">Due next week</span>
        </div>
      </div>
    </div>
  );
}