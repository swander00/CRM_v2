import React, { useState } from 'react';
import { DragDropContext, Droppable, Draggable, DropResult } from '@hello-pangea/dnd';
import { AlertCircle, Clock, User, Edit2, Trash2, Calendar, CheckCircle, Plus } from 'lucide-react';
import EditTaskModal from './EditTaskModal';
import DeleteTaskModal from './DeleteTaskModal';
import AddTaskModal from '../modals/AddTaskModal';

const initialColumns = {
  'todo': {
    id: 'todo',
    title: 'To Do',
    items: [
      {
        id: '1',
        title: 'Property Viewing',
        description: 'Schedule viewing for 123 Main St',
        priority: 'high',
        dueDate: '2024-03-01',
        assignee: 'Sarah Wilson',
        client: 'John Smith'
      },
      {
        id: '2',
        title: 'Follow-up Call',
        description: 'Call regarding mortgage pre-approval',
        priority: 'medium',
        dueDate: '2024-03-02',
        assignee: 'Mike Johnson',
        client: 'Emma Davis'
      }
    ]
  },
  'in-progress': {
    id: 'in-progress',
    title: 'In Progress',
    items: [
      {
        id: '3',
        title: 'Document Review',
        description: 'Review closing documents',
        priority: 'high',
        dueDate: '2024-03-03',
        assignee: 'David Lee',
        client: 'Robert Brown'
      }
    ]
  },
  'review': {
    id: 'review',
    title: 'Review',
    items: [
      {
        id: '4',
        title: 'Contract Draft',
        description: 'Prepare purchase agreement',
        priority: 'medium',
        dueDate: '2024-03-04',
        assignee: 'Sarah Wilson',
        client: 'Alice White'
      }
    ]
  },
  'completed': {
    id: 'completed',
    title: 'Completed',
    items: [
      {
        id: '5',
        title: 'Market Analysis',
        description: 'Complete market analysis report',
        priority: 'low',
        dueDate: '2024-03-05',
        assignee: 'Mike Johnson',
        client: 'James Wilson'
      }
    ]
  }
};

export default function TaskBoard() {
  const [columns, setColumns] = useState(initialColumns);
  const [editingTask, setEditingTask] = useState<any>(null);
  const [deletingTask, setDeletingTask] = useState<any>(null);
  const [showAddModal, setShowAddModal] = useState(false);

  const onDragEnd = (result: DropResult) => {
    if (!result.destination) return;

    const { source, destination } = result;

    if (source.droppableId === destination.droppableId) {
      const column = columns[source.droppableId];
      const items = Array.from(column.items);
      const [removed] = items.splice(source.index, 1);
      items.splice(destination.index, 0, removed);

      setColumns({
        ...columns,
        [source.droppableId]: {
          ...column,
          items
        }
      });
    } else {
      const sourceColumn = columns[source.droppableId];
      const destColumn = columns[destination.droppableId];
      const sourceItems = Array.from(sourceColumn.items);
      const destItems = Array.from(destColumn.items);
      const [removed] = sourceItems.splice(source.index, 1);
      destItems.splice(destination.index, 0, removed);

      setColumns({
        ...columns,
        [source.droppableId]: {
          ...sourceColumn,
          items: sourceItems
        },
        [destination.droppableId]: {
          ...destColumn,
          items: destItems
        }
      });
    }
  };

  const handleEditTask = (columnId: string, task: any) => {
    setEditingTask({ ...task, columnId });
  };

  const handleDeleteTask = (columnId: string, task: any) => {
    setDeletingTask({ ...task, columnId });
  };

  const handleUpdateTask = (updatedTask: any) => {
    const column = columns[updatedTask.columnId];
    const updatedItems = column.items.map(item =>
      item.id === updatedTask.id ? { ...item, ...updatedTask } : item
    );

    setColumns({
      ...columns,
      [updatedTask.columnId]: {
        ...column,
        items: updatedItems
      }
    });
    setEditingTask(null);
  };

  const handleConfirmDelete = () => {
    if (!deletingTask) return;

    const column = columns[deletingTask.columnId];
    const updatedItems = column.items.filter(item => item.id !== deletingTask.id);

    setColumns({
      ...columns,
      [deletingTask.columnId]: {
        ...column,
        items: updatedItems
      }
    });
    setDeletingTask(null);
  };

  const handleAddTask = (taskData: any) => {
    const newTask = {
      id: Date.now().toString(),
      ...taskData
    };

    setColumns({
      ...columns,
      'todo': {
        ...columns.todo,
        items: [...columns.todo.items, newTask]
      }
    });
    setShowAddModal(false);
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high':
        return 'text-red-400';
      case 'medium':
        return 'text-yellow-400';
      case 'low':
        return 'text-green-400';
      default:
        return 'text-gray-400';
    }
  };

  return (
    <div className="h-full overflow-x-auto">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-semibold text-gray-100">Tasks Overview</h2>
        <button
          onClick={() => setShowAddModal(true)}
          className="btn-primary flex items-center gap-2"
        >
          <Plus className="w-4 h-4" />
          Add Task
        </button>
      </div>

      <DragDropContext onDragEnd={onDragEnd}>
        <div className="flex gap-6 p-4 min-w-max">
          {Object.values(columns).map((column) => (
            <div key={column.id} className="w-80">
              <div className="mb-4 flex items-center justify-between">
                <h3 className="text-sm font-medium text-gray-400">{column.title}</h3>
                <span className="text-sm text-gray-500">{column.items.length}</span>
              </div>

              <Droppable droppableId={column.id}>
                {(provided) => (
                  <div
                    ref={provided.innerRef}
                    {...provided.droppableProps}
                    className="space-y-4"
                  >
                    {column.items.map((item, index) => (
                      <Draggable key={item.id} draggableId={item.id} index={index}>
                        {(provided) => (
                          <div
                            ref={provided.innerRef}
                            {...provided.draggableProps}
                            {...provided.dragHandleProps}
                            className="bg-dark-800 rounded-lg border border-dark-700 p-4 space-y-3"
                          >
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-2">
                                <AlertCircle className={`w-4 h-4 ${getPriorityColor(item.priority)}`} />
                                <h4 className="font-medium text-gray-200">{item.title}</h4>
                              </div>
                              <div className="flex items-center gap-2">
                                <button 
                                  onClick={() => handleEditTask(column.id, item)}
                                  className="text-gray-400 hover:text-gray-300 p-1"
                                >
                                  <Edit2 className="w-4 h-4" />
                                </button>
                                <button 
                                  onClick={() => handleDeleteTask(column.id, item)}
                                  className="text-gray-400 hover:text-red-400 p-1"
                                >
                                  <Trash2 className="w-4 h-4" />
                                </button>
                              </div>
                            </div>

                            <p className="text-sm text-gray-400">{item.description}</p>

                            <div className="space-y-2">
                              <div className="flex items-center gap-2 text-sm text-gray-400">
                                <User className="w-4 h-4" />
                                <span>{item.assignee}</span>
                              </div>
                              <div className="flex items-center gap-2 text-sm text-gray-400">
                                <Calendar className="w-4 h-4" />
                                <span>Due: {item.dueDate}</span>
                              </div>
                              <div className="flex items-center gap-2 text-sm text-gray-400">
                                <User className="w-4 h-4" />
                                <span>Client: {item.client}</span>
                              </div>
                            </div>

                            {column.id === 'completed' && (
                              <div className="flex items-center gap-2 text-sm text-green-400">
                                <CheckCircle className="w-4 h-4" />
                                <span>Completed</span>
                              </div>
                            )}
                          </div>
                        )}
                      </Draggable>
                    ))}
                    {provided.placeholder}
                  </div>
                )}
              </Droppable>
            </div>
          ))}
        </div>
      </DragDropContext>

      {editingTask && (
        <EditTaskModal
          task={editingTask}
          onClose={() => setEditingTask(null)}
          onSave={handleUpdateTask}
        />
      )}

      {deletingTask && (
        <DeleteTaskModal
          taskName={deletingTask.title}
          onClose={() => setDeletingTask(null)}
          onConfirm={handleConfirmDelete}
        />
      )}

      {showAddModal && (
        <AddTaskModal
          onClose={() => setShowAddModal(false)}
          onAdd={handleAddTask}
          leadId={1}
        />
      )}
    </div>
  );
}