import React, { useState } from 'react';
import { X } from 'lucide-react';
import Select from 'react-select';
import { useEditor, EditorContent } from '@tiptap/react';
import StarterKit from '@tiptap/starter-kit';
import Link from '@tiptap/extension-link';
import Placeholder from '@tiptap/extension-placeholder';
import TextAlign from '@tiptap/extension-text-align';
import Underline from '@tiptap/extension-underline';

interface EmailFormProps {
  block: {
    id: string;
    type: 'email';
    content?: {
      subject?: string;
      body?: string;
      delay?: number;
      delayUnit?: 'hours' | 'days' | 'weeks';
    };
  };
  onUpdate: (field: string, value: any) => void;
}

const emailTemplates = [
  { value: 'welcome', label: 'Welcome Email', 
    subject: 'Welcome to Our Real Estate Family!',
    body: 'Thank you for choosing us...' },
  { value: 'viewing', label: 'Property Viewing Confirmation', 
    subject: 'Your Property Viewing Appointment',
    body: 'This email confirms your viewing...' },
  { value: 'follow_up', label: 'Follow-up Email', 
    subject: 'Following Up on Your Property Interest',
    body: 'I wanted to follow up...' },
  { value: 'market_update', label: 'Market Update', 
    subject: 'Your Monthly Real Estate Market Update',
    body: 'Here are the latest market trends...' }
];

const pipelineOptions = [
  { value: 'new', label: 'New Lead' },
  { value: 'contacted', label: 'Contacted' },
  { value: 'qualified', label: 'Qualified' },
  { value: 'proposal', label: 'Proposal Sent' },
  { value: 'negotiating', label: 'Negotiating' },
  { value: 'closed', label: 'Closed Won' }
];

const tagOptions = [
  { value: 'vip', label: 'VIP' },
  { value: 'hot', label: 'Hot Lead' },
  { value: 'cold', label: 'Cold Lead' },
  { value: 'follow_up', label: 'Needs Follow-up' }
];

const actionOptions = [
  { value: 'email_opened', label: 'Email Opened' },
  { value: 'link_clicked', label: 'Link Clicked' },
  { value: 'form_submitted', label: 'Form Submitted' }
];

const customSelectStyles = {
  control: (base: any) => ({
    ...base,
    background: '#1F2937',
    borderColor: '#374151',
    '&:hover': {
      borderColor: '#4B5563'
    }
  }),
  menu: (base: any) => ({
    ...base,
    background: '#1F2937',
    border: '1px solid #374151'
  }),
  option: (base: any, state: { isSelected: boolean; isFocused: boolean }) => ({
    ...base,
    backgroundColor: state.isSelected ? '#3B82F6' : state.isFocused ? '#374151' : undefined,
    color: '#E5E7EB'
  }),
  multiValue: (base: any) => ({
    ...base,
    backgroundColor: '#374151',
    borderRadius: '4px'
  }),
  multiValueLabel: (base: any) => ({
    ...base,
    color: '#E5E7EB',
    padding: '2px 6px'
  }),
  multiValueRemove: (base: any) => ({
    ...base,
    color: '#9CA3AF',
    ':hover': {
      backgroundColor: '#4B5563',
      color: '#E5E7EB'
    }
  }),
  input: (base: any) => ({
    ...base,
    color: '#E5E7EB'
  })
};

export default function EmailForm({ block, onUpdate }: EmailFormProps) {
  const [stopConditions, setStopConditions] = useState<Array<{ type: string; value: string }>>([]);

  const editor = useEditor({
    extensions: [
      StarterKit,
      Link,
      Underline,
      TextAlign.configure({
        types: ['heading', 'paragraph']
      }),
      Placeholder.configure({
        placeholder: 'Write your message content here...'
      })
    ],
    content: block.content?.body || '',
    onUpdate: ({ editor }) => {
      onUpdate('body', editor.getHTML());
    }
  });

  const handleTemplateSelect = (option: any) => {
    if (option) {
      const template = emailTemplates.find(t => t.value === option.value);
      if (template) {
        onUpdate('subject', template.subject);
        editor?.commands.setContent(template.body);
      }
    }
  };

  const removeStopCondition = (index: number) => {
    setStopConditions(prev => prev.filter((_, i) => i !== index));
  };

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold text-gray-100 mb-6">Email Message</h3>
      </div>

      {/* Template Selection */}
      <div>
        <label className="block text-sm font-medium text-gray-400 mb-2">
          Select Template
        </label>
        <Select
          options={emailTemplates}
          onChange={handleTemplateSelect}
          styles={customSelectStyles}
          placeholder="Choose a template or start from scratch..."
          isClearable
        />
      </div>

      {/* Subject Line */}
      <div>
        <label className="block text-sm font-medium text-gray-400 mb-2">
          Subject Line
        </label>
        <input
          type="text"
          value={block.content?.subject || ''}
          onChange={(e) => onUpdate('subject', e.target.value)}
          className="w-full px-3 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200"
          placeholder="Enter email subject..."
        />
      </div>

      {/* Message Content */}
      <div>
        <label className="block text-sm font-medium text-gray-400 mb-2">
          Message Content
        </label>
        <div className="border border-dark-600 rounded-lg overflow-hidden">
          <EditorContent editor={editor} className="prose prose-invert max-w-none p-4 min-h-[200px] bg-dark-700" />
        </div>
      </div>

      {/* Stop Conditions */}
      <div>
        <h4 className="text-sm font-medium text-gray-400 mb-4">Stop Conditions</h4>
        <div className="space-y-4">
          {/* Pipeline Status */}
          <div>
            <label className="block text-sm text-gray-300 mb-2">Pipeline Status</label>
            <Select
              isMulti
              options={pipelineOptions}
              onChange={(options) => {
                const values = options.map(opt => ({ type: 'pipeline', value: opt.value }));
                setStopConditions(prev => [
                  ...prev.filter(c => c.type !== 'pipeline'),
                  ...values
                ]);
              }}
              styles={customSelectStyles}
              placeholder="Select pipeline statuses..."
            />
          </div>

          {/* Tags */}
          <div>
            <label className="block text-sm text-gray-300 mb-2">Tags</label>
            <Select
              isMulti
              options={tagOptions}
              onChange={(options) => {
                const values = options.map(opt => ({ type: 'tag', value: opt.value }));
                setStopConditions(prev => [
                  ...prev.filter(c => c.type !== 'tag'),
                  ...values
                ]);
              }}
              styles={customSelectStyles}
              placeholder="Select tags..."
            />
          </div>

          {/* User Actions */}
          <div>
            <label className="block text-sm text-gray-300 mb-2">User Actions</label>
            <Select
              isMulti
              options={actionOptions}
              onChange={(options) => {
                const values = options.map(opt => ({ type: 'action', value: opt.value }));
                setStopConditions(prev => [
                  ...prev.filter(c => c.type !== 'action'),
                  ...values
                ]);
              }}
              styles={customSelectStyles}
              placeholder="Select actions..."
            />
          </div>
        </div>
      </div>

      {/* Selected Stop Conditions Display */}
      {stopConditions.length > 0 && (
        <div className="p-4 bg-dark-700/50 rounded-lg">
          <h5 className="text-sm font-medium text-gray-300 mb-2">Active Stop Conditions</h5>
          <div className="space-y-2">
            {stopConditions.map((condition, index) => (
              <div
                key={`${condition.type}-${condition.value}-${index}`}
                className="flex items-center justify-between p-2 bg-dark-700 rounded-lg"
              >
                <span className="text-sm text-gray-200">
                  {condition.type}: {condition.value}
                </span>
                <button
                  onClick={() => removeStopCondition(index)}
                  className="text-gray-400 hover:text-gray-300"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Save Button */}
      <div className="pt-4 border-t border-dark-700">
        <button className="w-full btn-primary">
          Save Message
        </button>
      </div>
    </div>
  );
}