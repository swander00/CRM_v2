import React from 'react';

interface WhatsAppFormProps {
  block: {
    content: {
      body: string;
    };
  };
  onUpdate: (field: string, value: any) => void;
}

export default function WhatsAppForm({ block, onUpdate }: WhatsAppFormProps) {
  return (
    <div className="space-y-4">
      {/* Form Header */}
      <div>
        <h3 className="text-lg font-semibold text-gray-100">WhatsApp Message</h3>
      </div>

      {/* Message Content */}
      <div>
        <label className="block text-sm font-medium text-gray-400 mb-2">
          Message Content
        </label>
        <textarea
          value={block.content.body || ''}
          onChange={(e) => onUpdate('body', e.target.value)}
          className="w-full px-3 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200 resize-none h-32"
          placeholder="Enter WhatsApp message..."
        />
      </div>

      {/* WhatsApp Features */}
      <div className="mt-4 p-3 bg-dark-700/50 rounded-lg">
        <h4 className="text-sm font-medium text-gray-300 mb-2">Available Features</h4>
        <ul className="text-xs text-gray-400 space-y-1">
          <li>• Rich text formatting</li>
          <li>• Emoji support</li>
          <li>• Link previews</li>
          <li>• Message templates</li>
        </ul>
      </div>
    </div>
  );
}