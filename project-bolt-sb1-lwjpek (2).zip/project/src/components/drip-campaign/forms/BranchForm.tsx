import React, { useState } from 'react';
import Select from 'react-select';

interface BranchFormProps {
  block: {
    content?: {
      condition: string;
      operator: string;
      value?: string;
      branches: {
        true: string[];
        false: string[];
      };
    };
  };
  onUpdate: (field: string, value: any) => void;
}

const conditionOptions = [
  { value: 'leadScore', label: 'Lead Score' },
  { value: 'pipelineStage', label: 'Pipeline Stage' },
  { value: 'lastActivity', label: 'Last Activity' },
  { value: 'propertyPreference', label: 'Property Preference' },
  { value: 'budget', label: 'Budget Range' },
  { value: 'location', label: 'Location' },
  { value: 'engagementLevel', label: 'Engagement Level' }
];

const operatorOptions = [
  { value: 'equals', label: 'Equals' },
  { value: 'notEquals', label: 'Does Not Equal' },
  { value: 'greaterThan', label: 'Greater Than' },
  { value: 'lessThan', label: 'Less Than' },
  { value: 'contains', label: 'Contains' },
  { value: 'notContains', label: 'Does Not Contain' }
];

const customSelectStyles = {
  control: (base: any) => ({
    ...base,
    background: '#1F2937',
    borderColor: '#374151',
    '&:hover': {
      borderColor: '#4B5563'
    }
  }),
  menu: (base: any) => ({
    ...base,
    background: '#1F2937',
    border: '1px solid #374151'
  }),
  option: (base: any, state: { isSelected: boolean; isFocused: boolean }) => ({
    ...base,
    backgroundColor: state.isSelected ? '#3B82F6' : state.isFocused ? '#374151' : undefined,
    color: '#E5E7EB'
  }),
  singleValue: (base: any) => ({
    ...base,
    color: '#E5E7EB'
  }),
  input: (base: any) => ({
    ...base,
    color: '#E5E7EB'
  })
};

export default function BranchForm({ block, onUpdate }: BranchFormProps) {
  const [selectedCondition, setSelectedCondition] = useState(conditionOptions[0]);
  const [selectedOperator, setSelectedOperator] = useState(operatorOptions[0]);

  const handleConditionChange = (option: any) => {
    setSelectedCondition(option);
    onUpdate('condition', option.value);
  };

  const handleOperatorChange = (option: any) => {
    setSelectedOperator(option);
    onUpdate('operator', option.value);
  };

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold text-gray-100">Branch Condition</h3>
        <p className="text-sm text-gray-400 mt-1">
          Set up conditions to determine which path the campaign should follow
        </p>
      </div>

      {/* Condition Builder */}
      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-400 mb-2">
            If
          </label>
          <Select
            options={conditionOptions}
            value={selectedCondition}
            onChange={handleConditionChange}
            styles={customSelectStyles}
            placeholder="Select condition..."
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-400 mb-2">
            Operator
          </label>
          <Select
            options={operatorOptions}
            value={selectedOperator}
            onChange={handleOperatorChange}
            styles={customSelectStyles}
            placeholder="Select operator..."
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-400 mb-2">
            Value
          </label>
          <input
            type="text"
            value={block.content?.value || ''}
            onChange={(e) => onUpdate('value', e.target.value)}
            className="w-full px-3 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200"
            placeholder="Enter comparison value..."
          />
        </div>
      </div>

      {/* Branch Paths */}
      <div className="space-y-4">
        <h4 className="text-sm font-medium text-gray-400">Branch Paths</h4>
        
        <div className="grid grid-cols-2 gap-4">
          <div className="p-4 bg-green-500/10 border border-green-500/20 rounded-lg">
            <h5 className="text-sm font-medium text-green-400 mb-2">If True</h5>
            <p className="text-xs text-gray-400">
              Campaign will follow this path if the condition is met
            </p>
          </div>

          <div className="p-4 bg-red-500/10 border border-red-500/20 rounded-lg">
            <h5 className="text-sm font-medium text-red-400 mb-2">If False</h5>
            <p className="text-xs text-gray-400">
              Campaign will follow this path if the condition is not met
            </p>
          </div>
        </div>
      </div>

      {/* Best Practices */}
      <div className="mt-4 p-4 bg-dark-700/50 rounded-lg">
        <h4 className="text-sm font-medium text-gray-300 mb-2">Branching Best Practices</h4>
        <ul className="text-xs text-gray-400 space-y-1">
          <li>• Use clear and specific conditions</li>
          <li>• Consider all possible scenarios</li>
          <li>• Keep branch logic simple and focused</li>
          <li>• Test both paths thoroughly</li>
        </ul>
      </div>
    </div>
  );
}