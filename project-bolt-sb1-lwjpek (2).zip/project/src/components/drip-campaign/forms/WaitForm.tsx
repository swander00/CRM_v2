import React from 'react';
import Select from 'react-select';

interface WaitFormProps {
  block: {
    content?: {
      delay?: number;
      delayUnit?: 'minutes' | 'hours' | 'days' | 'weeks';
    };
  };
  onUpdate: (field: string, value: any) => void;
}

const timeUnitOptions = [
  { value: 'minutes', label: 'Minutes' },
  { value: 'hours', label: 'Hours' },
  { value: 'days', label: 'Days' },
  { value: 'weeks', label: 'Weeks' }
];

const customSelectStyles = {
  control: (base: any) => ({
    ...base,
    background: '#1F2937',
    borderColor: '#374151',
    '&:hover': {
      borderColor: '#4B5563'
    }
  }),
  menu: (base: any) => ({
    ...base,
    background: '#1F2937',
    border: '1px solid #374151'
  }),
  option: (base: any, state: { isSelected: boolean; isFocused: boolean }) => ({
    ...base,
    backgroundColor: state.isSelected ? '#3B82F6' : state.isFocused ? '#374151' : undefined,
    color: '#E5E7EB'
  }),
  singleValue: (base: any) => ({
    ...base,
    color: '#E5E7EB'
  }),
  input: (base: any) => ({
    ...base,
    color: '#E5E7EB'
  })
};

export default function WaitForm({ block, onUpdate }: WaitFormProps) {
  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold text-gray-100">Wait Duration</h3>
        <p className="text-sm text-gray-400 mt-1">
          Specify how long to wait before proceeding to the next step
        </p>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-400 mb-2">
            Duration
          </label>
          <input
            type="number"
            min="0"
            value={block.content?.delay || 0}
            onChange={(e) => onUpdate('delay', parseInt(e.target.value))}
            className="w-full px-3 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200"
            placeholder="Enter duration..."
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-400 mb-2">
            Time Unit
          </label>
          <Select
            options={timeUnitOptions}
            value={timeUnitOptions.find(option => option.value === block.content?.delayUnit)}
            onChange={(option) => onUpdate('delayUnit', option?.value)}
            styles={customSelectStyles}
            placeholder="Select unit..."
          />
        </div>
      </div>

      {/* Best Practices */}
      <div className="mt-4 p-4 bg-dark-700/50 rounded-lg">
        <h4 className="text-sm font-medium text-gray-300 mb-2">Timing Best Practices</h4>
        <ul className="text-xs text-gray-400 space-y-1">
          <li>• Consider recipient's time zone when setting delays</li>
          <li>• Use shorter delays for urgent communications</li>
          <li>• Allow sufficient time between messages to avoid overwhelming recipients</li>
          <li>• Consider business hours and typical response times</li>
        </ul>
      </div>

      {/* Quick Presets */}
      <div>
        <label className="block text-sm font-medium text-gray-400 mb-2">
          Quick Presets
        </label>
        <div className="grid grid-cols-2 gap-2">
          <button
            onClick={() => {
              onUpdate('delay', 1);
              onUpdate('delayUnit', 'hours');
            }}
            className="px-4 py-2 bg-dark-700 hover:bg-dark-600 rounded-lg text-sm text-gray-300"
          >
            1 Hour
          </button>
          <button
            onClick={() => {
              onUpdate('delay', 24);
              onUpdate('delayUnit', 'hours');
            }}
            className="px-4 py-2 bg-dark-700 hover:bg-dark-600 rounded-lg text-sm text-gray-300"
          >
            24 Hours
          </button>
          <button
            onClick={() => {
              onUpdate('delay', 3);
              onUpdate('delayUnit', 'days');
            }}
            className="px-4 py-2 bg-dark-700 hover:bg-dark-600 rounded-lg text-sm text-gray-300"
          >
            3 Days
          </button>
          <button
            onClick={() => {
              onUpdate('delay', 1);
              onUpdate('delayUnit', 'weeks');
            }}
            className="px-4 py-2 bg-dark-700 hover:bg-dark-600 rounded-lg text-sm text-gray-300"
          >
            1 Week
          </button>
        </div>
      </div>
    </div>
  );
}