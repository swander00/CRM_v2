import React, { useState } from 'react';
import Select from 'react-select';

interface SMSFormProps {
  block: {
    content: {
      body: string;
    };
  };
  onUpdate: (field: string, value: any) => void;
}

const smsTemplates = [
  { 
    value: 'viewing_confirmation', 
    label: 'Viewing Confirmation',
    body: 'Your property viewing at {address} is confirmed for {time}. Reply YES to confirm or NO to reschedule.'
  },
  { 
    value: 'follow_up', 
    label: 'Follow-up',
    body: 'Hi {name}, following up on your property search. Would you like to schedule a call to discuss your requirements?'
  },
  { 
    value: 'price_update', 
    label: 'Price Update',
    body: 'Price update for {address}: Now listed at {price}. Interested in viewing? Reply YES for available times.'
  },
  { 
    value: 'reminder', 
    label: 'Appointment Reminder',
    body: 'Reminder: Your appointment at {address} is tomorrow at {time}. Looking forward to meeting you!'
  }
];

const pipelineOptions = [
  { value: 'new', label: 'New Lead' },
  { value: 'contacted', label: 'Contacted' },
  { value: 'qualified', label: 'Qualified' },
  { value: 'proposal', label: 'Proposal Sent' },
  { value: 'negotiating', label: 'Negotiating' },
  { value: 'closed', label: 'Closed Won' }
];

const tagOptions = [
  { value: 'vip', label: 'VIP' },
  { value: 'hot', label: 'Hot Lead' },
  { value: 'cold', label: 'Cold Lead' },
  { value: 'follow_up', label: 'Needs Follow-up' }
];

const actionOptions = [
  { value: 'sms_replied', label: 'SMS Replied' },
  { value: 'link_clicked', label: 'Link Clicked' },
  { value: 'form_submitted', label: 'Form Submitted' }
];

const customSelectStyles = {
  control: (base: any) => ({
    ...base,
    background: '#1F2937',
    borderColor: '#374151',
    '&:hover': {
      borderColor: '#4B5563'
    }
  }),
  menu: (base: any) => ({
    ...base,
    background: '#1F2937',
    border: '1px solid #374151'
  }),
  option: (base: any, state: { isSelected: boolean; isFocused: boolean }) => ({
    ...base,
    backgroundColor: state.isSelected ? '#3B82F6' : state.isFocused ? '#374151' : undefined,
    color: '#E5E7EB'
  }),
  multiValue: (base: any) => ({
    ...base,
    backgroundColor: '#374151',
    borderRadius: '4px'
  }),
  multiValueLabel: (base: any) => ({
    ...base,
    color: '#E5E7EB',
    padding: '2px 6px'
  }),
  multiValueRemove: (base: any) => ({
    ...base,
    color: '#9CA3AF',
    ':hover': {
      backgroundColor: '#4B5563',
      color: '#E5E7EB'
    }
  }),
  input: (base: any) => ({
    ...base,
    color: '#E5E7EB'
  })
};

export default function SMSForm({ block, onUpdate }: SMSFormProps) {
  const [stopConditions, setStopConditions] = useState<Array<{ type: string; value: string }>>([]);

  const handleTemplateSelect = (option: any) => {
    if (option) {
      const template = smsTemplates.find(t => t.value === option.value);
      if (template) {
        onUpdate('body', template.body);
      }
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold text-gray-100">SMS Message</h3>
      </div>

      {/* Template Selection */}
      <div>
        <label className="block text-sm font-medium text-gray-400 mb-2">
          Select Template
        </label>
        <Select
          options={smsTemplates}
          onChange={handleTemplateSelect}
          styles={customSelectStyles}
          placeholder="Choose a template or start from scratch..."
          isClearable
        />
      </div>

      {/* Message Content */}
      <div>
        <label className="block text-sm font-medium text-gray-400 mb-2">
          Message Content
        </label>
        <textarea
          value={block.content.body || ''}
          onChange={(e) => onUpdate('body', e.target.value)}
          className="w-full px-3 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200 resize-none h-32"
          placeholder="Enter SMS message..."
          maxLength={160}
        />
        <div className="text-xs text-gray-400 mt-1 text-right">
          {(block.content.body?.length || 0)}/160 characters
        </div>
      </div>

      {/* Stop Conditions */}
      <div>
        <h4 className="text-sm font-medium text-gray-400 mb-4">Stop Conditions</h4>
        <div className="space-y-4">
          {/* Pipeline Status */}
          <div>
            <label className="block text-sm text-gray-300 mb-2">Pipeline Status</label>
            <Select
              isMulti
              options={pipelineOptions}
              onChange={(options) => {
                const values = options.map(opt => ({ type: 'pipeline', value: opt.value }));
                setStopConditions(prev => [
                  ...prev.filter(c => c.type !== 'pipeline'),
                  ...values
                ]);
              }}
              styles={customSelectStyles}
              placeholder="Select pipeline statuses..."
            />
          </div>

          {/* Tags */}
          <div>
            <label className="block text-sm text-gray-300 mb-2">Tags</label>
            <Select
              isMulti
              options={tagOptions}
              onChange={(options) => {
                const values = options.map(opt => ({ type: 'tag', value: opt.value }));
                setStopConditions(prev => [
                  ...prev.filter(c => c.type !== 'tag'),
                  ...values
                ]);
              }}
              styles={customSelectStyles}
              placeholder="Select tags..."
            />
          </div>

          {/* User Actions */}
          <div>
            <label className="block text-sm text-gray-300 mb-2">User Actions</label>
            <Select
              isMulti
              options={actionOptions}
              onChange={(options) => {
                const values = options.map(opt => ({ type: 'action', value: opt.value }));
                setStopConditions(prev => [
                  ...prev.filter(c => c.type !== 'action'),
                  ...values
                ]);
              }}
              styles={customSelectStyles}
              placeholder="Select actions..."
            />
          </div>
        </div>
      </div>

      {/* SMS Best Practices */}
      <div className="mt-4 p-3 bg-dark-700/50 rounded-lg">
        <h4 className="text-sm font-medium text-gray-300 mb-2">SMS Best Practices</h4>
        <ul className="text-xs text-gray-400 space-y-1">
          <li>• Keep messages concise and clear</li>
          <li>• Include a clear call-to-action</li>
          <li>• Avoid using special characters</li>
          <li>• Consider time zones when scheduling</li>
        </ul>
      </div>
    </div>
  );
}