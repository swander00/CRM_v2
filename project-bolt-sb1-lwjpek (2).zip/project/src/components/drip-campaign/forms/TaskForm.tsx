import React, { useState } from 'react';
import Select from 'react-select';

interface TaskFormProps {
  block: {
    content: {
      title?: string;
      description?: string;
      dueDate?: string;
      priority?: 'high' | 'medium' | 'low';
      assignee?: string;
    };
  };
  onUpdate: (field: string, value: any) => void;
}

const priorityOptions = [
  { value: 'high', label: 'High Priority', color: '#EF4444' },
  { value: 'medium', label: 'Medium Priority', color: '#F59E0B' },
  { value: 'low', label: 'Low Priority', color: '#10B981' }
];

const taskTypeOptions = [
  { value: 'call', label: 'Phone Call' },
  { value: 'meeting', label: 'Meeting' },
  { value: 'showing', label: 'Property Showing' },
  { value: 'follow_up', label: 'Follow-up' },
  { value: 'document', label: 'Document Review' },
  { value: 'other', label: 'Other' }
];

const pipelineOptions = [
  { value: 'new', label: 'New Lead' },
  { value: 'contacted', label: 'Contacted' },
  { value: 'qualified', label: 'Qualified' },
  { value: 'proposal', label: 'Proposal Sent' },
  { value: 'negotiating', label: 'Negotiating' },
  { value: 'closed', label: 'Closed Won' }
];

const tagOptions = [
  { value: 'vip', label: 'VIP' },
  { value: 'hot', label: 'Hot Lead' },
  { value: 'cold', label: 'Cold Lead' },
  { value: 'follow_up', label: 'Needs Follow-up' }
];

const actionOptions = [
  { value: 'task_completed', label: 'Task Completed' },
  { value: 'task_skipped', label: 'Task Skipped' },
  { value: 'task_rescheduled', label: 'Task Rescheduled' }
];

const customSelectStyles = {
  control: (base: any) => ({
    ...base,
    background: '#1F2937',
    borderColor: '#374151',
    '&:hover': {
      borderColor: '#4B5563'
    }
  }),
  menu: (base: any) => ({
    ...base,
    background: '#1F2937',
    border: '1px solid #374151'
  }),
  option: (base: any, state: { isSelected: boolean; isFocused: boolean }) => ({
    ...base,
    backgroundColor: state.isSelected ? '#3B82F6' : state.isFocused ? '#374151' : undefined,
    color: '#E5E7EB'
  }),
  multiValue: (base: any) => ({
    ...base,
    backgroundColor: '#374151',
    borderRadius: '4px'
  }),
  multiValueLabel: (base: any) => ({
    ...base,
    color: '#E5E7EB',
    padding: '2px 6px'
  }),
  multiValueRemove: (base: any) => ({
    ...base,
    color: '#9CA3AF',
    ':hover': {
      backgroundColor: '#4B5563',
      color: '#E5E7EB'
    }
  }),
  input: (base: any) => ({
    ...base,
    color: '#E5E7EB'
  })
};

export default function TaskForm({ block, onUpdate }: TaskFormProps) {
  const [stopConditions, setStopConditions] = useState<Array<{ type: string; value: string }>>([]);

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold text-gray-100">Task Details</h3>
      </div>

      {/* Task Type */}
      <div>
        <label className="block text-sm font-medium text-gray-400 mb-2">
          Task Type
        </label>
        <Select
          options={taskTypeOptions}
          styles={customSelectStyles}
          value={taskTypeOptions.find(option => option.value === block.content?.title)}
          onChange={(option) => onUpdate('title', option?.value)}
          placeholder="Select task type..."
        />
      </div>

      {/* Description */}
      <div>
        <label className="block text-sm font-medium text-gray-400 mb-2">
          Description
        </label>
        <textarea
          value={block.content?.description || ''}
          onChange={(e) => onUpdate('description', e.target.value)}
          className="w-full px-3 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200 resize-none h-32"
          placeholder="Enter task description..."
        />
      </div>

      {/* Priority & Due Date */}
      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-400 mb-2">
            Priority
          </label>
          <Select
            options={priorityOptions}
            styles={customSelectStyles}
            value={priorityOptions.find(option => option.value === block.content?.priority)}
            onChange={(option) => onUpdate('priority', option?.value)}
            placeholder="Select priority..."
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-400 mb-2">
            Due Date
          </label>
          <input
            type="datetime-local"
            value={block.content?.dueDate || ''}
            onChange={(e) => onUpdate('dueDate', e.target.value)}
            className="w-full px-3 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200"
          />
        </div>
      </div>

      {/* Assignee */}
      <div>
        <label className="block text-sm font-medium text-gray-400 mb-2">
          Assignee
        </label>
        <input
          type="text"
          value={block.content?.assignee || ''}
          onChange={(e) => onUpdate('assignee', e.target.value)}
          className="w-full px-3 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200"
          placeholder="Enter assignee name or select from team..."
        />
      </div>

      {/* Stop Conditions */}
      <div>
        <h4 className="text-sm font-medium text-gray-400 mb-4">Stop Conditions</h4>
        <div className="space-y-4">
          {/* Pipeline Status */}
          <div>
            <label className="block text-sm text-gray-300 mb-2">Pipeline Status</label>
            <Select
              isMulti
              options={pipelineOptions}
              onChange={(options) => {
                const values = options.map(opt => ({ type: 'pipeline', value: opt.value }));
                setStopConditions(prev => [
                  ...prev.filter(c => c.type !== 'pipeline'),
                  ...values
                ]);
              }}
              styles={customSelectStyles}
              placeholder="Select pipeline statuses..."
            />
          </div>

          {/* Tags */}
          <div>
            <label className="block text-sm text-gray-300 mb-2">Tags</label>
            <Select
              isMulti
              options={tagOptions}
              onChange={(options) => {
                const values = options.map(opt => ({ type: 'tag', value: opt.value }));
                setStopConditions(prev => [
                  ...prev.filter(c => c.type !== 'tag'),
                  ...values
                ]);
              }}
              styles={customSelectStyles}
              placeholder="Select tags..."
            />
          </div>

          {/* User Actions */}
          <div>
            <label className="block text-sm text-gray-300 mb-2">Task Actions</label>
            <Select
              isMulti
              options={actionOptions}
              onChange={(options) => {
                const values = options.map(opt => ({ type: 'action', value: opt.value }));
                setStopConditions(prev => [
                  ...prev.filter(c => c.type !== 'action'),
                  ...values
                ]);
              }}
              styles={customSelectStyles}
              placeholder="Select actions..."
            />
          </div>
        </div>
      </div>

      {/* Task Best Practices */}
      <div className="mt-4 p-3 bg-dark-700/50 rounded-lg">
        <h4 className="text-sm font-medium text-gray-300 mb-2">Task Best Practices</h4>
        <ul className="text-xs text-gray-400 space-y-1">
          <li>• Set clear and specific task objectives</li>
          <li>• Assign realistic due dates</li>
          <li>• Include all necessary details in the description</li>
          <li>• Consider team member workload when assigning</li>
        </ul>
      </div>
    </div>
  );
}