import React, { useState } from 'react';
import Select from 'react-select';
import { Facebook, Instagram, Linkedin, Twitter, Image, Link2, Calendar } from 'lucide-react';

interface SocialFormProps {
  block: {
    content?: {
      platforms?: string[];
      content?: string;
      media?: string[];
      scheduledTime?: string;
      hashtags?: string[];
    };
  };
  onUpdate: (field: string, value: any) => void;
}

const platforms = [
  { value: 'facebook', label: 'Facebook', icon: Facebook },
  { value: 'instagram', label: 'Instagram', icon: Instagram },
  { value: 'linkedin', label: 'LinkedIn', icon: Linkedin },
  { value: 'twitter', label: 'X (Twitter)', icon: Twitter }
];

const customSelectStyles = {
  control: (base: any) => ({
    ...base,
    background: '#1F2937',
    borderColor: '#374151',
    '&:hover': {
      borderColor: '#4B5563'
    }
  }),
  menu: (base: any) => ({
    ...base,
    background: '#1F2937',
    border: '1px solid #374151'
  }),
  option: (base: any, state: { isSelected: boolean; isFocused: boolean }) => ({
    ...base,
    backgroundColor: state.isSelected ? '#3B82F6' : state.isFocused ? '#374151' : undefined,
    color: '#E5E7EB'
  }),
  input: (base: any) => ({
    ...base,
    color: '#E5E7EB'
  })
};

export default function SocialForm({ block, onUpdate }: SocialFormProps) {
  const [content, setContent] = useState(block.content?.content || '');

  const handleContentChange = (value: string) => {
    setContent(value);
    onUpdate('content', value);
  };

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold text-gray-100">Social Media Post</h3>
      </div>

      {/* Platform Selection */}
      <div>
        <label className="block text-sm font-medium text-gray-400 mb-2">
          Platforms
        </label>
        <Select
          isMulti
          options={platforms}
          value={platforms.filter(p => block.content?.platforms?.includes(p.value))}
          onChange={(selected) => onUpdate('platforms', selected.map(s => s.value))}
          styles={customSelectStyles}
          formatOptionLabel={({ label, icon: Icon }) => (
            <div className="flex items-center gap-2">
              <Icon className="w-4 h-4" />
              <span>{label}</span>
            </div>
          )}
          placeholder="Select platforms..."
        />
      </div>

      {/* Post Content */}
      <div>
        <label className="block text-sm font-medium text-gray-400 mb-2">
          Post Content
        </label>
        <textarea
          value={content}
          onChange={(e) => handleContentChange(e.target.value)}
          className="w-full h-32 px-3 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200 resize-none"
          placeholder="Write your post content..."
        />
        <div className="text-xs text-gray-400 mt-1">
          {280 - content.length} characters remaining
        </div>
      </div>

      {/* Media and Links */}
      <div className="flex gap-3">
        <button className="btn-secondary flex items-center gap-2">
          <Image className="w-4 h-4" />
          Add Media
        </button>
        <button className="btn-secondary flex items-center gap-2">
          <Link2 className="w-4 h-4" />
          Add Link
        </button>
        <button className="btn-secondary flex items-center gap-2">
          <Calendar className="w-4 h-4" />
          Schedule
        </button>
      </div>

      {/* Hashtags */}
      <div>
        <label className="block text-sm font-medium text-gray-400 mb-2">
          Hashtags
        </label>
        <Select
          isMulti
          options={[
            { value: 'realestate', label: '#realestate' },
            { value: 'property', label: '#property' },
            { value: 'luxuryhomes', label: '#luxuryhomes' },
            { value: 'investment', label: '#investment' }
          ]}
          value={(block.content?.hashtags || []).map(tag => ({ value: tag, label: `#${tag}` }))}
          onChange={(selected) => onUpdate('hashtags', selected.map(s => s.value))}
          styles={customSelectStyles}
          placeholder="Add hashtags..."
        />
      </div>

      {/* Best Practices */}
      <div className="mt-4 p-3 bg-dark-700/50 rounded-lg">
        <h4 className="text-sm font-medium text-gray-300 mb-2">Social Media Best Practices</h4>
        <ul className="text-xs text-gray-400 space-y-1">
          <li>• Keep content engaging and concise</li>
          <li>• Use high-quality images or videos</li>
          <li>• Include relevant hashtags</li>
          <li>• Post at optimal times for each platform</li>
          <li>• Engage with comments and responses</li>
        </ul>
      </div>
    </div>
  );
}