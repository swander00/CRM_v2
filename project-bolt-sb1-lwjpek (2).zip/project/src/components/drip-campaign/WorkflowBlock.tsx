import React from 'react';
import { Mail, MessageSquare, CheckSquare, Clock, GitBranch, Share2 } from 'lucide-react';

interface Block {
  id: string;
  type: 'email' | 'sms' | 'task' | 'wait' | 'branch' | 'social';
  content?: {
    subject?: string;
    body?: string;
    delay?: number;
    delayUnit?: 'hours' | 'days' | 'weeks';
  };
}

interface WorkflowBlockProps {
  block: Block;
  isSelected: boolean;
  onClick: () => void;
}

const blockStyles = {
  email: {
    icon: Mail,
    colors: 'bg-blue-500/10 border-blue-500/20 text-blue-400'
  },
  sms: {
    icon: MessageSquare,
    colors: 'bg-green-500/10 border-green-500/20 text-green-400'
  },
  task: {
    icon: CheckSquare,
    colors: 'bg-yellow-500/10 border-yellow-500/20 text-yellow-400'
  },
  wait: {
    icon: Clock,
    colors: 'bg-gray-500/10 border-gray-500/20 text-gray-400'
  },
  branch: {
    icon: GitBranch,
    colors: 'bg-orange-500/10 border-orange-500/20 text-orange-400'
  },
  social: {
    icon: Share2,
    colors: 'bg-purple-500/10 border-purple-500/20 text-purple-400'
  }
};

export default function WorkflowBlock({ block, isSelected, onClick }: WorkflowBlockProps) {
  const style = blockStyles[block.type];
  const Icon = style.icon;

  return (
    <div
      className={`p-4 rounded-lg border transition-all cursor-pointer ${style.colors} ${
        isSelected ? 'ring-2 ring-primary-500' : ''
      }`}
      onClick={onClick}
    >
      <div className="flex items-center gap-3">
        <Icon className="w-5 h-5" />
        <span className="font-medium capitalize">
          {block.type === 'branch' ? 'Branch Campaign' : block.type}
        </span>
      </div>

      {block.content?.delay !== undefined && (
        <div className="mt-2 flex items-center gap-2 text-sm opacity-75">
          <Clock className="w-4 h-4" />
          <span>
            {block.content.delay} {block.content.delayUnit}
          </span>
        </div>
      )}
    </div>
  );
}