import React from 'react';
import { 
  Mail, 
  MessageSquare, 
  CheckSquare, 
  Clock, 
  GitBranch, 
  FileText, 
  Info 
} from 'lucide-react';

const elements = [
  {
    id: 'email',
    icon: Mail,
    label: 'Email',
    description: 'Add an email step',
    color: 'bg-blue-500/10 text-blue-400 border-blue-500/20'
  },
  {
    id: 'sms',
    icon: MessageSquare,
    label: 'SMS',
    description: 'Add an SMS message step',
    color: 'bg-green-500/10 text-green-400 border-green-500/20'
  },
  {
    id: 'task',
    icon: CheckSquare,
    label: 'Task',
    description: 'Add a task or reminder',
    color: 'bg-yellow-500/10 text-yellow-400 border-yellow-500/20'
  },
  {
    id: 'wait',
    icon: Clock,
    label: 'Wait',
    description: 'Add a delay between steps',
    color: 'bg-gray-500/10 text-gray-400 border-gray-500/20'
  },
  {
    id: 'branch',
    icon: GitBranch,
    label: 'Branch',
    description: 'Add conditional logic',
    color: 'bg-orange-500/10 text-orange-400 border-orange-500/20'
  }
];

const templates = [
  {
    id: 'email-templates',
    icon: FileText,
    label: 'Email Templates',
    items: [
      'Welcome Email',
      'Property Viewing',
      'Follow-up',
      'Market Update'
    ]
  },
  {
    id: 'sms-templates',
    icon: MessageSquare,
    label: 'SMS Templates',
    items: [
      'Viewing Confirmation',
      'Quick Follow-up',
      'Appointment Reminder'
    ]
  }
];

export default function ElementsSidebar() {
  return (
    <div className="w-64 bg-dark-800 border-r border-dark-700 p-4">
      <div className="space-y-6">
        {/* Elements Section */}
        <div>
          <h3 className="text-sm font-medium text-gray-400 mb-3">Elements</h3>
          <div className="space-y-2">
            {elements.map((element) => (
              <div key={element.id}>
                <div
                  className={`flex items-center gap-3 p-3 rounded-lg border cursor-move transition-colors ${element.color}`}
                  data-tooltip-id={`tooltip-${element.id}`}
                >
                  <element.icon className="w-5 h-5" />
                  <span>{element.label}</span>
                  <Info className="w-4 h-4 ml-auto opacity-50" />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Templates Section */}
        <div>
          <h3 className="text-sm font-medium text-gray-400 mb-3">Templates</h3>
          <div className="space-y-2">
            {templates.map((template) => (
              <div key={template.id} className="group">
                <button className="w-full flex items-center gap-2 px-4 py-2 rounded-lg bg-dark-700 hover:bg-dark-600 text-gray-300 transition-colors">
                  <template.icon className="w-4 h-4" />
                  <span>{template.label}</span>
                </button>
                {/* Template Items Dropdown */}
                <div className="hidden group-hover:block mt-1 ml-4 pl-2 border-l border-dark-600">
                  {template.items.map((item, index) => (
                    <button
                      key={index}
                      className="w-full text-left px-4 py-1.5 text-sm text-gray-400 hover:text-gray-300"
                    >
                      {item}
                    </button>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}