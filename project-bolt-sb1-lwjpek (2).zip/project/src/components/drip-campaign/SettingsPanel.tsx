import React, { useState } from 'react';
import { X, Clock, Calendar } from 'lucide-react';
import Select from 'react-select';
import EmailForm from './forms/EmailForm';
import SMSForm from './forms/SMSForm';
import TaskForm from './forms/TaskForm';
import WaitForm from './forms/WaitForm';
import BranchForm from './forms/BranchForm';
import SocialForm from './forms/SocialForm';

interface Block {
  id: string;
  type: 'email' | 'sms' | 'task' | 'wait' | 'branch' | 'social';
  content?: {
    subject?: string;
    body?: string;
    delay?: number;
    delayUnit?: 'hours' | 'days' | 'weeks';
  };
}

interface SettingsPanelProps {
  selectedBlock?: Block;
  onUpdate?: (id: string, updates: any) => void;
}

export default function SettingsPanel({ selectedBlock, onUpdate }: SettingsPanelProps) {
  const handleBlockUpdate = (field: string, value: any) => {
    if (selectedBlock && onUpdate) {
      onUpdate(selectedBlock.id, { [field]: value });
    }
  };

  const renderBlockSettings = () => {
    if (!selectedBlock) return null;

    switch (selectedBlock.type) {
      case 'email':
        return <EmailForm block={selectedBlock} onUpdate={handleBlockUpdate} />;
      case 'sms':
        return <SMSForm block={selectedBlock} onUpdate={handleBlockUpdate} />;
      case 'task':
        return <TaskForm block={selectedBlock} onUpdate={handleBlockUpdate} />;
      case 'wait':
        return <WaitForm block={selectedBlock} onUpdate={handleBlockUpdate} />;
      case 'branch':
        return <BranchForm block={selectedBlock} onUpdate={handleBlockUpdate} />;
      case 'social':
        return <SocialForm block={selectedBlock} onUpdate={handleBlockUpdate} />;
      default:
        return (
          <div className="text-gray-400">
            Select a block to edit its settings
          </div>
        );
    }
  };

  // If a block is selected, show its settings
  if (selectedBlock) {
    return (
      <div className="w-96 bg-dark-800 border-l border-dark-700 p-6">
        {renderBlockSettings()}
      </div>
    );
  }

  // Rest of the component remains unchanged...
  return (
    <div className="w-96 bg-dark-800 border-l border-dark-700 p-6">
      <div className="text-gray-400">
        Select a block to edit its settings
      </div>
    </div>
  );
}