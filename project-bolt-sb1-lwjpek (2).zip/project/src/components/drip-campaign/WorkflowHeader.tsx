import React from 'react';
import { ChevronRight, Save, Play } from 'lucide-react';

export default function WorkflowHeader() {
  return (
    <div className="h-16 bg-dark-800 border-b border-dark-700 px-6">
      <div className="h-full flex items-center justify-between">
        <div>
          <div className="flex items-center gap-2 text-sm text-gray-400 mb-1">
            <span>Home</span>
            <ChevronRight className="w-4 h-4" />
            <span>Campaigns</span>
            <ChevronRight className="w-4 h-4" />
            <span className="text-gray-200">Create Drip Campaign</span>
          </div>
          <h1 className="text-xl font-semibold text-gray-100">Drip Campaign Builder</h1>
        </div>

        <div className="flex items-center gap-3">
          <button className="btn-secondary flex items-center gap-2">
            <Save className="w-4 h-4" />
            Save as Draft
          </button>
          <button className="btn-primary flex items-center gap-2">
            <Play className="w-4 h-4" />
            Launch Campaign
          </button>
        </div>
      </div>
    </div>
  );
}