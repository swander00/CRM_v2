import React from 'react';
import { Mail, MessageSquare, CheckSquare, Clock, GitBranch, Share2 } from 'lucide-react';

interface AddBlockMenuProps {
  onSelect: (type: 'email' | 'sms' | 'task' | 'wait' | 'branch' | 'social') => void;
  onClose: () => void;
  allowedTypes?: string[];
}

const blockTypes = [
  {
    type: 'email',
    icon: Mail,
    label: 'Email',
    color: 'text-blue-400 bg-blue-500/10 border-blue-500/20'
  },
  {
    type: 'sms',
    icon: MessageSquare,
    label: 'SMS',
    color: 'text-green-400 bg-green-500/10 border-green-500/20'
  },
  {
    type: 'task',
    icon: CheckSquare,
    label: 'Task',
    color: 'text-yellow-400 bg-yellow-500/10 border-yellow-500/20'
  },
  {
    type: 'wait',
    icon: Clock,
    label: 'Wait',
    color: 'text-gray-400 bg-gray-500/10 border-gray-500/20'
  },
  {
    type: 'branch',
    icon: GitBranch,
    label: 'Branch Campaign',
    color: 'text-orange-400 bg-orange-500/10 border-orange-500/20'
  },
  {
    type: 'social',
    icon: Share2,
    label: 'Social Post',
    color: 'text-purple-400 bg-purple-500/10 border-purple-500/20'
  }
] as const;

export default function AddBlockMenu({ onSelect, onClose, allowedTypes = [] }: AddBlockMenuProps) {
  const filteredBlockTypes = allowedTypes.length > 0 
    ? blockTypes.filter(block => allowedTypes.includes(block.type))
    : blockTypes;

  return (
    <div 
      className="absolute left-1/2 -translate-x-1/2 z-50 bg-dark-800 border border-dark-700 rounded-lg shadow-lg p-2"
      onClick={(e) => e.stopPropagation()}
    >
      <div className="flex flex-col gap-2">
        {filteredBlockTypes.map((block) => {
          const Icon = block.icon;
          return (
            <button
              key={block.type}
              onClick={() => onSelect(block.type)}
              className={`flex items-center gap-3 p-3 rounded-lg border transition-colors hover:bg-dark-700 ${block.color}`}
            >
              <Icon className="w-5 h-5" />
              <span>{block.label}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}