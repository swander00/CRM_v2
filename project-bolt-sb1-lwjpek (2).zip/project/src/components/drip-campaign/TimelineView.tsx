import React, { useState } from 'react';
import { ChevronUp, Clock, Mail, MessageSquare } from 'lucide-react';

export default function TimelineView() {
  const [isExpanded, setIsExpanded] = useState(false);

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-dark-800 border-t border-dark-700">
      <button
        onClick={() => setIsExpanded(!isExpanded)}
        className="absolute -top-4 left-1/2 -translate-x-1/2 flex items-center gap-2 px-4 py-1 bg-dark-800 border border-dark-700 rounded-t-lg text-sm text-gray-400 hover:text-gray-300"
      >
        Timeline View
        <ChevronUp className={`w-4 h-4 transform transition-transform ${isExpanded ? 'rotate-180' : ''}`} />
      </button>

      {isExpanded && (
        <div className="p-4">
          <div className="flex items-center gap-8">
            {/* Timeline Steps */}
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2 px-3 py-2 bg-primary-500/10 border border-primary-500/20 rounded-lg text-primary-400">
                Start
              </div>
              <Clock className="w-4 h-4 text-gray-500" />
              <div className="flex items-center gap-2 px-3 py-2 bg-blue-500/10 border border-blue-500/20 rounded-lg text-blue-400">
                <Mail className="w-4 h-4" />
                <span>Welcome Email</span>
              </div>
              <Clock className="w-4 h-4 text-gray-500" />
              <div className="flex items-center gap-2 px-3 py-2 bg-green-500/10 border border-green-500/20 rounded-lg text-green-400">
                <MessageSquare className="w-4 h-4" />
                <span>Follow-up SMS</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}