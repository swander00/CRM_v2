import React, { useState } from 'react';
import { Plus } from 'lucide-react';
import WorkflowBlock from './WorkflowBlock';
import AddBlockMenu from './AddBlockMenu';

interface Block {
  id: string;
  type: 'email' | 'sms' | 'task' | 'wait' | 'branch' | 'social';
  content?: {
    subject?: string;
    body?: string;
    delay?: number;
    delayUnit?: 'hours' | 'days' | 'weeks';
  };
}

interface WorkflowCanvasProps {
  blocks: Block[];
  setBlocks: React.Dispatch<React.SetStateAction<Block[]>>;
  selectedBlock?: Block;
  onSelectBlock: (block: Block | undefined) => void;
  allowedTypes?: string[];
}

export default function WorkflowCanvas({ 
  blocks, 
  setBlocks, 
  selectedBlock, 
  onSelectBlock,
  allowedTypes = ['email', 'sms', 'task', 'wait', 'branch']
}: WorkflowCanvasProps) {
  const [showAddMenu, setShowAddMenu] = useState(false);
  const [insertIndex, setInsertIndex] = useState<number | null>(null);

  const handleAddBlock = (type: Block['type']) => {
    if (!allowedTypes.includes(type)) return;
    
    const newBlock: Block = {
      id: `block-${Date.now()}`,
      type,
      content: {
        delay: 0,
        delayUnit: 'hours'
      }
    };

    if (insertIndex !== null) {
      const updatedBlocks = [...blocks];
      updatedBlocks.splice(insertIndex, 0, newBlock);
      setBlocks(updatedBlocks);
    } else {
      setBlocks([...blocks, newBlock]);
    }
    
    onSelectBlock(newBlock);
    setShowAddMenu(false);
    setInsertIndex(null);
  };

  const handleAddClick = (index: number) => {
    setInsertIndex(index);
    setShowAddMenu(true);
  };

  return (
    <div className="flex-1 bg-dark-900 overflow-auto relative min-h-[calc(100vh-64px)]">
      {/* Grid Background */}
      <div 
        className="absolute inset-0"
        style={{
          backgroundImage: 'radial-gradient(circle, #374151 1px, transparent 1px)',
          backgroundSize: '24px 24px'
        }}
      />

      {/* Workflow Content */}
      <div className="relative flex flex-col items-center p-8 min-h-full">
        {/* Start Block */}
        <div className="px-6 py-3 bg-primary-500/10 border border-primary-500/20 rounded-lg text-primary-400">
          Campaign Start
        </div>

        {/* Initial Add Button */}
        <div className="w-px h-8 bg-dark-700" />
        <button
          onClick={() => handleAddClick(0)}
          className="w-8 h-8 bg-dark-800 border border-dark-700 rounded-full flex items-center justify-center text-gray-400 hover:text-gray-300 hover:border-primary-500 transition-colors"
        >
          <Plus className="w-5 h-5" />
        </button>

        {/* Workflow Blocks */}
        {blocks.map((block, index) => (
          <React.Fragment key={block.id}>
            {/* Block */}
            <div className="w-px h-8 bg-dark-700" />
            <WorkflowBlock
              block={block}
              isSelected={selectedBlock?.id === block.id}
              onClick={() => onSelectBlock(block)}
            />

            {/* Add Button after each block */}
            <div className="w-px h-8 bg-dark-700" />
            <button
              onClick={() => handleAddClick(index + 1)}
              className="w-8 h-8 bg-dark-800 border border-dark-700 rounded-full flex items-center justify-center text-gray-400 hover:text-gray-300 hover:border-primary-500 transition-colors"
            >
              <Plus className="w-5 h-5" />
            </button>
          </React.Fragment>
        ))}

        {/* Add Block Menu */}
        {showAddMenu && (
          <div className="absolute" style={{ top: `${insertIndex === 0 ? 120 : 120 + insertIndex! * 200}px` }}>
            <AddBlockMenu
              onSelect={handleAddBlock}
              onClose={() => {
                setShowAddMenu(false);
                setInsertIndex(null);
              }}
              allowedTypes={allowedTypes}
            />
          </div>
        )}
      </div>
    </div>
  );
}