import React from 'react';
import Select from 'react-select';

const options = [
  {
    label: 'Website',
    options: [
      { value: 'website1', label: 'Website 1' },
      { value: 'website2', label: 'Website 2' },
      { value: 'website3', label: 'Website 3' }
    ]
  },
  {
    label: 'Google Ads',
    options: [
      { value: 'google1', label: 'Ad Name 1' },
      { value: 'google2', label: 'Ad Name 2' },
      { value: 'google3', label: 'Ad Name 3' }
    ]
  },
  {
    label: 'Instagram',
    options: [
      { value: 'instagram1', label: 'Ad Name 1' },
      { value: 'instagram2', label: 'Ad Name 2' },
      { value: 'instagram3', label: 'Ad Name 3' }
    ]
  },
  {
    label: 'Facebook',
    options: [
      { value: 'facebook1', label: 'Ad Name 1' },
      { value: 'facebook2', label: 'Ad Name 2' },
      { value: 'facebook3', label: 'Ad Name 3' }
    ]
  },
  {
    label: 'LinkedIn',
    options: [
      { value: 'linkedin1', label: 'Ad Name 1' },
      { value: 'linkedin2', label: 'Ad Name 2' },
      { value: 'linkedin3', label: 'Ad Name 3' }
    ]
  },
  {
    label: 'Other',
    options: [
      { value: 'other1', label: 'Ad Name 1' },
      { value: 'other2', label: 'Ad Name 2' },
      { value: 'other3', label: 'Ad Name 3' }
    ]
  }
];

const customStyles = {
  control: (base: any) => ({
    ...base,
    background: '#1F2937',
    borderColor: '#374151',
    '&:hover': {
      borderColor: '#4B5563'
    }
  }),
  menu: (base: any) => ({
    ...base,
    background: '#1F2937',
    border: '1px solid #374151'
  }),
  group: (base: any) => ({
    ...base,
    paddingTop: 8,
    paddingBottom: 8
  }),
  groupHeading: (base: any) => ({
    ...base,
    color: '#9CA3AF',
    fontWeight: 600,
    fontSize: '0.875rem'
  }),
  option: (base: any, state: { isSelected: boolean; isFocused: boolean }) => ({
    ...base,
    backgroundColor: state.isSelected ? '#3B82F6' : state.isFocused ? '#374151' : undefined,
    '&:active': {
      backgroundColor: '#2563EB'
    }
  }),
  singleValue: (base: any) => ({
    ...base,
    color: '#E5E7EB'
  }),
  input: (base: any) => ({
    ...base,
    color: '#E5E7EB'
  }),
  clearIndicator: (base: any) => ({
    ...base,
    color: '#6B7280',
    '&:hover': {
      color: '#9CA3AF'
    }
  })
};

export default function LeadSourceDropdown() {
  return (
    <Select
      options={options}
      styles={customStyles}
      placeholder="Lead Source"
      className="w-48"
      isClearable
      theme={(theme) => ({
        ...theme,
        colors: {
          ...theme.colors,
          primary: '#3B82F6',
          primary75: '#60A5FA',
          primary50: '#93C5FD',
          primary25: '#BFDBFE',
          neutral0: '#1F2937',
          neutral5: '#374151',
          neutral10: '#4B5563',
          neutral20: '#6B7280',
          neutral30: '#9CA3AF',
          neutral40: '#D1D5DB',
          neutral50: '#E5E7EB',
          neutral60: '#F3F4F6',
          neutral70: '#F9FAFB',
          neutral80: '#FFFFFF',
          neutral90: '#FFFFFF'
        }
      })}
    />
  );
}