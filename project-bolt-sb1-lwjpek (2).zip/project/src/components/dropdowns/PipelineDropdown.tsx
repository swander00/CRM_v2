import React from 'react';
import Select from 'react-select';

const options = [
  { 
    value: 'new', 
    label: 'New Lead',
    color: '#94A3B8' // slate-400
  },
  { 
    value: 'contacted', 
    label: 'Tried Contacting',
    color: '#60A5FA' // blue-400
  },
  { 
    value: 'qualified', 
    label: 'Qualified',
    color: '#34D399' // emerald-400
  },
  { 
    value: 'warm', 
    label: 'Warm/Nurturing',
    color: '#FBBF24' // amber-400
  },
  { 
    value: 'hot', 
    label: 'Hot/Ready',
    color: '#F87171' // red-400
  },
  { 
    value: 'showing', 
    label: 'Showing',
    color: '#A78BFA' // violet-400
  },
  { 
    value: 'negotiating', 
    label: 'Negotiating',
    color: '#FB923C' // orange-400
  },
  { 
    value: 'pending', 
    label: 'Pending',
    color: '#38BDF8' // sky-400
  },
  { 
    value: 'closed', 
    label: 'Closed',
    color: '#4ADE80' // green-400
  }
];

const customStyles = {
  control: (base: any) => ({
    ...base,
    background: '#1F2937',
    borderColor: '#374151',
    minHeight: '38px',
    '&:hover': {
      borderColor: '#4B5563'
    }
  }),
  menu: (base: any) => ({
    ...base,
    background: '#1F2937',
    border: '1px solid #374151',
    boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06)'
  }),
  option: (base: any, { data, isSelected, isFocused }: any) => ({
    ...base,
    backgroundColor: isSelected ? '#3B82F6' : isFocused ? '#374151' : undefined,
    color: '#E5E7EB',
    padding: '8px 12px',
    display: 'flex',
    alignItems: 'center',
    cursor: 'pointer',
    '&:before': {
      content: '""',
      display: 'block',
      width: '8px',
      height: '8px',
      borderRadius: '50%',
      backgroundColor: data.color,
      marginRight: '8px',
      flexShrink: 0
    },
    '&:active': {
      backgroundColor: '#2563EB'
    }
  }),
  singleValue: (base: any, { data }: any) => ({
    ...base,
    color: '#E5E7EB',
    display: 'flex',
    alignItems: 'center',
    '&:before': {
      content: '""',
      display: 'block',
      width: '8px',
      height: '8px',
      borderRadius: '50%',
      backgroundColor: data.color,
      marginRight: '8px',
      flexShrink: 0
    }
  }),
  input: (base: any) => ({
    ...base,
    color: '#E5E7EB'
  }),
  placeholder: (base: any) => ({
    ...base,
    color: '#9CA3AF'
  }),
  dropdownIndicator: (base: any) => ({
    ...base,
    color: '#6B7280',
    '&:hover': {
      color: '#9CA3AF'
    }
  }),
  clearIndicator: (base: any) => ({
    ...base,
    color: '#6B7280',
    '&:hover': {
      color: '#9CA3AF'
    }
  })
};

export default function PipelineDropdown() {
  return (
    <Select
      options={options}
      styles={customStyles}
      placeholder="Pipeline Stage"
      className="w-56"
      isClearable
      isSearchable={false}
      theme={(theme) => ({
        ...theme,
        colors: {
          ...theme.colors,
          primary: '#3B82F6',
          primary75: '#60A5FA',
          primary50: '#93C5FD',
          primary25: '#BFDBFE',
          neutral0: '#1F2937',
          neutral5: '#374151',
          neutral10: '#4B5563',
          neutral20: '#6B7280',
          neutral30: '#9CA3AF',
          neutral40: '#D1D5DB',
          neutral50: '#E5E7EB',
          neutral60: '#F3F4F6',
          neutral70: '#F9FAFB',
          neutral80: '#FFFFFF',
          neutral90: '#FFFFFF'
        }
      })}
    />
  );
}