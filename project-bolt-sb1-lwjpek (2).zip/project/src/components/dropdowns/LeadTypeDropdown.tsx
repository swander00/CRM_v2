import React from 'react';
import Select from 'react-select';

const options = [
  {
    label: 'Buyers',
    options: [
      { value: 'first-time', label: 'First-Time Buyer' },
      { value: 'move-up', label: 'Move-Up Buyer' },
      { value: 'downsizing', label: 'Downsizing Buyer' },
      { value: 'investor', label: 'Investor Buyer' },
      { value: 'luxury', label: 'Luxury Buyer' },
      { value: 'vacation', label: 'Vacation Property Buyer' },
      { value: 'new-construction', label: 'New Construction Buyer' },
      { value: 'land', label: 'Land Buyer' },
      { value: 'reconstruction', label: 'Reconstruction Buyer' },
      { value: 'foreclosure', label: 'Foreclosure Buyer' }
    ]
  },
  {
    label: 'Sellers',
    options: [
      { value: 'homeowner', label: 'Homeowner Seller' },
      { value: 'investment', label: 'Investment Property Seller' },
      { value: 'relocation', label: 'Relocation Seller' },
      { value: 'distressed', label: 'Distressed Seller' },
      { value: 'luxury-seller', label: 'Luxury Seller' },
      { value: 'assignment', label: 'Assignment Seller' },
      { value: 'fsbo', label: 'FSBO' },
      { value: 'probate', label: 'Probate Seller' },
      { value: 'multi-property', label: 'Multi-Property Seller' },
      { value: 'land-seller', label: 'Land Seller' }
    ]
  },
  {
    label: 'Landlords',
    options: [
      { value: 'first-time-landlord', label: 'First-Time Landlord' },
      { value: 'experienced-landlord', label: 'Experienced Landlord' },
      { value: 'institutional-landlord', label: 'Institutional Landlord' },
      { value: 'vacation-rental', label: 'Vacation Rental Landlord' },
      { value: 'commercial-landlord', label: 'Commercial Property Landlord' }
    ]
  },
  {
    label: 'Tenants',
    options: [
      { value: 'long-term', label: 'Long-Term Renter' },
      { value: 'short-term', label: 'Short-Term Renter' },
      { value: 'luxury-renter', label: 'Luxury Renter' },
      { value: 'commercial-tenant', label: 'Commercial Tenant' },
      { value: 'relocation-tenant', label: 'Relocation Tenant' }
    ]
  }
];

const customStyles = {
  control: (base: any) => ({
    ...base,
    background: '#1F2937',
    borderColor: '#374151',
    '&:hover': {
      borderColor: '#4B5563'
    }
  }),
  menu: (base: any) => ({
    ...base,
    background: '#1F2937',
    border: '1px solid #374151'
  }),
  group: (base: any) => ({
    ...base,
    paddingTop: 8,
    paddingBottom: 8
  }),
  groupHeading: (base: any) => ({
    ...base,
    color: '#9CA3AF',
    fontWeight: 600,
    fontSize: '0.875rem'
  }),
  option: (base: any, state: { isSelected: boolean; isFocused: boolean }) => ({
    ...base,
    backgroundColor: state.isSelected ? '#3B82F6' : state.isFocused ? '#374151' : undefined,
    '&:active': {
      backgroundColor: '#2563EB'
    }
  }),
  singleValue: (base: any) => ({
    ...base,
    color: '#E5E7EB'
  }),
  input: (base: any) => ({
    ...base,
    color: '#E5E7EB'
  }),
  clearIndicator: (base: any) => ({
    ...base,
    color: '#6B7280',
    '&:hover': {
      color: '#9CA3AF'
    }
  })
};

export default function LeadTypeDropdown() {
  return (
    <Select
      options={options}
      styles={customStyles}
      placeholder="Lead Type"
      className="w-48"
      isClearable
      theme={(theme) => ({
        ...theme,
        colors: {
          ...theme.colors,
          primary: '#3B82F6',
          primary75: '#60A5FA',
          primary50: '#93C5FD',
          primary25: '#BFDBFE',
          neutral0: '#1F2937',
          neutral5: '#374151',
          neutral10: '#4B5563',
          neutral20: '#6B7280',
          neutral30: '#9CA3AF',
          neutral40: '#D1D5DB',
          neutral50: '#E5E7EB',
          neutral60: '#F3F4F6',
          neutral70: '#F9FAFB',
          neutral80: '#FFFFFF',
          neutral90: '#FFFFFF'
        }
      })}
    />
  );
}