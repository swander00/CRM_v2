import React, { useState } from 'react';
import LeadTableRow from './LeadTableRow';
import { useLeads } from '../contexts/LeadContext';
import DeleteLeadModal from './modals/DeleteLeadModal';

export default function LeadTable() {
  const { leads } = useLeads();
  const [deleteModal, setDeleteModal] = useState<{ show: boolean; lead?: any }>({
    show: false
  });

  return (
    <>
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-dark-800 border-b border-dark-700">
            <tr>
              <th className="px-4 py-2 text-left font-medium text-gray-400">INFO</th>
              <th className="px-4 py-2 text-left font-medium text-gray-400">PIPELINE</th>
              <th className="px-4 py-2 text-left font-medium text-gray-400">SOURCE</th>
              <th className="px-4 py-2 text-left font-medium text-gray-400">REQUIREMENTS</th>
              <th className="px-4 py-2 text-left font-medium text-gray-400">ACTIVITY</th>
              <th className="px-4 py-2 text-left font-medium text-gray-400">NEXT TASK</th>
              <th className="px-4 py-2 text-left font-medium text-gray-400">ASSIGNED</th>
              <th className="px-4 py-2 text-left font-medium text-gray-400">REGISTRATION</th>
              <th className="px-4 py-2 text-left font-medium text-gray-400"></th>
            </tr>
          </thead>
          <tbody className="divide-y divide-dark-700">
            {leads.map((lead) => (
              <LeadTableRow 
                key={lead.id} 
                lead={lead}
                onDeleteClick={() => setDeleteModal({ show: true, lead })}
              />
            ))}
          </tbody>
        </table>
      </div>

      {deleteModal.show && deleteModal.lead && (
        <DeleteLeadModal
          leadName={deleteModal.lead.name}
          onClose={() => setDeleteModal({ show: false })}
          onConfirm={() => {
            deleteModal.lead && archiveLead(deleteModal.lead.id);
            setDeleteModal({ show: false });
          }}
        />
      )}
    </>
  );
}