import React from 'react';
import { Image, Link2, Calendar, Plus } from 'lucide-react';
import Select from 'react-select';
import { Post } from './types';

interface PostEditorProps {
  currentPost: Post;
  onPostChange: (post: Post) => void;
  onAddPost: () => void;
}

const customSelectStyles = {
  control: (base: any) => ({
    ...base,
    background: '#1F2937',
    borderColor: '#374151',
    '&:hover': {
      borderColor: '#4B5563'
    }
  }),
  menu: (base: any) => ({
    ...base,
    background: '#1F2937',
    border: '1px solid #374151'
  }),
  option: (base: any, state: { isSelected: boolean; isFocused: boolean }) => ({
    ...base,
    backgroundColor: state.isSelected ? '#3B82F6' : state.isFocused ? '#374151' : undefined,
    color: '#E5E7EB'
  }),
  multiValue: (base: any) => ({
    ...base,
    backgroundColor: '#374151'
  }),
  multiValueLabel: (base: any) => ({
    ...base,
    color: '#E5E7EB'
  }),
  multiValueRemove: (base: any) => ({
    ...base,
    color: '#9CA3AF',
    ':hover': {
      backgroundColor: '#4B5563',
      color: '#E5E7EB'
    }
  }),
  input: (base: any) => ({
    ...base,
    color: '#E5E7EB'
  })
};

const hashtagOptions = [
  { value: 'realestate', label: '#realestate' },
  { value: 'property', label: '#property' },
  { value: 'luxuryhomes', label: '#luxuryhomes' },
  { value: 'investment', label: '#investment' },
  { value: 'realtor', label: '#realtor' },
  { value: 'homesale', label: '#homesale' },
  { value: 'dreamhome', label: '#dreamhome' },
  { value: 'luxuryrealestate', label: '#luxuryrealestate' }
];

export default function PostEditor({ currentPost, onPostChange, onAddPost }: PostEditorProps) {
  return (
    <div className="space-y-6">
      <h2 className="text-lg font-semibold text-gray-100">Create Post</h2>
      
      <div>
        <label className="block text-sm font-medium text-gray-400 mb-2">
          Post Content
        </label>
        <textarea
          value={currentPost.content}
          onChange={(e) => onPostChange({ ...currentPost, content: e.target.value })}
          className="w-full h-40 px-4 py-3 bg-dark-700 border border-dark-600 rounded-lg text-gray-200 resize-none"
          placeholder="Write your post content..."
        />
        <div className="text-xs text-gray-400 mt-1">
          {280 - currentPost.content.length} characters remaining
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-400 mb-2">
          Hashtags
        </label>
        <Select
          isMulti
          value={currentPost.hashtags.map(tag => ({ value: tag, label: `#${tag}` }))}
          onChange={(selected) => onPostChange({
            ...currentPost,
            hashtags: selected.map(option => option.value)
          })}
          options={hashtagOptions}
          styles={customSelectStyles}
          placeholder="Add hashtags..."
        />
      </div>

      <div className="flex gap-4">
        <button className="btn-secondary flex items-center gap-2">
          <Image className="w-4 h-4" />
          Add Media
        </button>
        <button className="btn-secondary flex items-center gap-2">
          <Link2 className="w-4 h-4" />
          Add Link
        </button>
        <button className="btn-secondary flex items-center gap-2">
          <Calendar className="w-4 h-4" />
          Schedule
        </button>
      </div>

      <button
        onClick={onAddPost}
        className="btn-primary w-full flex items-center justify-center gap-2"
      >
        <Plus className="w-4 h-4" />
        Add to Campaign
      </button>
    </div>
  );
}