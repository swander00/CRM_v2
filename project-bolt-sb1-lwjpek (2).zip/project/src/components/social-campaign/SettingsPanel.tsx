import React from 'react';
import { Clock, Tag, GitBranch } from 'lucide-react';
import Select from 'react-select';

interface SettingsPanelProps {
  selectedPost?: any;
  onUpdate?: (updates: any) => void;
}

const customSelectStyles = {
  control: (base: any) => ({
    ...base,
    background: '#1F2937',
    borderColor: '#374151',
    '&:hover': {
      borderColor: '#4B5563'
    }
  }),
  menu: (base: any) => ({
    ...base,
    background: '#1F2937',
    border: '1px solid #374151'
  }),
  option: (base: any, state: { isSelected: boolean; isFocused: boolean }) => ({
    ...base,
    backgroundColor: state.isSelected ? '#3B82F6' : state.isFocused ? '#374151' : undefined,
    color: '#E5E7EB'
  }),
  input: (base: any) => ({
    ...base,
    color: '#E5E7EB'
  })
};

export default function SettingsPanel({ selectedPost, onUpdate }: SettingsPanelProps) {
  if (!selectedPost) {
    return (
      <div className="w-96 bg-dark-800 border-l border-dark-700 p-6">
        <div className="text-gray-400">
          Select a post to edit its settings
        </div>
      </div>
    );
  }

  return (
    <div className="w-96 bg-dark-800 border-l border-dark-700 p-6">
      <div className="space-y-6">
        {/* Campaign Name */}
        <div>
          <label className="block text-sm font-medium text-gray-400 mb-2">
            Campaign Name
          </label>
          <input
            type="text"
            className="w-full px-4 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200"
            placeholder="Enter campaign name..."
          />
        </div>

        {/* Execution Type */}
        <div>
          <label className="block text-sm font-medium text-gray-400 mb-2">
            Execution Type
          </label>
          <div className="space-y-2">
            <label className="flex items-center gap-2">
              <input type="radio" name="execution-type" defaultChecked />
              <span className="text-gray-200">Relative date</span>
            </label>
            <label className="flex items-center gap-2">
              <input type="radio" name="execution-type" />
              <span className="text-gray-200">Fixed date</span>
            </label>
          </div>
        </div>

        {/* Stopping Clauses */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <label className="text-sm font-medium text-gray-400">
              Stopping Clauses
            </label>
            <Clock className="w-4 h-4 text-gray-400" />
          </div>
          <Select
            isMulti
            options={[
              { value: 'engagement_low', label: 'Low Engagement' },
              { value: 'budget_reached', label: 'Budget Reached' },
              { value: 'goal_achieved', label: 'Goal Achieved' }
            ]}
            styles={customSelectStyles}
            placeholder="Select stopping clauses..."
          />
        </div>

        {/* Tags */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <label className="text-sm font-medium text-gray-400">
              Tags
            </label>
            <Tag className="w-4 h-4 text-gray-400" />
          </div>
          <Select
            isMulti
            options={[
              { value: 'promotion', label: 'Promotion' },
              { value: 'announcement', label: 'Announcement' },
              { value: 'event', label: 'Event' }
            ]}
            styles={customSelectStyles}
            placeholder="Select tags..."
          />
        </div>

        {/* Pipeline Statuses */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <label className="text-sm font-medium text-gray-400">
              Pipeline Statuses
            </label>
            <GitBranch className="w-4 h-4 text-gray-400" />
          </div>
          <Select
            isMulti
            options={[
              { value: 'new', label: 'New Lead' },
              { value: 'contacted', label: 'Contacted' },
              { value: 'qualified', label: 'Qualified' }
            ]}
            styles={customSelectStyles}
            placeholder="Select pipeline statuses..."
          />
        </div>

        {/* Additional Options */}
        <div className="space-y-3">
          <label className="flex items-center gap-2">
            <input type="checkbox" className="rounded border-dark-600" />
            <span className="text-sm text-gray-200">Silent hours</span>
          </label>
          <label className="flex items-center gap-2">
            <input type="checkbox" className="rounded border-dark-600" />
            <span className="text-sm text-gray-200">Execute actions on business days only</span>
          </label>
        </div>

        {/* Clone Campaign */}
        <div>
          <label className="block text-sm font-medium text-gray-400 mb-2">
            Clone Campaign
          </label>
          <Select
            options={[
              { value: 'template1', label: 'Property Launch Template' },
              { value: 'template2', label: 'Market Update Template' },
              { value: 'template3', label: 'Open House Template' }
            ]}
            styles={customSelectStyles}
            placeholder="Select campaign template..."
          />
        </div>

        {/* Action Buttons */}
        <div className="flex justify-end gap-3 pt-4 border-t border-dark-700">
          <button className="btn-secondary">
            Discard
          </button>
          <button className="btn-primary">
            Save
          </button>
        </div>
      </div>
    </div>
  );
}