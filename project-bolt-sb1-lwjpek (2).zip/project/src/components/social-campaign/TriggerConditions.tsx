import React from 'react';
import { Mail, MessageSquare, Zap, AlertCircle } from 'lucide-react';
import Select from 'react-select';

interface TriggerConditionsProps {
  onTriggerChange: (triggers: CampaignTrigger[]) => void;
  triggers: CampaignTrigger[];
}

export interface CampaignTrigger {
  id: string;
  type: 'email' | 'sms' | 'drip';
  condition: string;
  value?: string;
  campaignId?: string;
}

const triggerConditions = {
  engagement: [
    { value: 'likes_above', label: 'Likes above threshold' },
    { value: 'comments_above', label: 'Comments above threshold' },
    { value: 'shares_above', label: 'Shares above threshold' },
    { value: 'clicks_above', label: 'Link clicks above threshold' },
    { value: 'profile_visit', label: 'Profile visited' },
    { value: 'message_received', label: 'Direct message received' }
  ],
  campaigns: [
    { value: 'campaign_1', label: 'Welcome Series' },
    { value: 'campaign_2', label: 'Property Alert' },
    { value: 'campaign_3', label: 'Market Update' },
    { value: 'campaign_4', label: 'Follow-up Sequence' }
  ]
};

const customSelectStyles = {
  control: (base: any) => ({
    ...base,
    background: '#1F2937',
    borderColor: '#374151',
    '&:hover': {
      borderColor: '#4B5563'
    }
  }),
  menu: (base: any) => ({
    ...base,
    background: '#1F2937',
    border: '1px solid #374151'
  }),
  option: (base: any, state: { isSelected: boolean; isFocused: boolean }) => ({
    ...base,
    backgroundColor: state.isSelected ? '#3B82F6' : state.isFocused ? '#374151' : undefined,
    color: '#E5E7EB'
  }),
  input: (base: any) => ({
    ...base,
    color: '#E5E7EB'
  })
};

export default function TriggerConditions({ onTriggerChange, triggers }: TriggerConditionsProps) {
  const handleAddTrigger = (type: 'email' | 'sms' | 'drip') => {
    const newTrigger: CampaignTrigger = {
      id: Date.now().toString(),
      type,
      condition: '',
    };
    onTriggerChange([...triggers, newTrigger]);
  };

  const handleRemoveTrigger = (triggerId: string) => {
    onTriggerChange(triggers.filter(t => t.id !== triggerId));
  };

  const handleTriggerUpdate = (triggerId: string, updates: Partial<CampaignTrigger>) => {
    onTriggerChange(
      triggers.map(trigger => 
        trigger.id === triggerId 
          ? { ...trigger, ...updates }
          : trigger
      )
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-semibold text-gray-100">Automation Triggers</h2>
        <div className="flex gap-2">
          <button
            onClick={() => handleAddTrigger('email')}
            className="btn-secondary flex items-center gap-2"
          >
            <Mail className="w-4 h-4" />
            Add Email
          </button>
          <button
            onClick={() => handleAddTrigger('sms')}
            className="btn-secondary flex items-center gap-2"
          >
            <MessageSquare className="w-4 h-4" />
            Add SMS
          </button>
          <button
            onClick={() => handleAddTrigger('drip')}
            className="btn-secondary flex items-center gap-2"
          >
            <Zap className="w-4 h-4" />
            Add Drip
          </button>
        </div>
      </div>

      {triggers.length > 0 ? (
        <div className="space-y-4">
          {triggers.map(trigger => (
            <div key={trigger.id} className="bg-dark-700/50 rounded-lg p-4 border border-dark-600">
              <div className="flex items-start gap-4">
                <div className="p-2 rounded-lg bg-dark-700">
                  {trigger.type === 'email' && <Mail className="w-5 h-5 text-blue-400" />}
                  {trigger.type === 'sms' && <MessageSquare className="w-5 h-5 text-green-400" />}
                  {trigger.type === 'drip' && <Zap className="w-5 h-5 text-yellow-400" />}
                </div>
                
                <div className="flex-1 space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-400 mb-2">
                      When
                    </label>
                    <Select
                      value={triggerConditions.engagement.find(c => c.value === trigger.condition)}
                      onChange={(option) => handleTriggerUpdate(trigger.id, { condition: option?.value })}
                      options={triggerConditions.engagement}
                      styles={customSelectStyles}
                      placeholder="Select trigger condition..."
                    />
                  </div>

                  {trigger.condition?.includes('above') && (
                    <div>
                      <label className="block text-sm font-medium text-gray-400 mb-2">
                        Threshold
                      </label>
                      <input
                        type="number"
                        value={trigger.value || ''}
                        onChange={(e) => handleTriggerUpdate(trigger.id, { value: e.target.value })}
                        className="w-full px-3 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200"
                        placeholder="Enter threshold value..."
                      />
                    </div>
                  )}

                  <div>
                    <label className="block text-sm font-medium text-gray-400 mb-2">
                      Start Campaign
                    </label>
                    <Select
                      value={triggerConditions.campaigns.find(c => c.value === trigger.campaignId)}
                      onChange={(option) => handleTriggerUpdate(trigger.id, { campaignId: option?.value })}
                      options={triggerConditions.campaigns}
                      styles={customSelectStyles}
                      placeholder="Select campaign to trigger..."
                    />
                  </div>
                </div>

                <button
                  onClick={() => handleRemoveTrigger(trigger.id)}
                  className="p-2 text-gray-400 hover:text-gray-300"
                >
                  <AlertCircle className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="text-center py-8 text-gray-400 bg-dark-700/50 rounded-lg">
          No automation triggers configured yet
        </div>
      )}

      <div className="p-4 bg-primary-500/10 rounded-lg">
        <h3 className="text-sm font-medium text-primary-400 mb-2">About Automation Triggers</h3>
        <p className="text-sm text-gray-400">
          Automation triggers allow you to automatically start email, SMS, or drip campaigns based on social media engagement.
          This helps create seamless multi-channel marketing campaigns and improve lead nurturing.
        </p>
      </div>
    </div>
  );
}