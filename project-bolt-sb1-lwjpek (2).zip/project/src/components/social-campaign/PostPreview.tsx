import React from 'react';
import { Calendar, X } from 'lucide-react';
import { Post } from './types';
import { platforms } from './PlatformSelector';

interface PostPreviewProps {
  posts: Post[];
  onRemovePost: (postId: string) => void;
}

export default function PostPreview({ posts, onRemovePost }: PostPreviewProps) {
  return (
    <div>
      <h2 className="text-lg font-semibold text-gray-100 mb-4">Campaign Posts</h2>
      <div className="space-y-4">
        {posts.map(post => (
          <div key={post.id} className="bg-dark-700 rounded-lg p-4 border border-dark-600">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                {post.platforms.map(platformId => {
                  const platform = platforms.find(p => p.id === platformId);
                  if (!platform) return null;
                  const Icon = platform.icon;
                  return (
                    <Icon key={platformId} className={`w-4 h-4 ${platform.color}`} />
                  );
                })}
              </div>
              <button
                onClick={() => onRemovePost(post.id)}
                className="text-gray-400 hover:text-gray-300"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <p className="text-gray-200 whitespace-pre-wrap">{post.content}</p>
            {post.hashtags.length > 0 && (
              <div className="mt-2 flex flex-wrap gap-2">
                {post.hashtags.map(tag => (
                  <span
                    key={tag}
                    className="text-sm text-primary-400"
                  >
                    #{tag}
                  </span>
                ))}
              </div>
            )}
            {post.scheduledTime && (
              <div className="mt-2 text-sm text-gray-400 flex items-center gap-2">
                <Calendar className="w-4 h-4" />
                Scheduled for: {new Date(post.scheduledTime).toLocaleString()}
              </div>
            )}
          </div>
        ))}
        {posts.length === 0 && (
          <div className="text-center py-8 text-gray-400">
            No posts added to the campaign yet
          </div>
        )}
      </div>
    </div>
  );
}