import React, { useState } from 'react';
import { Save, Play } from 'lucide-react';
import WorkflowCanvas from '../drip-campaign/WorkflowCanvas';
import SettingsPanel from '../drip-campaign/SettingsPanel';
import TimelineView from '../drip-campaign/TimelineView';

export default function SocialCampaignBuilder() {
  const [blocks, setBlocks] = React.useState([]);
  const [selectedBlock, setSelectedBlock] = React.useState(undefined);

  const handleBlockUpdate = (id: string, updates: any) => {
    setBlocks(blocks.map(block => 
      block.id === id 
        ? { ...block, content: { ...block.content, ...updates } }
        : block
    ));
  };

  return (
    <div className="min-h-screen bg-dark-900">
      {/* Header */}
      <div className="h-16 bg-dark-800 border-b border-dark-700 px-6">
        <div className="h-full flex items-center justify-between">
          <div>
            <h1 className="text-xl font-semibold text-gray-100">Social Campaign Builder</h1>
          </div>

          <div className="flex items-center gap-3">
            <button className="btn-secondary flex items-center gap-2">
              <Save className="w-4 h-4" />
              Save as Draft
            </button>
            <button className="btn-primary flex items-center gap-2">
              <Play className="w-4 h-4" />
              Launch Campaign
            </button>
          </div>
        </div>
      </div>

      <div className="flex h-[calc(100vh-64px)]">
        <WorkflowCanvas
          blocks={blocks}
          setBlocks={setBlocks}
          selectedBlock={selectedBlock}
          onSelectBlock={setSelectedBlock}
          allowedTypes={['social']}
        />
        <SettingsPanel
          selectedBlock={selectedBlock}
          onUpdate={handleBlockUpdate}
        />
      </div>
      <TimelineView />
    </div>
  );
}