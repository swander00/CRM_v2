export interface Post {
  id: string;
  content: string;
  platforms: string[];
  media?: string[];
  scheduledTime?: string;
  hashtags: string[];
}