import React from 'react';
import { Facebook, Instagram, Linkedin, Twitter } from 'lucide-react';

interface Platform {
  id: string;
  name: string;
  icon: any;
  color: string;
}

interface PlatformSelectorProps {
  selectedPlatforms: string[];
  onPlatformToggle: (platformId: string) => void;
}

export const platforms: Platform[] = [
  { id: 'facebook', name: 'Facebook', icon: Facebook, color: 'bg-blue-500/10 text-blue-400' },
  { id: 'instagram', name: 'Instagram', icon: Instagram, color: 'bg-pink-500/10 text-pink-400' },
  { id: 'linkedin', name: 'LinkedIn', icon: Linkedin, color: 'bg-blue-600/10 text-blue-600' },
  { id: 'x', name: 'X (Twitter)', icon: Twitter, color: 'bg-sky-500/10 text-sky-400' }
];

export default function PlatformSelector({ selectedPlatforms, onPlatformToggle }: PlatformSelectorProps) {
  return (
    <div className="mb-8">
      <h2 className="text-lg font-semibold text-gray-100 mb-4">Select Platforms</h2>
      <div className="flex flex-wrap gap-4">
        {platforms.map(platform => {
          const Icon = platform.icon;
          const isSelected = selectedPlatforms.includes(platform.id);
          return (
            <button
              key={platform.id}
              onClick={() => onPlatformToggle(platform.id)}
              className={`flex items-center gap-3 p-4 rounded-lg border transition-all ${
                isSelected
                  ? `${platform.color} border-current`
                  : 'border-dark-700 text-gray-400 hover:text-gray-300'
              }`}
            >
              <Icon className="w-5 h-5" />
              <span>{platform.name}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}