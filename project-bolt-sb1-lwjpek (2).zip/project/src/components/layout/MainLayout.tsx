import React from 'react';
import { Outlet } from 'react-router-dom';
import Sidebar from './Sidebar';
import TopBar from './TopBar';
import FloatingActionButton from '../FloatingActionButton';
import { useTheme } from '../../contexts/ThemeContext';

export default function MainLayout() {
  const { theme } = useTheme();

  return (
    <div className={`min-h-screen ${theme === 'light' ? 'bg-gray-50' : 'bg-dark-900'}`}>
      <Sidebar />
      <div className="pl-64">
        <TopBar />
        <main className="p-6">
          <Outlet />
        </main>
        <FloatingActionButton />
      </div>
    </div>
  );
}