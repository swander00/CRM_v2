import React, { useState } from 'react';
import { Bell, Search, Settings, User, ChevronDown, Inbox } from 'lucide-react';
import ThemeToggle from '../ThemeToggle';

export default function TopBar() {
  const [showNotifications, setShowNotifications] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [showInbox, setShowInbox] = useState(false);

  return (
    <header className="h-16 bg-gradient-to-r from-primary-600 via-primary-500 to-blue-500 relative">
      {/* Glassmorphism Overlay */}
      <div className="absolute inset-0 bg-white/10 backdrop-blur-sm dark:bg-dark-800/80"></div>
      
      <div className="relative h-full px-6 flex items-center justify-between">
        {/* Search */}
        <div className="flex-1 max-w-xl">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="text"
              placeholder="Search anything..."
              className="w-full pl-10 pr-4 py-2 bg-white/20 dark:bg-dark-700/50 backdrop-blur-md border border-white/20 dark:border-dark-600 rounded-lg text-white dark:text-gray-200 placeholder-gray-300 dark:placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-white/30 dark:focus:ring-primary-500/30"
            />
          </div>
        </div>

        {/* Right Section */}
        <div className="flex items-center gap-4">
          <ThemeToggle />
          
          {/* Inbox Button */}
          <button 
            onClick={() => setShowInbox(!showInbox)}
            className="flex items-center gap-2 px-4 py-2 bg-white/20 dark:bg-dark-700/50 backdrop-blur-md border border-white/20 dark:border-dark-600 rounded-lg text-white dark:text-gray-200 hover:bg-white/30 dark:hover:bg-dark-600/50 transition-colors relative"
          >
            <Inbox className="w-5 h-5" />
            <span className="font-medium">Inbox</span>
            <div className="flex gap-2 items-center border-l border-white/20 dark:border-dark-600 ml-2 pl-2">
              <span className="flex items-center justify-center min-w-[20px] h-5 bg-primary-500 rounded-full text-xs font-medium">
                3
              </span>
              <span className="flex items-center justify-center min-w-[20px] h-5 bg-green-500 rounded-full text-xs font-medium">
                5
              </span>
            </div>
          </button>

          {/* Notifications */}
          <div className="relative">
            <button 
              onClick={() => setShowNotifications(!showNotifications)}
              className="p-2 text-white/80 dark:text-gray-400 hover:text-white dark:hover:text-gray-300 relative"
            >
              <Bell className="w-5 h-5" />
              <span className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 rounded-full text-white text-xs flex items-center justify-center">
                2
              </span>
            </button>

            {showNotifications && (
              <div className="absolute right-0 mt-2 w-80 bg-white dark:bg-dark-800 rounded-lg shadow-lg border border-gray-200 dark:border-dark-700 py-2 backdrop-blur-lg">
                <div className="px-4 py-2 border-b border-gray-200 dark:border-dark-700">
                  <h3 className="font-medium text-gray-900 dark:text-gray-100">Notifications</h3>
                </div>
                <div className="max-h-[400px] overflow-y-auto">
                  {/* Example Notification */}
                  <div className="px-4 py-3 hover:bg-gray-50 dark:hover:bg-dark-700/50">
                    <div className="flex items-start gap-3">
                      <div className="w-8 h-8 rounded-full bg-primary-500/10 flex items-center justify-center">
                        <Inbox className="w-4 h-4 text-primary-500" />
                      </div>
                      <div>
                        <p className="text-sm text-gray-900 dark:text-gray-200">New message from John Doe</p>
                        <p className="text-xs text-gray-500 mt-1">2 minutes ago</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* User Profile */}
          <div className="relative">
            <button
              onClick={() => setShowUserMenu(!showUserMenu)}
              className="flex items-center gap-3 pl-4 cursor-pointer"
            >
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 bg-white/20 dark:bg-primary-500/10 rounded-full flex items-center justify-center">
                  <User className="w-5 h-5 text-white dark:text-primary-500" />
                </div>
                <div className="hidden md:block text-left">
                  <div className="text-sm font-medium text-white dark:text-gray-200">John Doe</div>
                  <div className="text-xs text-white/70 dark:text-gray-400">Admin</div>
                </div>
              </div>
              <ChevronDown className="w-4 h-4 text-white/70 dark:text-gray-500" />
            </button>

            {showUserMenu && (
              <div className="absolute right-0 mt-2 w-48 bg-white dark:bg-dark-800 rounded-lg shadow-lg border border-gray-200 dark:border-dark-700 py-2 backdrop-blur-lg">
                <button className="w-full px-4 py-2 text-left text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-dark-700">
                  Profile Settings
                </button>
                <button className="w-full px-4 py-2 text-left text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-dark-700">
                  Account Settings
                </button>
                <div className="border-t border-gray-200 dark:border-dark-700 my-1"></div>
                <button className="w-full px-4 py-2 text-left text-sm text-red-600 hover:bg-gray-100 dark:hover:bg-dark-700">
                  Sign Out
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Inbox Dropdown */}
      {showInbox && (
        <div className="absolute top-full left-0 w-full bg-white dark:bg-dark-800 border-b border-gray-200 dark:border-dark-700 shadow-lg">
          <div className="max-w-7xl mx-auto p-4">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold text-gray-900 dark:text-gray-100">Recent Communications</h2>
              <div className="flex gap-2">
                <button className="btn-secondary text-xs">Mark all as read</button>
                <button className="btn-secondary text-xs">Filter</button>
              </div>
            </div>
            
            <div className="space-y-2 max-h-96 overflow-y-auto">
              <div className="flex items-start gap-3 p-3 hover:bg-gray-50 dark:hover:bg-dark-700 rounded-lg transition-colors">
                <Inbox className="w-5 h-5 text-primary-400 flex-shrink-0 mt-1" />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <span className="font-medium text-gray-900 dark:text-gray-200">Mike Johnson (Mortgage Agent)</span>
                    <span className="text-xs text-gray-500">1 hour ago</span>
                  </div>
                  <p className="text-sm text-gray-600 dark:text-gray-400 truncate">Updated rates for jumbo mortgages...</p>
                </div>
              </div>
            </div>

            <div className="mt-4 text-center">
              <button className="text-primary-500 hover:text-primary-400 text-sm">
                View all communications
              </button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
}