import React, { useState } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import {
  LayoutDashboard,
  Users,
  PieChart,
  Calendar,
  Mail,
  Home,
  BarChart2,
  Settings,
  FileText,
  Briefcase,
  CheckSquare,
  Megaphone,
  UserCheck,
  Link2,
  CircleDollarSign,
  ChevronDown,
  ChevronRight,
  ShoppingBag,
  CreditCard
} from 'lucide-react';

interface NavItem {
  path?: string;
  icon: any;
  label: string;
  children?: NavItem[];
  end?: boolean;
}

const navItems: NavItem[] = [
  {
    path: '/',
    icon: LayoutDashboard,
    label: 'Dashboard',
    end: true
  },
  {
    icon: Users,
    label: 'Lead Management',
    children: [
      { path: '/leads', icon: UserCheck, label: 'Lead Management' },
      { path: '/contacts', icon: Users, label: 'Contact Management' },
      { path: '/pipeline', icon: PieChart, label: 'Pipeline' }
    ]
  },
  {
    icon: Calendar,
    label: 'Schedule',
    children: [
      { path: '/tasks', icon: CheckSquare, label: 'Tasks' },
      { path: '/calendar', icon: Calendar, label: 'Calendar' }
    ]
  },
  {
    icon: Mail,
    label: 'Communications',
    children: [
      { path: '/communications', icon: Mail, label: 'Inbox' },
      { path: '/templates/email', icon: FileText, label: 'Email Templates' },
      { path: '/templates/sms', icon: FileText, label: 'SMS Templates' },
      { path: '/templates/whatsapp', icon: FileText, label: 'WhatsApp Templates' }
    ]
  },
  {
    icon: Home,
    label: 'Properties',
    children: [
      { path: '/properties', icon: Home, label: 'Property Listings' },
      { path: '/deals', icon: Briefcase, label: 'Deals' }
    ]
  },
  {
    icon: BarChart2,
    label: 'Analytics',
    children: [
      { path: '/analytics', icon: BarChart2, label: 'Performance' },
      { path: '/revenue', icon: CircleDollarSign, label: 'Revenue' }
    ]
  },
  {
    icon: Megaphone,
    label: 'Marketing',
    children: [
      { path: '/marketing', icon: Megaphone, label: 'Marketing Hub' },
      { path: '/marketplace', icon: ShoppingBag, label: 'Marketplace' }
    ]
  },
  {
    icon: Link2,
    label: 'Integrations',
    children: [
      { path: '/integrations', icon: Link2, label: 'Connected Apps' },
      { path: '/documents', icon: FileText, label: 'Documents' }
    ]
  },
  {
    icon: Settings,
    label: 'Settings',
    children: [
      { path: '/settings/team', icon: Users, label: 'Team Management' },
      { path: '/settings/billing', icon: CreditCard, label: 'Billing & Plans' }
    ]
  }
];

const NavItemComponent = ({ item, level = 0 }: { item: NavItem; level?: number }) => {
  const location = useLocation();
  const [isOpen, setIsOpen] = useState(() => {
    // Open the section if any child path matches current location
    return item.children?.some(child => 
      location.pathname.startsWith(child.path || '')
    ) || false;
  });

  const Icon = item.icon;
  const hasChildren = item.children && item.children.length > 0;
  const paddingLeft = `${level * 1}rem`;

  // Check if current item or any of its children are active
  const isActive = hasChildren 
    ? item.children.some(child => location.pathname.startsWith(child.path || ''))
    : location.pathname === item.path;

  if (hasChildren) {
    return (
      <div>
        <button
          onClick={() => setIsOpen(!isOpen)}
          className={`w-full flex items-center gap-3 px-4 py-2 rounded-lg text-base mb-1 transition-colors ${
            isActive
              ? 'bg-primary-500/10 text-primary-400'
              : 'text-gray-400 hover:bg-dark-700 hover:text-gray-300'
          }`}
          style={{ paddingLeft: `${paddingLeft + 1}rem` }}
        >
          <Icon className="w-5 h-5" />
          <span className="flex-1 text-left font-medium">{item.label}</span>
          {isOpen ? (
            <ChevronDown className="w-4 h-4" />
          ) : (
            <ChevronRight className="w-4 h-4" />
          )}
        </button>
        {isOpen && (
          <div className="ml-4">
            {item.children.map((child, index) => (
              <NavItemComponent key={index} item={child} level={level + 1} />
            ))}
          </div>
        )}
      </div>
    );
  }

  return (
    <NavLink
      to={item.path || '#'}
      end={item.end}
      className={({ isActive }) => `
        flex items-center gap-3 px-4 py-2 rounded-lg text-base mb-1
        ${isActive 
          ? 'bg-primary-500/10 text-primary-400'
          : 'text-gray-400 hover:bg-dark-700 hover:text-gray-300'
        }
        transition-colors
      `}
      style={{ paddingLeft: `${paddingLeft + 1}rem` }}
    >
      <Icon className="w-5 h-5" />
      <span className="text-left">{item.label}</span>
    </NavLink>
  );
};

export default function Sidebar() {
  return (
    <aside className="fixed left-0 top-0 h-screen w-64 bg-dark-800 border-r border-dark-700 flex flex-col">
      {/* Header - Fixed */}
      <div className="flex-shrink-0 p-4 border-b border-dark-700">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-gradient-to-br from-primary-500 to-blue-500 rounded-lg flex items-center justify-center">
            <Home className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-lg font-bold text-gray-100">Real Estate CRM</h1>
            <p className="text-xs text-gray-400">Enterprise Suite</p>
          </div>
        </div>
      </div>
      
      {/* Navigation - Scrollable */}
      <nav className="flex-1 overflow-y-auto px-2 py-4 scrollbar-thin scrollbar-thumb-dark-600 scrollbar-track-dark-800">
        {navItems.map((item, index) => (
          <NavItemComponent key={index} item={item} />
        ))}
      </nav>

      {/* Footer - Fixed */}
      <div className="flex-shrink-0 p-4 border-t border-dark-700">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-primary-500/10 rounded-full flex items-center justify-center text-primary-400 font-medium">
            JS
          </div>
          <div className="flex-1 min-w-0">
            <div className="text-sm font-medium text-gray-200 truncate">John Smith</div>
            <div className="text-xs text-gray-400">Premium Account</div>
          </div>
        </div>
        <div className="mt-2 text-xs text-gray-400">
          <div className="flex items-center justify-between">
            <span>Storage: 75%</span>
            <span>23.4GB / 30GB</span>
          </div>
          <div className="mt-1 h-1 bg-dark-600 rounded-full">
            <div className="h-full w-3/4 bg-primary-500 rounded-full"></div>
          </div>
        </div>
      </div>
    </aside>
  );
}