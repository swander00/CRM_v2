import React from 'react';
import { Check } from 'lucide-react';
import CollapsibleSection from './CollapsibleSection';
import PropertyInfoGrid from './PropertyInfoGrid';
import ListingHistory from './ListingHistory';

interface PropertyDetailsProps {
  listingInfo: {
    listed: string;
    lastUpdated: string;
    originalPrice: number;
    mlsNumber: string;
    possession: string;
    taxes: number;
  };
  propertyDetails: {
    bedrooms: number;
    bathrooms: number;
    approxAge: string;
    lotSize: string;
    sqFootage: string;
    propertyType: string;
    status: string;
  };
  basement: {
    status: string;
    entrance: string;
  };
  parking: {
    drive: number;
    garage: number;
  };
  utilities: {
    ac: string;
    heatSource: string;
    water: string;
    sewers: string;
  };
  features: string[];
  listingHistory: Array<{
    date: string;
    price: number;
    type: 'increase' | 'decrease' | 'listed';
  }>;
}

export default function PropertyDetails({
  listingInfo,
  propertyDetails,
  basement,
  parking,
  utilities,
  features,
  listingHistory
}: PropertyDetailsProps) {
  return (
    <div className="space-y-1">
      <CollapsibleSection title="Listing Information">
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <PropertyInfoGrid label="Listed" value={listingInfo.listed} />
              <PropertyInfoGrid label="Last Updated" value={listingInfo.lastUpdated} />
              <PropertyInfoGrid label="Original Price" value={`$${listingInfo.originalPrice.toLocaleString()}`} />
            </div>
            <div>
              <PropertyInfoGrid label="MLS#" value={listingInfo.mlsNumber} align="right" />
              <PropertyInfoGrid label="Possession" value={listingInfo.possession} align="right" />
              <PropertyInfoGrid label="Taxes" value={`$${listingInfo.taxes.toLocaleString()}`} align="right" />
            </div>
          </div>

          <div className="pt-4 border-t border-gray-200">
            <h3 className="text-lg font-medium text-gray-900 mb-4">Listing History</h3>
            <ListingHistory history={listingHistory} />
          </div>
        </div>
      </CollapsibleSection>

      <CollapsibleSection title="Property Details">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <PropertyInfoGrid label="Bedrooms" value={propertyDetails.bedrooms} />
            <PropertyInfoGrid label="Bathrooms" value={propertyDetails.bathrooms} />
            <PropertyInfoGrid label="Approx. Age" value={propertyDetails.approxAge} />
            <PropertyInfoGrid label="Lot Size" value={propertyDetails.lotSize} />
          </div>
          <div>
            <PropertyInfoGrid label="Sq Footage" value={propertyDetails.sqFootage} align="right" />
            <PropertyInfoGrid label="Property Type" value={propertyDetails.propertyType} align="right" />
            <PropertyInfoGrid label="Status" value={propertyDetails.status} align="right" />
          </div>
        </div>
      </CollapsibleSection>

      <CollapsibleSection title="Basement">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <PropertyInfoGrid label="Status" value={basement.status} />
          <PropertyInfoGrid label="Entrance" value={basement.entrance} align="right" />
        </div>
      </CollapsibleSection>

      <CollapsibleSection title="Parking">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <PropertyInfoGrid label="Drive Parking" value={parking.drive} />
          <PropertyInfoGrid label="Garage Parking" value={parking.garage} align="right" />
        </div>
      </CollapsibleSection>

      <CollapsibleSection title="Utilities">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <PropertyInfoGrid label="Central A/C" value={utilities.ac} />
            <PropertyInfoGrid label="Water" value={utilities.water} />
          </div>
          <div>
            <PropertyInfoGrid label="Heat Source" value={utilities.heatSource} align="right" />
            <PropertyInfoGrid label="Sewers" value={utilities.sewers} align="right" />
          </div>
        </div>
      </CollapsibleSection>

      <CollapsibleSection title="Interior Features">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {features.map((feature, index) => (
            <div key={index} className="flex items-center gap-2">
              <Check className="w-5 h-5 text-green-500" />
              <span className="text-gray-600">{feature}</span>
            </div>
          ))}
        </div>
      </CollapsibleSection>
    </div>
  );
}