import React from 'react';
import { Calendar, TrendingDown, TrendingUp } from 'lucide-react';

interface PriceChange {
  date: string;
  price: number;
  type: 'increase' | 'decrease' | 'listed';
}

interface ListingHistoryProps {
  history: PriceChange[];
}

export default function ListingHistory({ history }: ListingHistoryProps) {
  return (
    <div className="overflow-x-auto">
      <table className="w-full">
        <thead className="bg-gray-50">
          <tr>
            <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">Date</th>
            <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">Event</th>
            <th className="px-4 py-3 text-right text-sm font-medium text-gray-600">Price</th>
            <th className="px-4 py-3 text-right text-sm font-medium text-gray-600">Change</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-gray-200">
          {history.map((change, index) => {
            const prevPrice = index < history.length - 1 ? history[index + 1].price : change.price;
            const priceDiff = change.price - prevPrice;
            const percentChange = ((priceDiff / prevPrice) * 100).toFixed(1);
            
            return (
              <tr key={change.date} className="hover:bg-gray-50">
                <td className="px-4 py-3 text-sm text-gray-600">
                  <div className="flex items-center gap-2">
                    <Calendar className="w-4 h-4" />
                    {change.date}
                  </div>
                </td>
                <td className="px-4 py-3 text-sm text-gray-900">
                  {change.type === 'listed' ? 'Listed' : 'Price Change'}
                </td>
                <td className="px-4 py-3 text-sm text-gray-900 text-right">
                  ${change.price.toLocaleString()}
                </td>
                <td className="px-4 py-3 text-sm text-right">
                  {change.type !== 'listed' && (
                    <div className={`flex items-center justify-end gap-1 ${
                      priceDiff > 0 ? 'text-green-600' : priceDiff < 0 ? 'text-red-600' : 'text-gray-600'
                    }`}>
                      {priceDiff > 0 ? (
                        <TrendingUp className="w-4 h-4" />
                      ) : priceDiff < 0 ? (
                        <TrendingDown className="w-4 h-4" />
                      ) : null}
                      {priceDiff !== 0 && `${priceDiff > 0 ? '+' : ''}${percentChange}%`}
                    </div>
                  )}
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}