import React from 'react';

interface PropertyInfoGridProps {
  label: string;
  value: string | number;
  align?: 'left' | 'right';
}

export default function PropertyInfoGrid({ label, value, align = 'left' }: PropertyInfoGridProps) {
  return (
    <div className="py-2">
      <div className={`flex items-center justify-between ${align === 'right' ? 'flex-row-reverse' : 'flex-row'}`}>
        <span className="text-gray-600">{label}:</span>
        <span className={`text-gray-900 font-medium ${align === 'right' ? 'text-right' : ''}`}>{value}</span>
      </div>
    </div>
  );
}