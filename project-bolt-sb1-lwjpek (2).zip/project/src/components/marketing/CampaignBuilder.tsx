import React from 'react';
import { Mail, MessageSquare, Share2, Zap } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const campaignTypes = [
  { 
    id: 'drip', 
    icon: Zap, 
    label: 'Drip Campaign', 
    description: 'Delivered individually based on triggers',
    color: 'bg-blue-500/10 border-blue-500/20 text-blue-400 hover:bg-blue-500/20',
    path: '/campaigns/drip/history'
  },
  { 
    id: 'email', 
    icon: Mail, 
    label: 'Email Campaign', 
    description: 'Sent to all recipients simultaneously',
    color: 'bg-green-500/10 border-green-500/20 text-green-400 hover:bg-green-500/20',
    path: '/campaigns/email/history'
  },
  { 
    id: 'sms', 
    icon: MessageSquare, 
    label: 'SMS Campaign', 
    description: 'Send text messages to your contacts',
    color: 'bg-yellow-500/10 border-yellow-500/20 text-yellow-400 hover:bg-yellow-500/20',
    path: '/campaigns/sms/history'
  },
  { 
    id: 'social', 
    icon: Share2, 
    label: 'Social Campaign', 
    description: 'Manage social media campaigns',
    color: 'bg-purple-500/10 border-purple-500/20 text-purple-400 hover:bg-purple-500/20',
    path: '/campaigns/social/history'
  }
];

export default function CampaignBuilder() {
  const navigate = useNavigate();

  return (
    <div className="bg-dark-800 rounded-lg border border-dark-700 p-6 mb-6">
      <h3 className="text-lg font-semibold text-gray-100 mb-6">Campaign Builder</h3>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
        {campaignTypes.map((type) => {
          const Icon = type.icon;
          return (
            <button
              key={type.id}
              onClick={() => navigate(type.path)}
              className={`flex items-start gap-4 p-4 rounded-lg border transition-all cursor-pointer text-left ${type.color}`}
            >
              <Icon className="w-6 h-6 mt-1" />
              <div>
                <div className="font-medium mb-1">{type.label}</div>
                <div className="text-sm opacity-80">{type.description}</div>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}