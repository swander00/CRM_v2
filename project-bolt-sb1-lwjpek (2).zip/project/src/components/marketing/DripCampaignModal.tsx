import React from 'react';
import { X, Plus, FolderOpen } from 'lucide-react';

interface DripCampaignModalProps {
  onClose: () => void;
  onCreateNew: () => void;
  onUseExisting: () => void;
}

export default function DripCampaignModal({ onClose, onCreateNew, onUseExisting }: DripCampaignModalProps) {
  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-dark-800 rounded-lg w-full max-w-md p-6">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold text-gray-100">Create Drip Campaign</h3>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-300"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-4">
          <button
            onClick={onCreateNew}
            className="w-full flex items-center gap-4 p-4 rounded-lg bg-dark-700 hover:bg-dark-600 transition-colors text-left"
          >
            <div className="p-3 bg-primary-500/10 rounded-lg">
              <Plus className="w-6 h-6 text-primary-400" />
            </div>
            <div>
              <div className="font-medium text-gray-200">Create New Drip</div>
              <div className="text-sm text-gray-400">Start with a blank workflow</div>
            </div>
          </button>

          <button
            onClick={onUseExisting}
            className="w-full flex items-center gap-4 p-4 rounded-lg bg-dark-700 hover:bg-dark-600 transition-colors text-left"
          >
            <div className="p-3 bg-primary-500/10 rounded-lg">
              <FolderOpen className="w-6 h-6 text-primary-400" />
            </div>
            <div>
              <div className="font-medium text-gray-200">Use Existing Drip</div>
              <div className="text-sm text-gray-400">Select from saved workflows</div>
            </div>
          </button>
        </div>
      </div>
    </div>
  );
}