import React from 'react';
import { Mail, MessageSquare, Share2, ArrowRight, Clock } from 'lucide-react';
import { format } from 'date-fns';

const campaigns = [
  {
    id: 1,
    name: 'Spring Listings Newsletter',
    type: 'email',
    status: 'active',
    metrics: {
      opens: 2456,
      clicks: 892,
      conversions: 124
    },
    lastSent: new Date(2024, 1, 15)
  },
  {
    id: 2,
    name: 'Open House Reminder',
    type: 'sms',
    status: 'scheduled',
    metrics: {
      opens: 0,
      clicks: 0,
      conversions: 0
    },
    lastSent: new Date(2024, 1, 20)
  },
  {
    id: 3,
    name: 'Market Update',
    type: 'social',
    status: 'completed',
    metrics: {
      opens: 3567,
      clicks: 1234,
      conversions: 89
    },
    lastSent: new Date(2024, 1, 10)
  }
];

const getTypeIcon = (type: string) => {
  switch (type) {
    case 'email':
      return <Mail className="w-4 h-4" />;
    case 'sms':
      return <MessageSquare className="w-4 h-4" />;
    case 'social':
      return <Share2 className="w-4 h-4" />;
    default:
      return <Mail className="w-4 h-4" />;
  }
};

const getStatusColor = (status: string) => {
  switch (status) {
    case 'active':
      return 'bg-green-500/10 text-green-400';
    case 'scheduled':
      return 'bg-blue-500/10 text-blue-400';
    case 'completed':
      return 'bg-gray-500/10 text-gray-400';
    default:
      return 'bg-gray-500/10 text-gray-400';
  }
};

export default function RecentCampaigns() {
  return (
    <div className="bg-dark-800 rounded-lg border border-dark-700 p-6">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-semibold text-gray-100">Recent Campaigns</h3>
        <button className="text-primary-400 hover:text-primary-300 text-sm flex items-center gap-1">
          View All
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>

      <div className="space-y-4">
        {campaigns.map((campaign) => (
          <div
            key={campaign.id}
            className="flex items-center gap-4 p-4 bg-dark-700/50 rounded-lg hover:bg-dark-700 transition-colors"
          >
            <div className="p-3 bg-dark-700 rounded-lg">
              {getTypeIcon(campaign.type)}
            </div>

            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between mb-1">
                <h4 className="font-medium text-gray-200 truncate">
                  {campaign.name}
                </h4>
                <span className={`px-2 py-1 rounded-full text-xs ${getStatusColor(campaign.status)}`}>
                  {campaign.status}
                </span>
              </div>

              <div className="flex items-center gap-4 text-sm text-gray-400">
                <div className="flex items-center gap-1">
                  <Clock className="w-4 h-4" />
                  {format(campaign.lastSent, 'MMM dd, yyyy')}
                </div>
                {campaign.status !== 'scheduled' && (
                  <>
                    <span>•</span>
                    <span>{campaign.metrics.opens} opens</span>
                    <span>•</span>
                    <span>{campaign.metrics.clicks} clicks</span>
                  </>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}