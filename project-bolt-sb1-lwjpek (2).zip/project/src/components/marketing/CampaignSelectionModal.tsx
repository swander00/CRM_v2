import React from 'react';
import { X, Zap, Mail, MessageSquare, Share2 } from 'lucide-react';

interface CampaignSelectionModalProps {
  onClose: () => void;
  onSelect: (type: string) => void;
}

const campaignTypes = [
  {
    id: 'drip',
    icon: Zap,
    title: 'Drip Campaign',
    description: 'Create automated sequences of messages that are sent based on specific triggers and timelines.',
    color: 'text-blue-400 bg-blue-500/10 border-blue-500/20'
  },
  {
    id: 'email',
    icon: Mail,
    title: 'Email Campaign',
    description: 'Design and send one-time email campaigns to targeted segments of your audience.',
    color: 'text-green-400 bg-green-500/10 border-green-500/20'
  },
  {
    id: 'sms',
    icon: MessageSquare,
    title: 'SMS Campaign',
    description: 'Send text message campaigns to reach your audience directly on their mobile devices.',
    color: 'text-yellow-400 bg-yellow-500/10 border-yellow-500/20'
  },
  {
    id: 'social',
    icon: Share2,
    title: 'Social Campaign',
    description: 'Create and schedule posts across multiple social media platforms to expand your reach.',
    color: 'text-purple-400 bg-purple-500/10 border-purple-500/20'
  }
];

export default function CampaignSelectionModal({ onClose, onSelect }: CampaignSelectionModalProps) {
  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-dark-800 rounded-lg w-full max-w-2xl p-6">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold text-gray-100">Create Campaign</h3>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-300"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="grid grid-cols-1 gap-4">
          {campaignTypes.map((type) => {
            const Icon = type.icon;
            return (
              <button
                key={type.id}
                onClick={() => onSelect(type.id)}
                className={`flex items-start gap-4 p-4 rounded-lg border transition-all hover:bg-dark-700 ${type.color}`}
              >
                <Icon className="w-6 h-6 mt-1" />
                <div className="flex-1 text-left">
                  <h4 className="font-medium mb-1">{type.title}</h4>
                  <p className="text-sm opacity-80">{type.description}</p>
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}