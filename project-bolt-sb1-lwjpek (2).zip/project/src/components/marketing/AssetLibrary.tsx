import React from 'react';
import { Image, FileText, Upload, Plus, Search, Filter } from 'lucide-react';

export default function AssetLibrary() {
  return (
    <div className="bg-dark-800 rounded-lg border border-dark-700 p-6">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-semibold text-gray-100">Asset Library</h3>
        <button className="btn-primary flex items-center gap-2">
          <Plus className="w-4 h-4" />
          Add Asset
        </button>
      </div>

      <div className="space-y-4">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <input
            type="text"
            placeholder="Search assets..."
            className="w-full pl-9 pr-4 py-2 bg-dark-700 border border-dark-600 rounded-lg text-sm text-gray-200"
          />
        </div>

        <div className="flex items-center gap-2">
          <button className="px-3 py-1 rounded-full text-sm bg-primary-500/10 text-primary-400">
            All Files
          </button>
          <button className="px-3 py-1 rounded-full text-sm bg-dark-700 text-gray-400">
            Images
          </button>
          <button className="px-3 py-1 rounded-full text-sm bg-dark-700 text-gray-400">
            Documents
          </button>
        </div>

        <div className="space-y-2">
          <div className="p-3 bg-dark-700/50 rounded-lg flex items-center gap-3">
            <div className="w-10 h-10 bg-primary-500/10 rounded-lg flex items-center justify-center">
              <Image className="w-5 h-5 text-primary-400" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-sm font-medium text-gray-200">hero-image.jpg</div>
              <div className="text-xs text-gray-400">2.4 MB • Added 2 days ago</div>
            </div>
          </div>

          <div className="p-3 bg-dark-700/50 rounded-lg flex items-center gap-3">
            <div className="w-10 h-10 bg-blue-500/10 rounded-lg flex items-center justify-center">
              <FileText className="w-5 h-5 text-blue-400" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-sm font-medium text-gray-200">newsletter-template.html</div>
              <div className="text-xs text-gray-400">48 KB • Added 3 days ago</div>
            </div>
          </div>
        </div>

        <div className="border-2 border-dashed border-dark-600 rounded-lg p-8">
          <div className="flex flex-col items-center text-center">
            <Upload className="w-8 h-8 text-gray-400 mb-2" />
            <p className="text-sm text-gray-300 mb-1">
              Drag and drop files here, or{' '}
              <button className="text-primary-400 hover:text-primary-300">browse</button>
            </p>
            <p className="text-xs text-gray-400">
              Supports: JPG, PNG, GIF, PDF, DOC up to 10MB
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}