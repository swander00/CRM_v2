import React from 'react';
import { Mail, MousePointerClick, TrendingUp, Users } from 'lucide-react';

export default function MarketingOverview() {
  return (
    <div className="grid grid-cols-2 gap-4">
      <div className="bg-dark-800 rounded-lg border border-dark-700 p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-gray-400">Total Campaigns</p>
            <p className="text-2xl font-semibold text-gray-100 mt-1">45</p>
          </div>
          <div className="p-3 bg-primary-500/10 rounded-full">
            <Mail className="w-6 h-6 text-primary-400" />
          </div>
        </div>
        <div className="mt-4 flex items-center gap-1">
          <TrendingUp className="w-4 h-4 text-green-400" />
          <span className="text-sm text-green-400">12</span>
          <span className="text-sm text-gray-400 ml-1">active campaigns</span>
        </div>
      </div>

      <div className="bg-dark-800 rounded-lg border border-dark-700 p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-gray-400">Open Rate</p>
            <p className="text-2xl font-semibold text-gray-100 mt-1">68%</p>
          </div>
          <div className="p-3 bg-green-500/10 rounded-full">
            <Mail className="w-6 h-6 text-green-400" />
          </div>
        </div>
        <div className="mt-4 flex items-center gap-1">
          <TrendingUp className="w-4 h-4 text-green-400" />
          <span className="text-sm text-green-400">5%</span>
          <span className="text-sm text-gray-400 ml-1">vs last month</span>
        </div>
      </div>

      <div className="bg-dark-800 rounded-lg border border-dark-700 p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-gray-400">Click Rate</p>
            <p className="text-2xl font-semibold text-gray-100 mt-1">52%</p>
          </div>
          <div className="p-3 bg-blue-500/10 rounded-full">
            <MousePointerClick className="w-6 h-6 text-blue-400" />
          </div>
        </div>
        <div className="mt-4 flex items-center gap-1">
          <TrendingUp className="w-4 h-4 text-green-400" />
          <span className="text-sm text-green-400">3%</span>
          <span className="text-sm text-gray-400 ml-1">vs last month</span>
        </div>
      </div>

      <div className="bg-dark-800 rounded-lg border border-dark-700 p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-gray-400">Conversions</p>
            <p className="text-2xl font-semibold text-gray-100 mt-1">20%</p>
          </div>
          <div className="p-3 bg-purple-500/10 rounded-full">
            <Users className="w-6 h-6 text-purple-400" />
          </div>
        </div>
        <div className="mt-4 flex items-center gap-1">
          <TrendingUp className="w-4 h-4 text-green-400" />
          <span className="text-sm text-green-400">2%</span>
          <span className="text-sm text-gray-400 ml-1">vs last month</span>
        </div>
      </div>
    </div>
  );
}