import React, { useState } from 'react';
import { 
  X, Image, Link, Type, Grid, Columns, Square, Plus, 
  LayoutTemplate, Youtube, Clock, Facebook, Twitter, Linkedin, 
  Instagram, UserCheck, Building, Mail, Timer
} from 'lucide-react';

interface EmailBuilderProps {
  onClose: () => void;
}

interface EmailBlock {
  id: string;
  type: 'text' | 'image' | 'button' | 'divider' | 'spacer' | 'columns' | 'header' | 'footer' | 
        'video' | 'social' | 'dynamic' | 'timer' | 'oneColumn' | 'threeColumns';
  content?: string;
  src?: string;
  columns?: EmailBlock[][];
  links?: { [key: string]: string };
  dynamicField?: string;
  endTime?: string;
}

const blockTypes = [
  { 
    category: 'Layout',
    items: [
      { type: 'oneColumn', icon: LayoutTemplate, label: '1 Column' },
      { type: 'columns', icon: Columns, label: '2 Columns' },
      { type: 'threeColumns', icon: Grid, label: '3 Columns' },
      { type: 'header', icon: LayoutTemplate, label: 'Header Section' },
      { type: 'footer', icon: LayoutTemplate, label: 'Footer Section' }
    ]
  },
  {
    category: 'Content',
    items: [
      { type: 'text', icon: Type, label: 'Text Block' },
      { type: 'image', icon: Image, label: 'Image' },
      { type: 'button', icon: Square, label: 'Button' },
      { type: 'video', icon: Youtube, label: 'Video' },
      { type: 'divider', icon: Grid, label: 'Divider' }
    ]
  },
  {
    category: 'Interactive',
    items: [
      { type: 'social', icon: Facebook, label: 'Social Links' },
      { type: 'dynamic', icon: UserCheck, label: 'Dynamic Content' },
      { type: 'timer', icon: Timer, label: 'Countdown Timer' }
    ]
  }
];

const socialIcons = [
  { platform: 'Facebook', icon: Facebook },
  { platform: 'Twitter', icon: Twitter },
  { platform: 'LinkedIn', icon: Linkedin },
  { platform: 'Instagram', icon: Instagram }
];

const dynamicFields = [
  { field: '{First Name}', icon: UserCheck },
  { field: '{Company}', icon: Building },
  { field: '{Email}', icon: Mail }
];

export default function EmailBuilder({ onClose }: EmailBuilderProps) {
  const [blocks, setBlocks] = useState<EmailBlock[]>([]);
  const [draggedBlock, setDraggedBlock] = useState<EmailBlock | null>(null);
  const [dropTarget, setDropTarget] = useState<number>(-1);

  const handleDragStart = (blockType: string) => {
    const newBlock: EmailBlock = {
      id: Date.now().toString(),
      type: blockType as EmailBlock['type'],
      content: '',
    };
    setDraggedBlock(newBlock);
  };

  const handleDragOver = (e: React.DragEvent, index: number) => {
    e.preventDefault();
    setDropTarget(index);
  };

  const handleDrop = (e: React.DragEvent, index: number) => {
    e.preventDefault();
    if (draggedBlock) {
      const newBlocks = [...blocks];
      newBlocks.splice(index, 0, draggedBlock);
      setBlocks(newBlocks);
      setDraggedBlock(null);
      setDropTarget(-1);
    }
  };

  const handleBlockContentChange = (index: number, content: string) => {
    const newBlocks = [...blocks];
    newBlocks[index].content = content;
    setBlocks(newBlocks);
  };

  const handleRemoveBlock = (index: number) => {
    const newBlocks = [...blocks];
    newBlocks.splice(index, 1);
    setBlocks(newBlocks);
  };

  const renderBlock = (block: EmailBlock, index: number) => {
    const blockContent = () => {
      switch (block.type) {
        case 'text':
          return (
            <textarea
              value={block.content}
              onChange={(e) => handleBlockContentChange(index, e.target.value)}
              className="w-full p-3 bg-dark-600 border border-dark-500 rounded-lg text-gray-200 min-h-[100px] resize-none"
              placeholder="Enter text here..."
            />
          );

        case 'header':
          return (
            <div className="p-4 bg-dark-600 border border-dark-500 rounded-lg">
              <div className="flex items-center justify-between mb-4">
                <div className="w-32 h-12 bg-dark-500 rounded flex items-center justify-center">
                  <Image className="w-6 h-6 text-gray-400" />
                </div>
                <div className="flex gap-4">
                  <button className="text-gray-200 hover:text-primary-400">Home</button>
                  <button className="text-gray-200 hover:text-primary-400">Products</button>
                  <button className="text-gray-200 hover:text-primary-400">Contact</button>
                </div>
              </div>
            </div>
          );

        case 'footer':
          return (
            <div className="p-4 bg-dark-600 border border-dark-500 rounded-lg">
              <div className="flex flex-col items-center gap-4">
                <div className="flex gap-4">
                  {socialIcons.map((social) => (
                    <social.icon key={social.platform} className="w-5 h-5 text-gray-400 hover:text-primary-400 cursor-pointer" />
                  ))}
                </div>
                <div className="text-sm text-gray-400">
                  © 2024 Your Company. All rights reserved.
                </div>
                <div className="text-sm text-gray-400">
                  <a href="#" className="hover:text-primary-400">Unsubscribe</a>
                  {' • '}
                  <a href="#" className="hover:text-primary-400">Privacy Policy</a>
                </div>
              </div>
            </div>
          );

        case 'video':
          return (
            <div className="p-4 bg-dark-600 border border-dark-500 rounded-lg">
              <input
                type="text"
                placeholder="Enter video URL (YouTube/Vimeo)"
                className="w-full p-2 bg-dark-500 border border-dark-400 rounded text-gray-200 mb-2"
              />
              <div className="aspect-video bg-dark-500 rounded flex items-center justify-center">
                <Youtube className="w-12 h-12 text-gray-400" />
              </div>
            </div>
          );

        case 'social':
          return (
            <div className="p-4 bg-dark-600 border border-dark-500 rounded-lg">
              <div className="flex justify-center gap-4">
                {socialIcons.map((social) => (
                  <div key={social.platform} className="flex flex-col items-center gap-2">
                    <social.icon className="w-8 h-8 text-gray-400 hover:text-primary-400 cursor-pointer" />
                    <input
                      type="text"
                      placeholder={`${social.platform} URL`}
                      className="w-32 p-1 bg-dark-500 border border-dark-400 rounded text-sm text-gray-200"
                    />
                  </div>
                ))}
              </div>
            </div>
          );

        case 'dynamic':
          return (
            <div className="p-4 bg-dark-600 border border-dark-500 rounded-lg">
              <div className="flex flex-wrap gap-2">
                {dynamicFields.map((field) => (
                  <button
                    key={field.field}
                    className="flex items-center gap-2 px-3 py-1 bg-dark-500 rounded-full text-gray-200 hover:bg-dark-400"
                  >
                    <field.icon className="w-4 h-4" />
                    {field.field}
                  </button>
                ))}
              </div>
            </div>
          );

        case 'timer':
          return (
            <div className="p-4 bg-dark-600 border border-dark-500 rounded-lg">
              <input
                type="datetime-local"
                className="w-full p-2 bg-dark-500 border border-dark-400 rounded text-gray-200 mb-2"
              />
              <div className="flex justify-center gap-4">
                <div className="flex flex-col items-center">
                  <div className="w-16 h-16 bg-dark-500 rounded-lg flex items-center justify-center text-2xl font-bold text-primary-400">
                    24
                  </div>
                  <span className="text-sm text-gray-400 mt-1">Days</span>
                </div>
                <div className="flex flex-col items-center">
                  <div className="w-16 h-16 bg-dark-500 rounded-lg flex items-center justify-center text-2xl font-bold text-primary-400">
                    12
                  </div>
                  <span className="text-sm text-gray-400 mt-1">Hours</span>
                </div>
                <div className="flex flex-col items-center">
                  <div className="w-16 h-16 bg-dark-500 rounded-lg flex items-center justify-center text-2xl font-bold text-primary-400">
                    30
                  </div>
                  <span className="text-sm text-gray-400 mt-1">Minutes</span>
                </div>
              </div>
            </div>
          );

        case 'oneColumn':
          return (
            <div className="p-4 bg-dark-600 border border-dark-500 rounded-lg">
              <div className="min-h-[100px] bg-dark-500 rounded p-4 text-center text-gray-400">
                Single Column Content
              </div>
            </div>
          );

        case 'threeColumns':
          return (
            <div className="grid grid-cols-3 gap-4">
              <div className="p-4 bg-dark-600 border border-dark-500 rounded-lg">
                Column 1
              </div>
              <div className="p-4 bg-dark-600 border border-dark-500 rounded-lg">
                Column 2
              </div>
              <div className="p-4 bg-dark-600 border border-dark-500 rounded-lg">
                Column 3
              </div>
            </div>
          );

        // ... other cases remain the same
        default:
          return null;
      }
    };

    return (
      <div
        className={`my-2 transition-all ${dropTarget === index ? 'opacity-50' : ''}`}
        onDragOver={(e) => handleDragOver(e, index)}
        onDrop={(e) => handleDrop(e, index)}
      >
        <div className="relative group">
          <div className="absolute -right-4 top-1/2 -translate-y-1/2 opacity-0 group-hover:opacity-100 transition-opacity">
            <button
              onClick={() => handleRemoveBlock(index)}
              className="p-1 bg-red-500/10 text-red-400 rounded hover:bg-red-500/20"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
          {blockContent()}
        </div>
      </div>
    );
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-dark-800 rounded-lg w-full max-w-6xl h-[90vh] flex overflow-hidden">
        {/* Sidebar */}
        <div className="w-64 border-r border-dark-700 p-4 overflow-y-auto">
          <h3 className="text-lg font-semibold text-gray-100 mb-4">Elements</h3>
          <div className="space-y-6">
            {blockTypes.map((category) => (
              <div key={category.category}>
                <h4 className="text-sm font-medium text-gray-400 mb-2">{category.category}</h4>
                <div className="space-y-2">
                  {category.items.map((block) => (
                    <div
                      key={block.type}
                      draggable
                      onDragStart={() => handleDragStart(block.type)}
                      className="flex items-center gap-3 p-3 bg-dark-700 rounded-lg cursor-move hover:bg-dark-600 transition-colors"
                    >
                      <block.icon className="w-5 h-5 text-primary-400" />
                      <span className="text-gray-200">{block.label}</span>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Builder Area */}
        <div className="flex-1 flex flex-col">
          {/* Header */}
          <div className="p-4 border-b border-dark-700 flex items-center justify-between">
            <h2 className="text-lg font-semibold text-gray-100">Email Builder</h2>
            <div className="flex items-center gap-3">
              <button className="btn-secondary">Preview</button>
              <button className="btn-primary">Save Template</button>
              <button onClick={onClose} className="text-gray-400 hover:text-gray-300">
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Canvas */}
          <div className="flex-1 overflow-y-auto p-6">
            <div className="max-w-2xl mx-auto bg-dark-700 rounded-lg min-h-[600px] p-6">
              {blocks.length === 0 ? (
                <div
                  className="border-2 border-dashed border-dark-600 rounded-lg p-8 text-center"
                  onDragOver={(e) => handleDragOver(e, 0)}
                  onDrop={(e) => handleDrop(e, 0)}
                >
                  <Plus className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                  <p className="text-gray-400">Drag and drop elements here</p>
                </div>
              ) : (
                blocks.map((block, index) => (
                  <React.Fragment key={block.id}>
                    {renderBlock(block, index)}
                  </React.Fragment>
                ))
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}