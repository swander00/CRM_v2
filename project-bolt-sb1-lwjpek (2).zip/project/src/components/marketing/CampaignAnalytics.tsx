import React from 'react';
import { BarChart2, TrendingUp, Users, Mail } from 'lucide-react';

export default function CampaignAnalytics() {
  return (
    <div className="bg-dark-800 rounded-lg border border-dark-700 p-6">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-semibold text-gray-100">Campaign Analytics</h3>
        <div className="flex items-center gap-3">
          <select className="bg-dark-700 border border-dark-700 rounded-lg px-3 py-2 text-sm text-gray-200">
            <option>Last 7 days</option>
            <option>Last 30 days</option>
            <option>Last 90 days</option>
            <option>Custom Range</option>
          </select>
          <button className="btn-secondary flex items-center gap-2">
            <BarChart2 className="w-4 h-4" />
            Detailed Report
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-dark-700/50 rounded-lg p-6">
          <h4 className="text-sm font-medium text-gray-400 mb-4">Performance Overview</h4>
          <div className="h-64 flex items-center justify-center text-gray-400">
            Chart placeholder - Performance metrics over time
          </div>
        </div>

        <div className="bg-dark-700/50 rounded-lg p-6">
          <h4 className="text-sm font-medium text-gray-400 mb-4">Engagement Breakdown</h4>
          <div className="h-64 flex items-center justify-center text-gray-400">
            Chart placeholder - Engagement metrics distribution
          </div>
        </div>
      </div>

      <div className="mt-6">
        <h4 className="text-sm font-medium text-gray-400 mb-4">Top Performing Campaigns</h4>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="text-left border-b border-dark-600">
                <th className="pb-3 font-medium text-gray-400">Campaign</th>
                <th className="pb-3 font-medium text-gray-400">Type</th>
                <th className="pb-3 font-medium text-gray-400">Opens</th>
                <th className="pb-3 font-medium text-gray-400">Clicks</th>
                <th className="pb-3 font-medium text-gray-400">Conversions</th>
              </tr>
            </thead>
            <tbody className="text-sm">
              <tr className="border-b border-dark-600">
                <td className="py-3 text-gray-200">Spring Newsletter</td>
                <td className="py-3 text-gray-400">Email</td>
                <td className="py-3 text-gray-200">2,456</td>
                <td className="py-3 text-gray-200">892</td>
                <td className="py-3 text-green-400">124</td>
              </tr>
              <tr className="border-b border-dark-600">
                <td className="py-3 text-gray-200">Open House Alert</td>
                <td className="py-3 text-gray-400">SMS</td>
                <td className="py-3 text-gray-200">1,845</td>
                <td className="py-3 text-gray-200">756</td>
                <td className="py-3 text-green-400">98</td>
              </tr>
              <tr>
                <td className="py-3 text-gray-200">Market Update</td>
                <td className="py-3 text-gray-400">Social</td>
                <td className="py-3 text-gray-200">3,567</td>
                <td className="py-3 text-gray-200">1,234</td>
                <td className="py-3 text-green-400">89</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}