import React from 'react';
import { X, Calendar, RefreshCw } from 'lucide-react';

interface CalendarSyncModalProps {
  onClose: () => void;
}

export default function CalendarSyncModal({ onClose }: CalendarSyncModalProps) {
  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-dark-800 rounded-lg w-full max-w-md p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-lg font-semibold text-gray-100">Sync Calendars</h2>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-300"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-4">
          {/* Google Calendar */}
          <div className="p-4 bg-dark-700/50 rounded-lg">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-3">
                <img src="/google-calendar.svg" alt="Google Calendar" className="w-6 h-6" />
                <div>
                  <h3 className="font-medium text-gray-200">Google Calendar</h3>
                  <p className="text-sm text-gray-400">Sync with your Google Calendar</p>
                </div>
              </div>
              <button className="btn-primary text-sm">
                Connect
              </button>
            </div>
            <div className="text-xs text-gray-400">
              Last synced: Never
            </div>
          </div>

          {/* iCloud Calendar */}
          <div className="p-4 bg-dark-700/50 rounded-lg">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-3">
                <Calendar className="w-6 h-6 text-blue-400" />
                <div>
                  <h3 className="font-medium text-gray-200">iCloud Calendar</h3>
                  <p className="text-sm text-gray-400">Sync with your iCloud Calendar</p>
                </div>
              </div>
              <button className="btn-primary text-sm">
                Connect
              </button>
            </div>
            <div className="text-xs text-gray-400">
              Last synced: Never
            </div>
          </div>

          {/* Sync Settings */}
          <div className="p-4 bg-dark-700/50 rounded-lg">
            <h3 className="font-medium text-gray-200 mb-3">Sync Settings</h3>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="text-sm text-gray-400">Auto-sync frequency</div>
                <select className="bg-dark-700 border border-dark-600 rounded text-sm text-gray-200 px-2 py-1">
                  <option>Every 15 minutes</option>
                  <option>Every 30 minutes</option>
                  <option>Every hour</option>
                </select>
              </div>
              <div className="flex items-center justify-between">
                <div className="text-sm text-gray-400">Sync past events</div>
                <select className="bg-dark-700 border border-dark-600 rounded text-sm text-gray-200 px-2 py-1">
                  <option>Last 30 days</option>
                  <option>Last 90 days</option>
                  <option>Last year</option>
                </select>
              </div>
            </div>
          </div>
        </div>

        <div className="flex justify-end gap-3 mt-6">
          <button
            onClick={onClose}
            className="btn-secondary"
          >
            Cancel
          </button>
          <button className="btn-primary flex items-center gap-2">
            <RefreshCw className="w-4 h-4" />
            Sync Now
          </button>
        </div>
      </div>
    </div>
  );
}