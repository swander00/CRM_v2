import React from 'react';
import { Calendar, Plus, RefreshCw } from 'lucide-react';

interface CalendarSidebarProps {
  selectedCalendars: string[];
  onCalendarToggle: (calendar: string) => void;
  onSyncClick: () => void;
}

const calendarSources = [
  {
    id: 'native',
    name: 'CRM Calendar',
    color: '#1563df',
    icon: Calendar
  },
  {
    id: 'google',
    name: 'Google Calendar',
    color: '#EA4335',
    connected: false
  },
  {
    id: 'icloud',
    name: 'iCloud Calendar',
    color: '#147EFB',
    connected: false
  }
];

const eventTypes = [
  { id: 'viewing', name: 'Property Viewings', color: '#10B981' },
  { id: 'meeting', name: 'Client Meetings', color: '#6366F1' },
  { id: 'task', name: 'Tasks', color: '#F59E0B' }
];

export default function CalendarSidebar({ 
  selectedCalendars, 
  onCalendarToggle,
  onSyncClick 
}: CalendarSidebarProps) {
  return (
    <div className="w-64 bg-dark-800 border-r border-dark-700 p-4">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-sm font-medium text-gray-400">Calendars</h2>
        <button
          onClick={onSyncClick}
          className="text-primary-400 hover:text-primary-300 p-1 rounded-lg hover:bg-dark-700"
        >
          <RefreshCw className="w-4 h-4" />
        </button>
      </div>

      <div className="space-y-6">
        {/* Calendar Sources */}
        <div className="space-y-2">
          {calendarSources.map((calendar) => (
            <div
              key={calendar.id}
              className="flex items-center justify-between p-2 rounded-lg hover:bg-dark-700"
            >
              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={selectedCalendars.includes(calendar.id)}
                  onChange={() => onCalendarToggle(calendar.id)}
                  className="rounded border-dark-600"
                />
                <div
                  className="w-3 h-3 rounded-full"
                  style={{ backgroundColor: calendar.color }}
                />
                <span className="text-sm text-gray-200">{calendar.name}</span>
              </div>
              {'connected' in calendar && (
                <button className="text-xs text-primary-400 hover:text-primary-300">
                  {calendar.connected ? 'Connected' : 'Connect'}
                </button>
              )}
            </div>
          ))}
        </div>

        {/* Event Types */}
        <div>
          <h3 className="text-sm font-medium text-gray-400 mb-2">Event Types</h3>
          <div className="space-y-2">
            {eventTypes.map((type) => (
              <div
                key={type.id}
                className="flex items-center gap-2 p-2 rounded-lg hover:bg-dark-700"
              >
                <input
                  type="checkbox"
                  defaultChecked
                  className="rounded border-dark-600"
                />
                <div
                  className="w-3 h-3 rounded-full"
                  style={{ backgroundColor: type.color }}
                />
                <span className="text-sm text-gray-200">{type.name}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Mini Calendar (placeholder) */}
        <div className="bg-dark-700/50 rounded-lg p-4">
          <div className="text-center text-sm text-gray-400">
            Mini calendar coming soon
          </div>
        </div>
      </div>
    </div>
  );
}