import React, { useState } from 'react';
import { Star, Mail, Phone, MessageSquare, Trash2, Building2, MapPin } from 'lucide-react';
import { format } from 'date-fns';
import DeleteContactModal from './modals/DeleteContactModal';

const mockContacts = [
  {
    id: 1,
    name: 'John Smith',
    company: 'ABC Mortgages',
    type: 'Mortgage Agent',
    email: 'john.smith@abcmortgages.com',
    phone: '+1 (555) 123-4567',
    location: 'Toronto, ON',
    tags: ['A Lender', 'Preferred Partner'],
    rating: 5,
    lastContact: new Date(2024, 1, 15),
    status: 'Active'
  },
  {
    id: 2,
    name: 'Sarah Lee',
    company: 'Lee & Associates',
    type: 'Lawyer',
    email: 'sarah.lee@leelaw.com',
    phone: '+1 (555) 234-5678',
    location: 'Vancouver, BC',
    tags: ['Real Estate Law', 'Top Rated'],
    rating: 4,
    lastContact: new Date(2024, 1, 14),
    status: 'Active'
  }
];

export default function ContactTable() {
  const [contacts, setContacts] = useState(mockContacts);
  const [deleteModal, setDeleteModal] = useState<{ show: boolean; contact?: any }>({
    show: false
  });

  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }).map((_, index) => (
      <Star
        key={index}
        className={`w-4 h-4 ${
          index < rating ? 'text-yellow-400 fill-current' : 'text-gray-400'
        }`}
      />
    ));
  };

  const handleDeleteContact = (contactId: number) => {
    setContacts(contacts.filter(contact => contact.id !== contactId));
    setDeleteModal({ show: false });
  };

  return (
    <>
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-dark-800 border-b border-dark-700">
            <tr>
              <th className="px-4 py-2 text-left font-medium text-gray-400">CONTACT</th>
              <th className="px-4 py-2 text-left font-medium text-gray-400">TYPE</th>
              <th className="px-4 py-2 text-left font-medium text-gray-400">TAGS</th>
              <th className="px-4 py-2 text-left font-medium text-gray-400">RATING</th>
              <th className="px-4 py-2 text-left font-medium text-gray-400">LOCATION</th>
              <th className="px-4 py-2 text-left font-medium text-gray-400">LAST CONTACT</th>
              <th className="px-4 py-2 text-left font-medium text-gray-400">STATUS</th>
              <th className="px-4 py-2 text-left font-medium text-gray-400">ACTIONS</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-dark-700">
            {contacts.map((contact) => (
              <tr key={contact.id} className="group hover:bg-dark-800/50">
                <td className="px-4 py-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-primary-500/10 flex items-center justify-center text-primary-400">
                      {contact.name.charAt(0)}
                    </div>
                    <div>
                      <div className="font-medium text-gray-200">{contact.name}</div>
                      <div className="text-sm text-gray-400">{contact.company}</div>
                    </div>
                  </div>
                </td>
                <td className="px-4 py-4">
                  <div className="flex items-center gap-2">
                    <Building2 className="w-4 h-4 text-primary-400" />
                    <span className="text-gray-200">{contact.type}</span>
                  </div>
                </td>
                <td className="px-4 py-4">
                  <div className="flex flex-wrap gap-1">
                    {contact.tags.map((tag) => (
                      <span
                        key={tag}
                        className="px-2 py-1 text-xs rounded-full bg-primary-500/10 text-primary-400"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                </td>
                <td className="px-4 py-4">
                  <div className="flex items-center gap-1">
                    {renderStars(contact.rating)}
                  </div>
                </td>
                <td className="px-4 py-4">
                  <div className="flex items-center gap-2">
                    <MapPin className="w-4 h-4 text-gray-400" />
                    <span className="text-gray-200">{contact.location}</span>
                  </div>
                </td>
                <td className="px-4 py-4">
                  <div className="text-gray-200">
                    {format(contact.lastContact, 'MMM dd, yyyy')}
                  </div>
                </td>
                <td className="px-4 py-4">
                  <span className={`px-2 py-1 text-xs rounded-full ${
                    contact.status === 'Active'
                      ? 'bg-green-500/10 text-green-400'
                      : 'bg-gray-500/10 text-gray-400'
                  }`}>
                    {contact.status}
                  </span>
                </td>
                <td className="px-4 py-4">
                  <div className="flex items-center gap-2">
                    <button className="p-1 text-gray-400 hover:text-gray-300">
                      <Phone className="w-4 h-4" />
                    </button>
                    <button className="p-1 text-gray-400 hover:text-gray-300">
                      <Mail className="w-4 h-4" />
                    </button>
                    <button className="p-1 text-gray-400 hover:text-gray-300">
                      <MessageSquare className="w-4 h-4" />
                    </button>
                    <button 
                      onClick={() => setDeleteModal({ show: true, contact })}
                      className="p-1 text-gray-400 hover:text-red-400"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {deleteModal.show && deleteModal.contact && (
        <DeleteContactModal
          contactName={deleteModal.contact.name}
          onClose={() => setDeleteModal({ show: false })}
          onConfirm={() => handleDeleteContact(deleteModal.contact.id)}
        />
      )}
    </>
  );
}