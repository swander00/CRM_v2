import React, { useState } from 'react';
import { Search, Filter, ChevronDown, Save } from 'lucide-react';
import ContactTypeDropdown from './dropdowns/ContactTypeDropdown';
import ContactTagsDropdown from './dropdowns/ContactTagsDropdown';

export default function SearchFilters() {
  const [showAdvancedFilters, setShowAdvancedFilters] = useState(false);

  return (
    <div className="space-y-4 mb-6">
      <div className="flex flex-col lg:flex-row gap-4">
        <div className="flex-1">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="text"
              placeholder="Search contacts by name, company, or tags..."
              className="w-full pl-10 pr-4 py-2.5 bg-dark-800 border border-dark-700 text-gray-200 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent transition-all"
            />
          </div>
        </div>
        
        <div className="flex flex-wrap gap-3">
          <ContactTypeDropdown />
          <ContactTagsDropdown />

          <button className="btn-secondary flex items-center gap-2">
            <Save className="w-4 h-4" />
            Saved Views
          </button>
          
          <button 
            className="btn-secondary flex items-center gap-2"
            onClick={() => setShowAdvancedFilters(!showAdvancedFilters)}
          >
            <Filter className="w-4 h-4" />
            More Filters
            <ChevronDown className="w-4 h-4" />
          </button>
        </div>
      </div>

      {showAdvancedFilters && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mt-4 p-4 bg-dark-800 rounded-lg border border-dark-700">
          <div className="space-y-2">
            <label className="text-sm text-gray-400">Location</label>
            <select className="w-full bg-dark-700 border border-dark-600 rounded-lg px-3 py-2 text-gray-200">
              <option>All Locations</option>
              <option>Toronto</option>
              <option>Vancouver</option>
              <option>Montreal</option>
            </select>
          </div>

          <div className="space-y-2">
            <label className="text-sm text-gray-400">Rating</label>
            <select className="w-full bg-dark-700 border border-dark-600 rounded-lg px-3 py-2 text-gray-200">
              <option>All Ratings</option>
              <option>5 Stars</option>
              <option>4+ Stars</option>
              <option>3+ Stars</option>
            </select>
          </div>

          <div className="space-y-2">
            <label className="text-sm text-gray-400">Last Contact</label>
            <select className="w-full bg-dark-700 border border-dark-600 rounded-lg px-3 py-2 text-gray-200">
              <option>Any Time</option>
              <option>Last 7 Days</option>
              <option>Last 30 Days</option>
              <option>Last 90 Days</option>
            </select>
          </div>

          <div className="space-y-2">
            <label className="text-sm text-gray-400">Status</label>
            <select className="w-full bg-dark-700 border border-dark-600 rounded-lg px-3 py-2 text-gray-200">
              <option>All Status</option>
              <option>Active</option>
              <option>Inactive</option>
              <option>On Hold</option>
            </select>
          </div>
        </div>
      )}
    </div>
  );
}