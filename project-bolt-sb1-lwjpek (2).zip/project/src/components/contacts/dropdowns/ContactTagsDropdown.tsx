import React from 'react';
import Select from 'react-select';

const options = [
  {
    label: 'Mortgage Agents',
    options: [
      { value: 'a-lender', label: 'A Lenders' },
      { value: 'b-lender', label: 'B Lenders' },
      { value: 'private-lender', label: 'Private Lenders' }
    ]
  },
  {
    label: 'Service Quality',
    options: [
      { value: 'preferred', label: 'Preferred Partner' },
      { value: 'verified', label: 'Verified' },
      { value: 'top-rated', label: 'Top Rated' }
    ]
  },
  {
    label: 'Availability',
    options: [
      { value: 'weekend', label: 'Weekend Available' },
      { value: 'emergency', label: 'Emergency Service' },
      { value: '24-7', label: '24/7 Available' }
    ]
  }
];

const customStyles = {
  control: (base: any) => ({
    ...base,
    background: '#1F2937',
    borderColor: '#374151',
    minHeight: '38px',
    '&:hover': {
      borderColor: '#4B5563'
    }
  }),
  menu: (base: any) => ({
    ...base,
    background: '#1F2937',
    border: '1px solid #374151'
  }),
  group: (base: any) => ({
    ...base,
    paddingTop: 8,
    paddingBottom: 8
  }),
  groupHeading: (base: any) => ({
    ...base,
    color: '#9CA3AF',
    fontWeight: 600,
    fontSize: '0.875rem'
  }),
  option: (base: any, state: { isSelected: boolean; isFocused: boolean }) => ({
    ...base,
    backgroundColor: state.isSelected ? '#3B82F6' : state.isFocused ? '#374151' : undefined,
    color: '#E5E7EB'
  }),
  singleValue: (base: any) => ({
    ...base,
    color: '#E5E7EB'
  }),
  input: (base: any) => ({
    ...base,
    color: '#E5E7EB'
  }),
  multiValue: (base: any) => ({
    ...base,
    backgroundColor: '#374151'
  }),
  multiValueLabel: (base: any) => ({
    ...base,
    color: '#E5E7EB'
  }),
  multiValueRemove: (base: any) => ({
    ...base,
    color: '#9CA3AF',
    ':hover': {
      backgroundColor: '#4B5563',
      color: '#E5E7EB'
    }
  })
};

export default function ContactTagsDropdown() {
  return (
    <Select
      options={options}
      styles={customStyles}
      placeholder="Tags"
      className="w-56"
      isMulti
      isClearable
      theme={(theme) => ({
        ...theme,
        colors: {
          ...theme.colors,
          primary: '#3B82F6',
          primary75: '#60A5FA',
          primary50: '#93C5FD',
          primary25: '#BFDBFE',
          neutral0: '#1F2937',
          neutral5: '#374151',
          neutral10: '#4B5563',
          neutral20: '#6B7280',
          neutral30: '#9CA3AF',
          neutral40: '#D1D5DB',
          neutral50: '#E5E7EB',
          neutral60: '#F3F4F6',
          neutral70: '#F9FAFB',
          neutral80: '#FFFFFF',
          neutral90: '#FFFFFF'
        }
      })}
    />
  );
}