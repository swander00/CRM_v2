import React from 'react';
import { X, AlertTriangle } from 'lucide-react';

interface DeleteContactModalProps {
  contactName: string;
  onClose: () => void;
  onConfirm: () => void;
}

export default function DeleteContactModal({ contactName, onClose, onConfirm }: DeleteContactModalProps) {
  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-dark-800 rounded-lg w-full max-w-md p-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <AlertTriangle className="w-6 h-6 text-red-400" />
            <h3 className="text-lg font-semibold text-gray-100">Delete Contact</h3>
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-300"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="mb-6">
          <p className="text-gray-200">
            Are you sure you want to delete <span className="font-semibold">{contactName}</span>?
          </p>
          <p className="text-sm text-gray-400 mt-2">
            This action cannot be undone. All data associated with this contact will be permanently removed.
          </p>
        </div>

        <div className="flex justify-end gap-3">
          <button
            onClick={onClose}
            className="btn-secondary"
          >
            Cancel
          </button>
          <button
            onClick={onConfirm}
            className="px-4 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600 transition-colors"
          >
            Delete Contact
          </button>
        </div>
      </div>
    </div>
  );
}