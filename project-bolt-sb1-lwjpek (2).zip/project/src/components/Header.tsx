import React, { useState } from 'react';
import { Plus, Bell, Settings, Inbox, Mail, MessageSquare, Phone } from 'lucide-react';
import AddLeadModal from './modals/AddLeadModal';
import PipelineSelectionModal from './modals/PipelineSelectionModal';
import { useLeads } from '../contexts/LeadContext';

export default function Header() {
  const [showInbox, setShowInbox] = useState(false);
  const [showAddLeadModal, setShowAddLeadModal] = useState(false);
  const [showPipelineModal, setShowPipelineModal] = useState(false);
  const [selectedLead, setSelectedLead] = useState<any>(null);
  const { addLead } = useLeads();

  const handleAddLead = (leadData: any) => {
    setSelectedLead(leadData);
    setShowAddLeadModal(false);
    setShowPipelineModal(true);
  };

  const handlePipelineSelect = (pipeline: string) => {
    if (selectedLead) {
      const leadWithPipeline = {
        ...selectedLead,
        pipelineStatus: pipeline
      };
      addLead(leadWithPipeline);
      setSelectedLead(null);
    }
    setShowPipelineModal(false);
  };

  return (
    <header className="bg-dark-800 border-b border-dark-700 sticky top-0 z-50">
      <div className="w-full px-4 sm:px-6">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center gap-8">
            <h1 className="text-2xl font-bold text-gray-100">Lead Management</h1>
            <button 
              onClick={() => setShowInbox(!showInbox)}
              className={`flex items-center gap-2 px-3 py-2 rounded-lg transition-all ${
                showInbox 
                  ? 'bg-primary-500/10 text-primary-400' 
                  : 'text-gray-400 hover:text-gray-300'
              }`}
            >
              <Inbox className="w-5 h-5" />
              <span>Inbox</span>
              <span className="bg-primary-500 text-white text-xs px-2 py-0.5 rounded-full">12</span>
            </button>
          </div>

          <div className="flex items-center gap-4">
            <div className="flex -space-x-1">
              <div className="relative group">
                <button className="p-2 text-gray-400 hover:text-gray-300 hover:shadow-glow rounded-full transition-all relative">
                  <Mail className="w-5 h-5" />
                  <span className="absolute -top-1 -right-1 w-4 h-4 bg-primary-500 rounded-full text-white text-xs flex items-center justify-center">4</span>
                </button>
                <div className="hidden group-hover:block absolute top-full right-0 mt-2 w-48 bg-dark-800 border border-dark-700 rounded-lg shadow-lg p-2">
                  <div className="text-xs text-gray-400 p-2">4 unread emails</div>
                </div>
              </div>

              <div className="relative group">
                <button className="p-2 text-gray-400 hover:text-gray-300 hover:shadow-glow rounded-full transition-all relative">
                  <MessageSquare className="w-5 h-5" />
                  <span className="absolute -top-1 -right-1 w-4 h-4 bg-green-500 rounded-full text-white text-xs flex items-center justify-center">6</span>
                </button>
                <div className="hidden group-hover:block absolute top-full right-0 mt-2 w-48 bg-dark-800 border border-dark-700 rounded-lg shadow-lg p-2">
                  <div className="text-xs text-gray-400 p-2">6 unread messages</div>
                </div>
              </div>

              <div className="relative group">
                <button className="p-2 text-gray-400 hover:text-gray-300 hover:shadow-glow rounded-full transition-all relative">
                  <Phone className="w-5 h-5" />
                  <span className="absolute -top-1 -right-1 w-4 h-4 bg-yellow-500 rounded-full text-white text-xs flex items-center justify-center">2</span>
                </button>
                <div className="hidden group-hover:block absolute top-full right-0 mt-2 w-48 bg-dark-800 border border-dark-700 rounded-lg shadow-lg p-2">
                  <div className="text-xs text-gray-400 p-2">2 missed calls</div>
                </div>
              </div>
            </div>

            <button className="p-2 text-gray-400 hover:text-gray-300 hover:shadow-glow rounded-full transition-all relative">
              <Bell className="w-5 h-5" />
              <span className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 rounded-full text-white text-xs flex items-center justify-center">3</span>
            </button>

            <button className="p-2 text-gray-400 hover:text-gray-300 hover:shadow-glow rounded-full transition-all">
              <Settings className="w-5 h-5" />
            </button>

            <button 
              onClick={() => setShowAddLeadModal(true)}
              className="btn-primary flex items-center gap-2"
            >
              <Plus className="w-4 h-4" />
              Add Lead
            </button>
          </div>
        </div>
      </div>

      {showAddLeadModal && (
        <AddLeadModal
          onClose={() => setShowAddLeadModal(false)}
          onAdd={handleAddLead}
        />
      )}

      {showPipelineModal && (
        <PipelineSelectionModal
          onClose={() => {
            setShowPipelineModal(false);
            setSelectedLead(null);
          }}
          onSelect={handlePipelineSelect}
        />
      )}
    </header>
  );
}