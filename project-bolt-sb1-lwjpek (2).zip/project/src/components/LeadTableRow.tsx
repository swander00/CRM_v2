import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Phone, Mail, Star, Clock, Calendar, ExternalLink, Tag, Trash2 } from 'lucide-react';
import { Lead } from '../types/lead';
import Select from 'react-select';
import { format, formatDistanceToNow } from 'date-fns';
import { Tooltip } from 'react-tooltip';

interface LeadTableRowProps {
  lead: Lead;
  onDeleteClick: () => void;
}

const pipelineOptions = [
  { 
    value: 'new', 
    label: 'New Lead',
    color: '#94A3B8' // slate-400
  },
  { 
    value: 'contacted', 
    label: 'Tried Contacting',
    color: '#60A5FA' // blue-400
  },
  { 
    value: 'qualified', 
    label: 'Qualified',
    color: '#34D399' // emerald-400
  },
  { 
    value: 'warm', 
    label: 'Warm/Nurturing',
    color: '#FBBF24' // amber-400
  },
  { 
    value: 'hot', 
    label: 'Hot/Ready',
    color: '#F87171' // red-400
  },
  { 
    value: 'showing', 
    label: 'Showing',
    color: '#A78BFA' // violet-400
  },
  { 
    value: 'negotiating', 
    label: 'Negotiating',
    color: '#FB923C' // orange-400
  },
  { 
    value: 'pending', 
    label: 'Pending',
    color: '#38BDF8' // sky-400
  },
  { 
    value: 'closed', 
    label: 'Closed',
    color: '#4ADE80' // green-400
  }
];

const customStyles = {
  control: (base: any) => ({
    ...base,
    background: '#1F2937',
    borderColor: '#374151',
    minHeight: '30px',
    height: '30px',
    '&:hover': {
      borderColor: '#4B5563'
    }
  }),
  menu: (base: any) => ({
    ...base,
    background: '#1F2937',
    border: '1px solid #374151',
    boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06)',
    zIndex: 50
  }),
  option: (base: any, { data, isSelected, isFocused }: any) => ({
    ...base,
    backgroundColor: isSelected ? '#3B82F6' : isFocused ? '#374151' : undefined,
    color: '#E5E7EB',
    padding: '8px 12px',
    display: 'flex',
    alignItems: 'center',
    cursor: 'pointer',
    '&:before': {
      content: '""',
      display: 'block',
      width: '8px',
      height: '8px',
      borderRadius: '50%',
      backgroundColor: data.color,
      marginRight: '8px',
      flexShrink: 0
    },
    '&:active': {
      backgroundColor: '#2563EB'
    }
  }),
  singleValue: (base: any, { data }: any) => ({
    ...base,
    color: '#E5E7EB',
    display: 'flex',
    alignItems: 'center',
    '&:before': {
      content: '""',
      display: 'block',
      width: '8px',
      height: '8px',
      borderRadius: '50%',
      backgroundColor: data.color,
      marginRight: '8px',
      flexShrink: 0
    }
  }),
  input: (base: any) => ({
    ...base,
    color: '#E5E7EB',
    margin: '0',
    padding: '0'
  }),
  valueContainer: (base: any) => ({
    ...base,
    height: '30px',
    padding: '0 6px'
  }),
  indicatorsContainer: (base: any) => ({
    ...base,
    height: '30px'
  }),
  dropdownIndicator: (base: any) => ({
    ...base,
    padding: '4px',
    color: '#6B7280',
    '&:hover': {
      color: '#9CA3AF'
    }
  }),
  clearIndicator: (base: any) => ({
    ...base,
    padding: '4px',
    color: '#6B7280',
    '&:hover': {
      color: '#9CA3AF'
    }
  }),
  placeholder: (base: any) => ({
    ...base,
    color: '#9CA3AF'
  })
};

export default function LeadTableRow({ lead, onDeleteClick }: LeadTableRowProps) {
  const navigate = useNavigate();
  const [pipelineStatus, setPipelineStatus] = useState(
    pipelineOptions.find(option => option.value === lead.pipelineStatus)
  );

  const handlePipelineChange = (selectedOption: any) => {
    setPipelineStatus(selectedOption);
  };

  const handleLeadClick = () => {
    navigate(`/lead/${lead.id}`);
  };

  const renderStars = (score: number) => {
    return Array.from({ length: 5 }).map((_, index) => (
      <Star
        key={index}
        className={`w-4 h-4 ${
          index < Math.floor(score / 20) ? 'text-yellow-400 fill-current' : 'text-gray-400'
        }`}
      />
    ));
  };

  return (
    <tr className="group hover:bg-dark-800/50 transition-colors">
      <td className="px-4 py-3">
        <div className="flex items-center gap-3">
          <input type="checkbox" className="rounded border-dark-600" />
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1">
              <button 
                onClick={handleLeadClick}
                className="font-medium text-gray-200 hover:text-primary-400 transition-colors text-left"
              >
                {lead.name}
              </button>
              <span className="text-xs text-gray-400">({lead.leadType})</span>
              <div className="flex items-center gap-1">
                {renderStars(lead.leadScore)}
              </div>
            </div>
            <div className="space-y-1">
              <a
                href={`tel:${lead.phone}`}
                className="flex items-center gap-1 text-primary-400 hover:text-primary-300 transition-colors text-sm"
              >
                <Phone className="w-3 h-3" />
                {lead.phone}
              </a>
              <a
                href={`mailto:${lead.email}`}
                className="flex items-center gap-1 text-primary-400 hover:text-primary-300 transition-colors text-sm"
              >
                <Mail className="w-3 h-3" />
                {lead.email}
              </a>
              <div className="flex flex-wrap gap-1 mt-1">
                {lead.tags.map((tag) => (
                  <span
                    key={tag}
                    className="inline-flex items-center px-2 py-0.5 rounded text-xs bg-primary-500/10 text-primary-400"
                  >
                    <Tag className="w-3 h-3 mr-1" />
                    {tag}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
      </td>

      <td className="px-4 py-3 min-w-[200px]">
        <Select
          value={pipelineStatus}
          onChange={handlePipelineChange}
          options={pipelineOptions}
          styles={customStyles}
          isSearchable={false}
          isClearable
          theme={(theme) => ({
            ...theme,
            colors: {
              ...theme.colors,
              primary: '#3B82F6',
              primary75: '#60A5FA',
              primary50: '#93C5FD',
              primary25: '#BFDBFE',
              neutral0: '#1F2937',
              neutral5: '#374151',
              neutral10: '#4B5563',
              neutral20: '#6B7280',
              neutral30: '#9CA3AF',
              neutral40: '#D1D5DB',
              neutral50: '#E5E7EB',
              neutral60: '#F3F4F6',
              neutral70: '#F9FAFB',
              neutral80: '#FFFFFF',
              neutral90: '#FFFFFF'
            }
          })}
        />
      </td>

      <td className="px-4 py-3">
        <div className="flex items-center gap-1 text-xs text-gray-400">
          <ExternalLink className="w-3 h-3" />
          <a href={lead.source.url} className="hover:text-primary-400 transition-colors">
            {lead.source.type}
          </a>
        </div>
        <div className="mt-1 text-xs text-gray-500">
          {lead.source.location}
        </div>
      </td>

      <td className="px-4 py-3">
        <div className="text-xs text-gray-400">
          <div>
            <span className="font-medium">Property:</span> {lead.propertyPreferences.type}
          </div>
          <div>
            <span className="font-medium">Price:</span> ${lead.price.minBuy} - ${lead.price.maxBuy}
          </div>
          <div>
            <span className="font-medium">Beds/Baths:</span> {lead.propertyPreferences.bedrooms}bd/{lead.propertyPreferences.bathrooms}ba
          </div>
          <div>
            <span className="font-medium">Timeline:</span> {lead.timeline.intent} in {lead.timeline.urgency}
          </div>
        </div>
      </td>

      <td className="px-4 py-3">
        <div className="space-y-1 text-xs text-gray-400">
          <div className="flex items-center gap-1">
            <Clock className="w-3 h-3" />
            {formatDistanceToNow(new Date(lead.activity.lastContact.date), { addSuffix: true })}
          </div>
          <div>
            📞 {lead.activity.calls} calls
          </div>
          <div>
            📧 {lead.activity.emails.total} emails
            {lead.activity.emails.unread > 0 && (
              <span className="text-primary-400 ml-1">
                ({lead.activity.emails.unread} unread)
              </span>
            )}
          </div>
          <div>
            💬 {lead.activity.messages.total} messages
            {lead.activity.messages.unread > 0 && (
              <span className="text-primary-400 ml-1">
                ({lead.activity.messages.unread} unread)
              </span>
            )}
          </div>
        </div>
      </td>

      <td className="px-4 py-3">
        {lead.tasks.nextTask && (
          <div className="flex items-center gap-2">
            <div className={`w-2 h-2 rounded-full ${
              lead.tasks.nextTask.priority === 'high' ? 'bg-red-500' :
              lead.tasks.nextTask.priority === 'medium' ? 'bg-orange-500' :
              'bg-green-500'
            }`} />
            <div className="text-xs text-gray-400">
              <div className="font-medium">{lead.tasks.nextTask.type}</div>
              <div className="flex items-center gap-1">
                <Calendar className="w-3 h-3" />
                {format(new Date(lead.tasks.nextTask.dueDate), 'MMM dd, h:mm a')}
              </div>
              <div className="text-gray-500 truncate max-w-[200px]">
                {lead.tasks.nextTask.description}
              </div>
            </div>
          </div>
        )}
      </td>

      <td className="px-4 py-3">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-full bg-primary-500/10 flex items-center justify-center">
            {lead.assigned.name.charAt(0)}
          </div>
          <div className="text-xs">
            <div className="text-gray-200">{lead.assigned.name}</div>
            <div className="text-gray-400">
              {lead.tasks.completed}/{lead.tasks.total} tasks
            </div>
          </div>
        </div>
      </td>

      <td className="px-4 py-3">
        <div className="text-xs text-gray-400">
          {format(new Date(lead.registrationDate), 'MMM dd, yyyy')}
          <div className="text-gray-500">
            {format(new Date(lead.registrationDate), 'h:mm a')}
          </div>
        </div>
      </td>

      <td className="px-4 py-3">
        <button
          onClick={onDeleteClick}
          className="p-2 text-gray-400 hover:text-red-400 transition-colors opacity-0 group-hover:opacity-100"
        >
          <Trash2 className="w-4 h-4" />
        </button>
      </td>
    </tr>
  );
}