import React, { useState, useRef } from 'react';
import { FileText, Paperclip, Plus, Download, Eye, Trash2, X } from 'lucide-react';
import { format } from 'date-fns';

interface NotesAttachmentsProps {
  lead: any;
}

interface Note {
  id: number;
  content: string;
  author: string;
  date: string;
}

interface Attachment {
  id: number;
  name: string;
  type: string;
  size: string;
  uploadDate: string;
  url: string;
}

export default function NotesAttachments({ lead }: NotesAttachmentsProps) {
  const [showNoteModal, setShowNoteModal] = useState(false);
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [newNote, setNewNote] = useState('');
  const [notes, setNotes] = useState<Note[]>([
    {
      id: 1,
      content: 'Initial Consultation Notes: Client is looking for a luxury property in Beverly Hills. Budget range is flexible but prefers modern architecture. Mentioned potential need for home office space.',
      author: 'Sarah Wilson',
      date: new Date().toISOString()
    }
  ]);
  const [attachments, setAttachments] = useState<Attachment[]>([
    {
      id: 1,
      name: 'Pre-approval Letter.pdf',
      type: 'PDF',
      size: '2.4 MB',
      uploadDate: new Date().toISOString(),
      url: '#'
    }
  ]);
  const [dragActive, setDragActive] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleAddNote = () => {
    if (newNote.trim()) {
      const note: Note = {
        id: notes.length + 1,
        content: newNote.trim(),
        author: 'Current User', // In a real app, get from auth context
        date: new Date().toISOString()
      };
      setNotes([note, ...notes]);
      setNewNote('');
      setShowNoteModal(false);
    }
  };

  const handleFileUpload = (files: FileList) => {
    Array.from(files).forEach(file => {
      const attachment: Attachment = {
        id: attachments.length + 1,
        name: file.name,
        type: file.type.split('/')[1].toUpperCase(),
        size: `${(file.size / (1024 * 1024)).toFixed(1)} MB`,
        uploadDate: new Date().toISOString(),
        url: URL.createObjectURL(file)
      };
      setAttachments([attachment, ...attachments]);
    });
    setShowUploadModal(false);
  };

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFileUpload(e.dataTransfer.files);
    }
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      handleFileUpload(e.target.files);
    }
  };

  const NoteModal = () => (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-dark-800 rounded-lg w-full max-w-lg p-6">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold text-gray-100">Add Note</h3>
          <button
            onClick={() => setShowNoteModal(false)}
            className="text-gray-400 hover:text-gray-300"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <textarea
          value={newNote}
          onChange={(e) => setNewNote(e.target.value)}
          placeholder="Enter your note here..."
          className="w-full h-32 bg-dark-700 border border-dark-600 rounded-lg p-3 text-gray-200 placeholder-gray-500 focus:ring-2 focus:ring-primary-500 focus:border-transparent resize-none"
        />

        <div className="flex justify-end gap-3 mt-6">
          <button
            onClick={() => setShowNoteModal(false)}
            className="btn-secondary"
          >
            Cancel
          </button>
          <button
            onClick={handleAddNote}
            disabled={!newNote.trim()}
            className="btn-primary disabled:opacity-50 disabled:cursor-not-allowed"
          >
            Add Note
          </button>
        </div>
      </div>
    </div>
  );

  const UploadModal = () => (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-dark-800 rounded-lg w-full max-w-lg p-6">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold text-gray-100">Upload Files</h3>
          <button
            onClick={() => setShowUploadModal(false)}
            className="text-gray-400 hover:text-gray-300"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div
          className={`border-2 border-dashed rounded-lg p-8 text-center ${
            dragActive
              ? 'border-primary-500 bg-primary-500/10'
              : 'border-dark-600 hover:border-dark-500'
          }`}
          onDragEnter={handleDrag}
          onDragLeave={handleDrag}
          onDragOver={handleDrag}
          onDrop={handleDrop}
        >
          <input
            ref={fileInputRef}
            type="file"
            multiple
            onChange={handleFileInput}
            className="hidden"
          />

          <Paperclip className="w-8 h-8 text-gray-400 mx-auto mb-4" />
          <p className="text-gray-300 mb-2">
            Drag and drop files here, or{' '}
            <button
              onClick={() => fileInputRef.current?.click()}
              className="text-primary-400 hover:text-primary-300"
            >
              browse
            </button>
          </p>
          <p className="text-sm text-gray-400">
            Supported formats: PDF, DOC, DOCX, JPG, PNG
          </p>
        </div>

        <div className="flex justify-end gap-3 mt-6">
          <button
            onClick={() => setShowUploadModal(false)}
            className="btn-secondary"
          >
            Cancel
          </button>
        </div>
      </div>
    </div>
  );

  return (
    <div className="bg-dark-800 rounded-lg border border-dark-700 p-6">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-semibold text-gray-100">Notes & Attachments</h3>
        <div className="flex gap-2">
          <button
            onClick={() => setShowUploadModal(true)}
            className="btn-secondary flex items-center gap-2"
          >
            <Paperclip className="w-4 h-4" />
            Upload File
          </button>
          <button
            onClick={() => setShowNoteModal(true)}
            className="btn-primary flex items-center gap-2"
          >
            <Plus className="w-4 h-4" />
            Add Note
          </button>
        </div>
      </div>

      <div className="space-y-6">
        {/* Notes Section */}
        <div>
          <h4 className="text-sm font-medium text-gray-400 mb-4">Notes</h4>
          <div className="space-y-4">
            {notes.map((note) => (
              <div key={note.id} className="bg-dark-700/50 rounded-lg p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="font-medium text-gray-200">Note</span>
                  <span className="text-sm text-gray-400">
                    {format(new Date(note.date), 'MMM dd, yyyy h:mm a')}
                  </span>
                </div>
                <p className="text-sm text-gray-400">{note.content}</p>
                <div className="mt-2 flex items-center gap-2">
                  <span className="text-xs text-gray-500">Added by {note.author}</span>
                  <button className="text-xs text-primary-400 hover:text-primary-300">Edit</button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Attachments Section */}
        <div>
          <h4 className="text-sm font-medium text-gray-400 mb-4">Attachments</h4>
          <div className="space-y-3">
            {attachments.map((file) => (
              <div key={file.id} className="flex items-center justify-between p-3 bg-dark-700/50 rounded-lg">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-primary-500/10 rounded-lg flex items-center justify-center">
                    <FileText className="w-5 h-5 text-primary-400" />
                  </div>
                  <div>
                    <div className="font-medium text-gray-200">{file.name}</div>
                    <div className="text-xs text-gray-400">
                      {file.type} • {file.size} • Uploaded {format(new Date(file.uploadDate), 'MMM dd, yyyy')}
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <button className="p-2 text-gray-400 hover:text-gray-300">
                    <Eye className="w-4 h-4" />
                  </button>
                  <button className="p-2 text-gray-400 hover:text-gray-300">
                    <Download className="w-4 h-4" />
                  </button>
                  <button className="p-2 text-red-400 hover:text-red-300">
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {showNoteModal && <NoteModal />}
      {showUploadModal && <UploadModal />}
    </div>
  );
}