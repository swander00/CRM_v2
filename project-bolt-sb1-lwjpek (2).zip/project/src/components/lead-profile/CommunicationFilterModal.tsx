import React, { useState } from 'react';
import { X, Calendar } from 'lucide-react';
import Select from 'react-select';

interface CommunicationFilterModalProps {
  currentFilters: {
    types: string[];
    dateRange: string;
    status: string[];
    search: string;
  };
  onClose: () => void;
  onApply: (filters: any) => void;
}

const customSelectStyles = {
  control: (base: any) => ({
    ...base,
    background: '#1F2937',
    borderColor: '#374151',
    '&:hover': {
      borderColor: '#4B5563'
    }
  }),
  menu: (base: any) => ({
    ...base,
    background: '#1F2937',
    border: '1px solid #374151'
  }),
  option: (base: any, state: { isSelected: boolean; isFocused: boolean }) => ({
    ...base,
    backgroundColor: state.isSelected ? '#3B82F6' : state.isFocused ? '#374151' : undefined,
    color: '#E5E7EB'
  }),
  multiValue: (base: any) => ({
    ...base,
    backgroundColor: '#374151'
  }),
  multiValueLabel: (base: any) => ({
    ...base,
    color: '#E5E7EB'
  }),
  multiValueRemove: (base: any) => ({
    ...base,
    color: '#9CA3AF',
    ':hover': {
      backgroundColor: '#4B5563',
      color: '#E5E7EB'
    }
  }),
  input: (base: any) => ({
    ...base,
    color: '#E5E7EB'
  })
};

const typeOptions = [
  { value: 'all', label: 'All Types' },
  { value: 'call', label: 'Phone Calls' },
  { value: 'email', label: 'Emails' },
  { value: 'sms', label: 'SMS Messages' },
  { value: 'meeting', label: 'Meetings' },
  { value: 'note', label: 'Notes' }
];

const dateRangeOptions = [
  { value: 'today', label: 'Today' },
  { value: 'yesterday', label: 'Yesterday' },
  { value: '7days', label: 'Last 7 Days' },
  { value: '30days', label: 'Last 30 Days' },
  { value: '90days', label: 'Last 90 Days' },
  { value: 'custom', label: 'Custom Range' }
];

const statusOptions = [
  { value: 'all', label: 'All Status' },
  { value: 'completed', label: 'Completed' },
  { value: 'pending', label: 'Pending' },
  { value: 'missed', label: 'Missed' },
  { value: 'scheduled', label: 'Scheduled' }
];

export default function CommunicationFilterModal({ 
  currentFilters,
  onClose, 
  onApply 
}: CommunicationFilterModalProps) {
  const [filters, setFilters] = useState(currentFilters);
  const [showCustomDateRange, setShowCustomDateRange] = useState(false);
  const [customDateRange, setCustomDateRange] = useState({
    start: '',
    end: ''
  });

  const handleApply = () => {
    const finalFilters = {
      ...filters,
      dateRange: filters.dateRange === 'custom' ? customDateRange : filters.dateRange
    };
    onApply(finalFilters);
  };

  const handleReset = () => {
    setFilters({
      types: ['all'],
      dateRange: '7days',
      status: ['all'],
      search: ''
    });
    setCustomDateRange({ start: '', end: '' });
    setShowCustomDateRange(false);
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-dark-800 rounded-lg w-full max-w-md p-6">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold text-gray-100">Filter Communications</h3>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-300"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-6">
          {/* Communication Types */}
          <div>
            <label className="block text-sm font-medium text-gray-400 mb-2">
              Communication Types
            </label>
            <Select
              isMulti
              options={typeOptions}
              value={typeOptions.filter(option => filters.types.includes(option.value))}
              onChange={(selected) => setFilters({
                ...filters,
                types: selected.length ? selected.map(s => s.value) : ['all']
              })}
              styles={customSelectStyles}
              placeholder="Select types..."
            />
          </div>

          {/* Date Range */}
          <div>
            <label className="block text-sm font-medium text-gray-400 mb-2">
              Date Range
            </label>
            <Select
              options={dateRangeOptions}
              value={dateRangeOptions.find(option => option.value === filters.dateRange)}
              onChange={(selected) => {
                setFilters({ ...filters, dateRange: selected?.value || '7days' });
                setShowCustomDateRange(selected?.value === 'custom');
              }}
              styles={customSelectStyles}
              placeholder="Select date range..."
            />
          </div>

          {/* Custom Date Range */}
          {showCustomDateRange && (
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-400 mb-2">
                  Start Date
                </label>
                <input
                  type="date"
                  value={customDateRange.start}
                  onChange={(e) => setCustomDateRange({ ...customDateRange, start: e.target.value })}
                  className="w-full px-3 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-400 mb-2">
                  End Date
                </label>
                <input
                  type="date"
                  value={customDateRange.end}
                  onChange={(e) => setCustomDateRange({ ...customDateRange, end: e.target.value })}
                  className="w-full px-3 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200"
                />
              </div>
            </div>
          )}

          {/* Status */}
          <div>
            <label className="block text-sm font-medium text-gray-400 mb-2">
              Status
            </label>
            <Select
              isMulti
              options={statusOptions}
              value={statusOptions.filter(option => filters.status.includes(option.value))}
              onChange={(selected) => setFilters({
                ...filters,
                status: selected.length ? selected.map(s => s.value) : ['all']
              })}
              styles={customSelectStyles}
              placeholder="Select status..."
            />
          </div>
        </div>

        <div className="flex justify-between mt-6 pt-6 border-t border-dark-700">
          <button
            onClick={handleReset}
            className="text-gray-400 hover:text-gray-300"
          >
            Reset Filters
          </button>
          <div className="flex gap-3">
            <button
              onClick={onClose}
              className="btn-secondary"
            >
              Cancel
            </button>
            <button
              onClick={handleApply}
              className="btn-primary"
            >
              Apply Filters
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}