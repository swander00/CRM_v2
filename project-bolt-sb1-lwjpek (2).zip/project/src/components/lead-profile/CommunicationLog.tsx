import React, { useState } from 'react';
import { Search, Filter, Phone, Mail, MessageSquare } from 'lucide-react';
import { format } from 'date-fns';
import CommunicationFilterModal from './CommunicationFilterModal';
import ViewAllCommunicationsModal from './ViewAllCommunicationsModal';

interface CommunicationLogProps {
  lead: any;
}

const mockCommunications = [
  {
    type: 'call',
    date: new Date().toISOString(),
    content: 'Discussed property requirements and budget constraints. Client interested in viewing properties next week.',
    duration: '15 mins',
    status: 'Completed'
  },
  {
    type: 'email',
    date: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(),
    subject: 'Property Listings',
    content: 'Sent property listings matching requirements. Included virtual tour links and pricing details.',
    status: 'Opened • 2 clicks'
  },
  {
    type: 'sms',
    date: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
    content: 'Confirmed appointment for property viewing at 123 Main St.',
    status: 'Delivered & Read'
  }
];

export default function CommunicationLog({ lead }: CommunicationLogProps) {
  const [showFilterModal, setShowFilterModal] = useState(false);
  const [showAllModal, setShowAllModal] = useState(false);
  const [filters, setFilters] = useState({
    types: ['all'],
    dateRange: '7days',
    status: ['all'],
    search: ''
  });

  const handleFilterChange = (newFilters: any) => {
    setFilters(newFilters);
    setShowFilterModal(false);
  };

  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFilters(prev => ({ ...prev, search: e.target.value }));
  };

  return (
    <div className="bg-dark-800 rounded-lg border border-dark-700 p-6">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-semibold text-gray-100">Communication Log</h3>
        <div className="flex gap-2">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <input
              type="text"
              placeholder="Search communications..."
              value={filters.search}
              onChange={handleSearch}
              className="pl-9 pr-4 py-2 bg-dark-700 border border-dark-600 rounded-lg text-sm text-gray-200 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-primary-500"
            />
          </div>
          <button 
            onClick={() => setShowFilterModal(true)}
            className="btn-secondary flex items-center gap-2"
          >
            <Filter className="w-4 h-4" />
            Filter
            {(filters.types.length > 1 || filters.types[0] !== 'all' || 
              filters.status.length > 1 || filters.status[0] !== 'all') && (
              <span className="w-2 h-2 rounded-full bg-primary-500"></span>
            )}
          </button>
        </div>
      </div>

      <div className="space-y-4">
        {/* Example communication items */}
        <div className="flex items-start gap-4 p-4 bg-dark-700/50 rounded-lg hover:bg-dark-700 transition-colors">
          <div className="w-10 h-10 rounded-full bg-primary-500/10 flex items-center justify-center flex-shrink-0">
            <Phone className="w-5 h-5 text-primary-400" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between mb-1">
              <div className="font-medium text-gray-200">Phone Call</div>
              <span className="text-sm text-gray-400">
                {format(new Date(lead.activity.lastContact.date), 'MMM dd, h:mm a')}
              </span>
            </div>
            <p className="text-sm text-gray-400">
              Discussed property requirements and budget constraints. Client interested in viewing properties next week.
            </p>
            <div className="mt-2 flex items-center gap-2">
              <span className="text-xs text-gray-500">Duration: 15 mins</span>
              <button className="text-xs text-primary-400 hover:text-primary-300">Add Note</button>
            </div>
          </div>
        </div>

        <div className="flex items-start gap-4 p-4 bg-dark-700/50 rounded-lg hover:bg-dark-700 transition-colors">
          <div className="w-10 h-10 rounded-full bg-blue-500/10 flex items-center justify-center flex-shrink-0">
            <Mail className="w-5 h-5 text-blue-400" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between mb-1">
              <div className="font-medium text-gray-200">Email Sent</div>
              <span className="text-sm text-gray-400">Yesterday at 2:30 PM</span>
            </div>
            <p className="text-sm text-gray-400">
              Sent property listings matching requirements. Included virtual tour links and pricing details.
            </p>
            <div className="mt-2 flex items-center gap-2">
              <span className="text-xs text-green-400">Opened • 2 clicks</span>
              <button className="text-xs text-primary-400 hover:text-primary-300">View Email</button>
            </div>
          </div>
        </div>

        <div className="flex items-start gap-4 p-4 bg-dark-700/50 rounded-lg hover:bg-dark-700 transition-colors">
          <div className="w-10 h-10 rounded-full bg-green-500/10 flex items-center justify-center flex-shrink-0">
            <MessageSquare className="w-5 h-5 text-green-400" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between mb-1">
              <div className="font-medium text-gray-200">SMS Message</div>
              <span className="text-sm text-gray-400">2 days ago</span>
            </div>
            <p className="text-sm text-gray-400">
              Confirmed appointment for property viewing at 123 Main St.
            </p>
            <div className="mt-2 flex items-center gap-2">
              <span className="text-xs text-green-400">Delivered & Read</span>
            </div>
          </div>
        </div>
      </div>

      <div className="mt-4 text-center">
        <button 
          onClick={() => setShowAllModal(true)}
          className="text-primary-400 hover:text-primary-300 text-sm"
        >
          View All Communications
        </button>
      </div>

      {showFilterModal && (
        <CommunicationFilterModal
          currentFilters={filters}
          onClose={() => setShowFilterModal(false)}
          onApply={handleFilterChange}
        />
      )}

      {showAllModal && (
        <ViewAllCommunicationsModal
          onClose={() => setShowAllModal(false)}
          communications={mockCommunications}
        />
      )}
    </div>
  );
}