import React, { useState } from 'react';
import { DollarSign, Calculator, Home, TrendingUp, Wallet, Trash2 } from 'lucide-react';
import DeleteLeadModal from '../modals/DeleteLeadModal';

interface FinancialInformationProps {
  lead: any;
}

export default function FinancialInformation({ lead }: FinancialInformationProps) {
  const [financialData, setFinancialData] = useState({
    currentProperty: {
      currentMortgage: 450000,
      propertyValue: 850000
    }
  });

  const [mortgageCalc, setMortgageCalc] = useState({
    loanAmount: '',
    interestRate: '',
    loanTerm: '30',
    downPayment: '',
    propertyTax: '',
    condoFee: ''
  });

  const [showDeleteModal, setShowDeleteModal] = useState(false);

  const handleInputChange = (field: string, value: string) => {
    const numValue = value === '' ? '' : value.replace(/[^0-9]/g, '');
    const pathParts = field.split('.');
    
    setFinancialData(prev => {
      const newData = { ...prev };
      let current: any = newData;
      
      for (let i = 0; i < pathParts.length - 1; i++) {
        current = current[pathParts[i]];
      }
      
      current[pathParts[pathParts.length - 1]] = numValue ? parseInt(numValue) : 0;
      return newData;
    });
  };

  const formatNumber = (value: string | number) => {
    const num = typeof value === 'string' ? parseFloat(value) : value;
    return isNaN(num) ? '0' : num.toLocaleString();
  };

  const calculateMonthlyPayment = () => {
    const P = parseFloat(mortgageCalc.loanAmount.replace(/,/g, '')) - parseFloat(mortgageCalc.downPayment.replace(/,/g, '') || '0');
    const r = parseFloat(mortgageCalc.interestRate) / 100 / 12;
    const n = parseFloat(mortgageCalc.loanTerm) * 12;

    let monthlyPayment = 0;
    if (P && r && n) {
      monthlyPayment = (P * r * Math.pow(1 + r, n)) / (Math.pow(1 + r, n) - 1);
    }

    // Add optional monthly expenses
    const propertyTax = parseFloat(mortgageCalc.propertyTax.replace(/,/g, '') || '0');
    const condoFee = parseFloat(mortgageCalc.condoFee.replace(/,/g, '') || '0');
    const totalMonthly = monthlyPayment + propertyTax + condoFee;

    return totalMonthly.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  };

  const equity = financialData.currentProperty.propertyValue - financialData.currentProperty.currentMortgage;

  return (
    <div className="bg-dark-800 rounded-lg border border-dark-700 p-6">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-semibold text-gray-100">Financial Analysis</h3>
      </div>

      <div className="space-y-6">
        {/* Property Details Section */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="p-4 bg-dark-700/50 rounded-lg">
            <div className="flex items-center gap-2 mb-2">
              <Home className="w-5 h-5 text-primary-400" />
              <h4 className="font-medium text-gray-200">Current Mortgage</h4>
            </div>
            <div className="relative">
              <DollarSign className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="text"
                value={formatNumber(financialData.currentProperty.currentMortgage)}
                onChange={(e) => handleInputChange('currentProperty.currentMortgage', e.target.value)}
                className="w-full pl-10 pr-4 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200"
                placeholder="Enter current mortgage"
              />
            </div>
          </div>
          
          <div className="p-4 bg-dark-700/50 rounded-lg">
            <div className="flex items-center gap-2 mb-2">
              <TrendingUp className="w-5 h-5 text-primary-400" />
              <h4 className="font-medium text-gray-200">Property Value</h4>
            </div>
            <div className="relative">
              <DollarSign className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="text"
                value={formatNumber(financialData.currentProperty.propertyValue)}
                onChange={(e) => handleInputChange('currentProperty.propertyValue', e.target.value)}
                className="w-full pl-10 pr-4 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200"
                placeholder="Enter property value"
              />
            </div>
          </div>

          <div className="p-4 bg-primary-500/10 border border-primary-500/20 rounded-lg">
            <div className="flex items-center gap-2 mb-2">
              <Wallet className="w-5 h-5 text-primary-400" />
              <h4 className="font-medium text-gray-200">Available Equity</h4>
            </div>
            <div className="text-2xl font-semibold text-primary-400">
              ${formatNumber(equity)}
            </div>
            <div className="text-sm text-gray-400 mt-1">
              Based on current value
            </div>
          </div>
        </div>

        {/* Mortgage Calculator Section */}
        <div className="p-6 bg-dark-700/50 rounded-lg">
          <div className="flex items-center gap-2 mb-4">
            <Calculator className="w-5 h-5 text-primary-400" />
            <h4 className="font-medium text-gray-200">Mortgage Calculator</h4>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm text-gray-400 mb-2">Loan Amount</label>
              <div className="relative">
                <DollarSign className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                <input
                  type="text"
                  value={formatNumber(mortgageCalc.loanAmount)}
                  onChange={(e) => setMortgageCalc({ ...mortgageCalc, loanAmount: e.target.value.replace(/,/g, '') })}
                  className="w-full pl-10 pr-4 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200"
                  placeholder="Enter loan amount"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm text-gray-400 mb-2">Down Payment</label>
              <div className="relative">
                <DollarSign className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                <input
                  type="text"
                  value={formatNumber(mortgageCalc.downPayment)}
                  onChange={(e) => setMortgageCalc({ ...mortgageCalc, downPayment: e.target.value.replace(/,/g, '') })}
                  className="w-full pl-10 pr-4 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200"
                  placeholder="Enter down payment"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm text-gray-400 mb-2">Interest Rate (%)</label>
              <input
                type="number"
                value={mortgageCalc.interestRate}
                onChange={(e) => setMortgageCalc({ ...mortgageCalc, interestRate: e.target.value })}
                className="w-full px-4 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200"
                placeholder="Enter rate"
                step="0.1"
              />
            </div>

            <div>
              <label className="block text-sm text-gray-400 mb-2">Loan Term</label>
              <select
                value={mortgageCalc.loanTerm}
                onChange={(e) => setMortgageCalc({ ...mortgageCalc, loanTerm: e.target.value })}
                className="w-full px-4 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200"
              >
                <option value="30">30 Years</option>
                <option value="20">20 Years</option>
                <option value="15">15 Years</option>
                <option value="10">10 Years</option>
              </select>
            </div>

            {/* Optional Fields */}
            <div>
              <label className="block text-sm text-gray-400 mb-2">
                Monthly Property Tax (Optional)
              </label>
              <div className="relative">
                <DollarSign className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                <input
                  type="text"
                  value={formatNumber(mortgageCalc.propertyTax)}
                  onChange={(e) => setMortgageCalc({ ...mortgageCalc, propertyTax: e.target.value.replace(/,/g, '') })}
                  className="w-full pl-10 pr-4 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200"
                  placeholder="Enter monthly property tax"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm text-gray-400 mb-2">
                Monthly Condo Fee (Optional)
              </label>
              <div className="relative">
                <DollarSign className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                <input
                  type="text"
                  value={formatNumber(mortgageCalc.condoFee)}
                  onChange={(e) => setMortgageCalc({ ...mortgageCalc, condoFee: e.target.value.replace(/,/g, '') })}
                  className="w-full pl-10 pr-4 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200"
                  placeholder="Enter monthly condo fee"
                />
              </div>
            </div>
          </div>

          <div className="mt-4 p-4 bg-dark-800/50 rounded-lg">
            <div className="flex items-center justify-between">
              <span className="text-gray-400">Total Monthly Payment:</span>
              <span className="text-xl font-semibold text-primary-400">
                ${calculateMonthlyPayment()}
              </span>
            </div>
            <div className="text-xs text-gray-500 mt-1">
              Includes principal, interest{mortgageCalc.propertyTax && ', property tax'}{mortgageCalc.condoFee && ', condo fee'}
            </div>
          </div>
        </div>

        {/* Delete Lead Button */}
        <div className="flex justify-center pt-6 border-t border-dark-700">
          <button
            onClick={() => setShowDeleteModal(true)}
            className="flex items-center gap-2 px-4 py-2 bg-red-500/10 text-red-400 rounded-lg hover:bg-red-500/20 transition-colors"
          >
            <Trash2 className="w-4 h-4" />
            Delete Lead
          </button>
        </div>
      </div>

      {showDeleteModal && (
        <DeleteLeadModal
          leadName={lead.name}
          onClose={() => setShowDeleteModal(false)}
          onConfirm={() => {
            // Handle lead deletion here
            console.log('Deleting lead:', lead.id);
            setShowDeleteModal(false);
          }}
        />
      )}
    </div>
  );
}