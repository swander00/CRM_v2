import React, { useState } from 'react';
import { Phone, Mail, MapPin, Plus, Star, Home } from 'lucide-react';
import AddContactModal from '../contacts/modals/AddContactModal';
import ContactPreferences from './ContactPreferences';

interface ContactInformationProps {
  lead: any;
}

export default function ContactInformation({ lead }: ContactInformationProps) {
  const [showAddModal, setShowAddModal] = useState(false);
  const [preferences, setPreferences] = useState({
    email: true,
    phone: false,
    sms: false
  });

  const handleAddContact = (contactData: any) => {
    // Here you would typically integrate with your backend
    console.log('New contact data:', contactData);
    setShowAddModal(false);
  };

  const handlePreferenceChange = (type: 'email' | 'phone' | 'sms') => {
    setPreferences(prev => ({
      ...prev,
      [type]: !prev[type]
    }));
  };

  return (
    <div className="bg-dark-800 rounded-lg border border-dark-700 p-6">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-semibold text-gray-100">Contact Information</h3>
        <button 
          onClick={() => setShowAddModal(true)}
          className="btn-secondary flex items-center gap-2"
        >
          <Plus className="w-4 h-4" />
          Add Contact
        </button>
      </div>

      <div className="space-y-4">
        {/* Primary Contact */}
        <div>
          <div className="flex items-center justify-between mb-3">
            <h4 className="text-sm font-medium text-gray-400">Primary Contact</h4>
            <span className="px-2 py-1 text-xs bg-primary-500/10 text-primary-400 rounded-full">Primary</span>
          </div>
          <div className="p-4 bg-dark-700/50 rounded-lg">
            <div className="flex items-center gap-6">
              <div className="flex items-center gap-2 min-w-[200px]">
                <Phone className="w-5 h-5 text-primary-400" />
                <a href={`tel:${lead.phone}`} className="text-gray-200 hover:text-primary-400">
                  {lead.phone}
                </a>
                <Star className="w-4 h-4 text-yellow-400" fill="currentColor" />
              </div>
              <div className="flex items-center gap-2 min-w-[250px]">
                <Mail className="w-5 h-5 text-primary-400" />
                <a href={`mailto:${lead.email}`} className="text-gray-200 hover:text-primary-400">
                  {lead.email}
                </a>
              </div>
              <div className="flex items-center gap-2 flex-1">
                <Home className="w-5 h-5 text-primary-400" />
                <span className="text-gray-200">123 Main Street, Unit 4B, Beverly Hills, CA 90210</span>
              </div>
            </div>
          </div>
        </div>

        {/* Secondary Contact */}
        <div>
          <div className="flex items-center justify-between mb-3">
            <h4 className="text-sm font-medium text-gray-400">Secondary Contact</h4>
            <span className="px-2 py-1 text-xs bg-dark-700 text-gray-400 rounded-full">Secondary</span>
          </div>
          <div className="p-4 bg-dark-700/50 rounded-lg">
            <div className="flex items-center gap-6">
              <div className="flex items-center gap-2 min-w-[200px]">
                <Phone className="w-5 h-5 text-primary-400" />
                <a href="tel:+1-555-987-6543" className="text-gray-200 hover:text-primary-400">
                  +1 (555) 987-6543
                </a>
              </div>
              <div className="flex items-center gap-2 min-w-[250px]">
                <Mail className="w-5 h-5 text-primary-400" />
                <a href="mailto:secondary@example.com" className="text-gray-200 hover:text-primary-400">
                  secondary@example.com
                </a>
              </div>
              <div className="flex items-center gap-2 flex-1">
                <Home className="w-5 h-5 text-primary-400" />
                <span className="text-gray-200">456 Park Avenue, Penthouse Suite, New York, NY 10022</span>
              </div>
            </div>
          </div>
        </div>

        {/* Contact Preferences */}
        <div className="pt-2">
          <h4 className="text-sm font-medium text-gray-400 mb-3">Contact Preferences</h4>
          <ContactPreferences 
            preferences={preferences}
            onPreferenceChange={handlePreferenceChange}
          />
        </div>
      </div>

      {showAddModal && (
        <AddContactModal
          onClose={() => setShowAddModal(false)}
          onAdd={handleAddContact}
        />
      )}
    </div>
  );
}