import React, { useState } from 'react';
import { X, Search, Filter, Calendar, Eye, FileText, Phone, Mail, MessageSquare, Clock } from 'lucide-react';
import { format } from 'date-fns';

interface ViewFullTimelineModalProps {
  onClose: () => void;
  activities: any[];
}

export default function ViewFullTimelineModal({ onClose, activities }: ViewFullTimelineModalProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedType, setSelectedType] = useState('all');
  const [dateRange, setDateRange] = useState('all');

  const getIcon = (type: string) => {
    switch (type) {
      case 'view':
        return <Eye className="w-4 h-4 text-primary-400" />;
      case 'call':
        return <Phone className="w-4 h-4 text-blue-400" />;
      case 'email':
        return <Mail className="w-4 h-4 text-green-400" />;
      case 'sms':
        return <MessageSquare className="w-4 h-4 text-yellow-400" />;
      case 'document':
        return <FileText className="w-4 h-4 text-purple-400" />;
      default:
        return <Calendar className="w-4 h-4 text-gray-400" />;
    }
  };

  const filteredActivities = activities
    .filter(activity => 
      (selectedType === 'all' || activity.type === selectedType) &&
      (searchTerm === '' || 
        activity.description.toLowerCase().includes(searchTerm.toLowerCase())
      )
    )
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  const groupActivitiesByDate = () => {
    const groups: { [key: string]: typeof activities } = {};
    
    filteredActivities.forEach(activity => {
      const date = format(new Date(activity.date), 'MMM dd, yyyy');
      if (!groups[date]) {
        groups[date] = [];
      }
      groups[date].push(activity);
    });

    return groups;
  };

  const groupedActivities = groupActivitiesByDate();

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-dark-800 rounded-lg w-full max-w-4xl max-h-[90vh] overflow-hidden">
        <div className="flex items-center justify-between p-6 border-b border-dark-700">
          <h3 className="text-lg font-semibold text-gray-100">Activity Timeline</h3>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-300"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6">
          {/* Filters */}
          <div className="flex flex-col md:flex-row gap-4 mb-6">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                <input
                  type="text"
                  placeholder="Search activities..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200"
                />
              </div>
            </div>
            
            <div className="flex gap-3">
              <select
                value={selectedType}
                onChange={(e) => setSelectedType(e.target.value)}
                className="bg-dark-700 border border-dark-600 rounded-lg px-3 py-2 text-gray-200"
              >
                <option value="all">All Activities</option>
                <option value="view">Property Views</option>
                <option value="call">Calls</option>
                <option value="email">Emails</option>
                <option value="sms">SMS</option>
                <option value="document">Documents</option>
              </select>

              <select
                value={dateRange}
                onChange={(e) => setDateRange(e.target.value)}
                className="bg-dark-700 border border-dark-600 rounded-lg px-3 py-2 text-gray-200"
              >
                <option value="all">All Time</option>
                <option value="today">Today</option>
                <option value="week">This Week</option>
                <option value="month">This Month</option>
                <option value="quarter">Last 3 Months</option>
              </select>
            </div>
          </div>

          {/* Timeline */}
          <div className="relative max-h-[calc(90vh-280px)] overflow-y-auto">
            <div className="absolute top-0 bottom-0 left-4 w-px bg-dark-600"></div>
            
            <div className="space-y-6">
              {Object.entries(groupedActivities).map(([date, activities]) => (
                <div key={date} className="relative">
                  <div className="sticky top-0 z-10 mb-4 ml-10 py-2 bg-dark-800">
                    <h4 className="text-sm font-medium text-gray-400">{date}</h4>
                  </div>
                  
                  <div className="space-y-4">
                    {activities.map((activity, index) => (
                      <div key={index} className="relative pl-10">
                        <div className="absolute left-0 w-8 h-8 rounded-full bg-dark-700 flex items-center justify-center">
                          {getIcon(activity.type)}
                        </div>
                        
                        <div className="bg-dark-700/50 rounded-lg p-4">
                          <div className="flex items-center justify-between mb-2">
                            <span className="font-medium text-gray-200">
                              {activity.title}
                            </span>
                            <span className="text-sm text-gray-400">
                              {format(new Date(activity.date), 'h:mm a')}
                            </span>
                          </div>
                          
                          <p className="text-sm text-gray-400">
                            {activity.description}
                          </p>
                          
                          {activity.metadata && (
                            <div className="mt-2 text-xs text-gray-500">
                              {activity.type === 'call' && (
                                <span className="flex items-center gap-1">
                                  <Clock className="w-3 h-3" />
                                  Duration: {activity.metadata.duration}
                                </span>
                              )}
                              {activity.type === 'email' && activity.metadata.status && (
                                <span className="text-green-400">
                                  {activity.metadata.status}
                                </span>
                              )}
                            </div>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ))}

              {filteredActivities.length === 0 && (
                <div className="text-center py-8 text-gray-400">
                  No activities found matching your filters
                </div>
              )}
            </div>
          </div>
        </div>

        <div className="flex justify-end gap-3 p-6 border-t border-dark-700">
          <button onClick={onClose} className="btn-secondary">
            Close
          </button>
        </div>
      </div>
    </div>
  );
}