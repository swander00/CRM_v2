import React, { useState } from 'react';
import { Plus, Calendar, Clock, CheckCircle, AlertCircle } from 'lucide-react';
import { format } from 'date-fns';
import AddTaskModal from '../modals/AddTaskModal';
import ViewAllTasksModal from './ViewAllTasksModal';

interface LeadTasksProps {
  lead: any;
}

interface Task {
  id: number;
  title: string;
  description: string;
  dueDate: string;
  priority: 'high' | 'medium' | 'low';
  status: 'pending' | 'completed';
  assignee?: { label: string; value: string };
  completedAt?: string;
  createdAt: string;
}

export default function LeadTasks({ lead }: LeadTasksProps) {
  const [showAddModal, setShowAddModal] = useState(false);
  const [showAllTasksModal, setShowAllTasksModal] = useState(false);
  const [tasks, setTasks] = useState<{
    completed: number;
    total: number;
    nextTask: Task | null;
    allTasks: Task[];
  }>({
    completed: lead.tasks?.completed || 0,
    total: lead.tasks?.total || 0,
    nextTask: lead.tasks?.nextTask || null,
    allTasks: lead.tasks?.allTasks || []
  });

  const handleAddTask = (taskData: any) => {
    const newTask: Task = {
      ...taskData,
      id: Date.now(),
      status: 'pending',
      createdAt: new Date().toISOString()
    };

    setTasks(prev => ({
      ...prev,
      total: prev.total + 1,
      nextTask: prev.nextTask ? prev.nextTask : newTask,
      allTasks: [...prev.allTasks, newTask]
    }));

    setShowAddModal(false);
  };

  const handleCompleteTask = () => {
    if (!tasks.nextTask) return;

    setTasks(prev => ({
      ...prev,
      completed: prev.completed + 1,
      nextTask: null,
      allTasks: prev.allTasks.map(task => 
        task.id === prev.nextTask?.id 
          ? { ...task, status: 'completed', completedAt: new Date().toISOString() }
          : task
      )
    }));
  };

  const getTaskPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high':
        return 'text-red-400';
      case 'medium':
        return 'text-orange-400';
      case 'low':
        return 'text-green-400';
      default:
        return 'text-gray-400';
    }
  };

  return (
    <div className="bg-dark-800 rounded-lg border border-dark-700 p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-semibold text-gray-100">Tasks</h3>
          <p className="text-sm text-gray-400 mt-1">
            {tasks.completed} of {tasks.total} tasks completed
          </p>
        </div>
        <button 
          onClick={() => setShowAddModal(true)}
          className="btn-primary flex items-center gap-2"
        >
          <Plus className="w-4 h-4" />
          Add Task
        </button>
      </div>

      <div className="space-y-4">
        {tasks.nextTask && (
          <div className="p-4 bg-dark-700/50 rounded-lg border border-dark-600">
            <div className="flex items-start justify-between">
              <div className="flex items-start gap-3">
                <AlertCircle className={`w-5 h-5 mt-1 ${getTaskPriorityColor(tasks.nextTask.priority)}`} />
                <div>
                  <h4 className="font-medium text-gray-200">{tasks.nextTask.description}</h4>
                  <div className="mt-2 flex items-center gap-4 text-sm">
                    <div className="flex items-center gap-1 text-gray-400">
                      <Calendar className="w-4 h-4" />
                      <span>{format(new Date(tasks.nextTask.dueDate), 'MMM dd')}</span>
                    </div>
                    <div className="flex items-center gap-1 text-gray-400">
                      <Clock className="w-4 h-4" />
                      <span>{format(new Date(tasks.nextTask.dueDate), 'h:mm a')}</span>
                    </div>
                  </div>
                </div>
              </div>
              <button 
                onClick={handleCompleteTask}
                className="flex items-center gap-1 text-sm text-primary-400 hover:text-primary-300"
              >
                <CheckCircle className="w-4 h-4" />
                Complete
              </button>
            </div>
          </div>
        )}

        {/* Example completed task */}
        <div className="p-4 bg-dark-700/50 rounded-lg border border-dark-600 opacity-60">
          <div className="flex items-start justify-between">
            <div className="flex items-start gap-3">
              <CheckCircle className="w-5 h-5 mt-1 text-green-400" />
              <div>
                <h4 className="font-medium text-gray-200 line-through">Initial consultation call</h4>
                <div className="mt-2 flex items-center gap-4 text-sm">
                  <div className="flex items-center gap-1 text-gray-400">
                    <Calendar className="w-4 h-4" />
                    <span>Completed Jan 15</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="mt-6 text-center">
        <button 
          onClick={() => setShowAllTasksModal(true)}
          className="text-primary-400 hover:text-primary-300 text-sm"
        >
          View All Tasks
        </button>
      </div>

      {showAddModal && (
        <AddTaskModal
          onClose={() => setShowAddModal(false)}
          onAdd={handleAddTask}
          leadId={lead.id}
        />
      )}

      {showAllTasksModal && (
        <ViewAllTasksModal
          onClose={() => setShowAllTasksModal(false)}
          tasks={tasks.allTasks}
          onTaskComplete={(taskId) => {
            setTasks(prev => ({
              ...prev,
              completed: prev.completed + 1,
              allTasks: prev.allTasks.map(task =>
                task.id === taskId
                  ? { ...task, status: 'completed', completedAt: new Date().toISOString() }
                  : task
              )
            }));
          }}
          onTaskDelete={(taskId) => {
            setTasks(prev => ({
              ...prev,
              total: prev.total - 1,
              allTasks: prev.allTasks.filter(task => task.id !== taskId)
            }));
          }}
        />
      )}
    </div>
  );
}