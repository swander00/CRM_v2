import React, { useState } from 'react';
import { Plus, Search, Clock, MapPin, Home, DollarSign, Calendar, X, Edit2, RefreshCw, Trash2 } from 'lucide-react';
import SearchFiltersModal from './SearchFiltersModal';

interface SavedSearch {
  id: string;
  name: string;
  location: string;
  frequency: 'daily' | 'weekly' | 'monthly';
  criteria: {
    priceRange: string;
    propertyType: string;
    otherCriteria: string[];
  };
  lastSent?: string;
  nextSend?: string;
}

interface SavedSearchesProps {
  leadId: number;
}

export default function SavedSearches({ leadId }: SavedSearchesProps) {
  const [showFiltersModal, setShowFiltersModal] = useState(false);
  const [editingSearch, setEditingSearch] = useState<SavedSearch | null>(null);

  // Mock saved searches
  const [savedSearches] = useState<SavedSearch[]>([
    {
      id: '1',
      name: 'Downtown Condos',
      location: 'Downtown Los Angeles',
      frequency: 'daily',
      criteria: {
        priceRange: '$500,000-$800,000',
        propertyType: 'Condo',
        otherCriteria: ['2+ beds', '2+ baths', 'Pool']
      },
      lastSent: '2024-02-15T10:30:00',
      nextSend: '2024-02-16T10:30:00'
    },
    {
      id: '2',
      name: 'Beverly Hills Homes',
      location: 'Beverly Hills',
      frequency: 'weekly',
      criteria: {
        priceRange: '$2M-$5M',
        propertyType: 'Single Family',
        otherCriteria: ['4+ beds', '3+ baths', 'Pool', 'View']
      },
      lastSent: '2024-02-10T14:00:00',
      nextSend: '2024-02-17T14:00:00'
    }
  ]);

  const handleAddSearch = () => {
    setEditingSearch(null);
    setShowFiltersModal(true);
  };

  const handleEditSearch = (search: SavedSearch) => {
    setEditingSearch(search);
    setShowFiltersModal(true);
  };

  return (
    <div className="bg-dark-800 rounded-lg border border-dark-700 p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-semibold text-gray-100">Saved Searches</h3>
          <p className="text-sm text-gray-400 mt-1">Automated property alerts for this lead</p>
        </div>
        <button 
          onClick={handleAddSearch}
          className="btn-primary flex items-center gap-2"
        >
          <Plus className="w-4 h-4" />
          Add Search
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {savedSearches.map((search) => (
          <div 
            key={search.id}
            className="bg-dark-700/50 rounded-lg p-4 hover:bg-dark-700 transition-colors"
          >
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-start gap-3">
                <div className="p-2 bg-primary-500/10 rounded-lg">
                  <Search className="w-5 h-5 text-primary-400" />
                </div>
                <div>
                  <h4 className="font-medium text-gray-200">{search.name}</h4>
                  <div className="flex items-center gap-2 text-sm text-gray-400 mt-1">
                    <MapPin className="w-4 h-4" />
                    <span>{search.location}</span>
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <button 
                  onClick={() => handleEditSearch(search)}
                  className="p-1 text-gray-400 hover:text-gray-300"
                >
                  <Edit2 className="w-4 h-4" />
                </button>
                <button className="p-1 text-gray-400 hover:text-gray-300">
                  <RefreshCw className="w-4 h-4" />
                </button>
                <button className="p-1 text-red-400 hover:text-red-300">
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4 mb-4">
              <div className="flex items-center gap-2 text-sm text-gray-400">
                <DollarSign className="w-4 h-4" />
                <span>{search.criteria.priceRange}</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-gray-400">
                <Home className="w-4 h-4" />
                <span>{search.criteria.propertyType}</span>
              </div>
            </div>

            <div className="flex flex-wrap gap-2 mb-4">
              {search.criteria.otherCriteria.map((criteria, index) => (
                <span
                  key={index}
                  className="px-2 py-1 bg-dark-600 rounded-full text-xs text-gray-300"
                >
                  {criteria}
                </span>
              ))}
            </div>

            <div className="flex items-center justify-between pt-3 border-t border-dark-600">
              <div className="flex items-center gap-2 text-sm">
                <Clock className="w-4 h-4 text-primary-400" />
                <span className="text-gray-400">Sends {search.frequency}</span>
              </div>
              <div className="flex items-center gap-4 text-sm text-gray-400">
                {search.lastSent && (
                  <span>
                    Last sent: {new Date(search.lastSent).toLocaleDateString()}
                  </span>
                )}
                {search.nextSend && (
                  <span>
                    Next send: {new Date(search.nextSend).toLocaleDateString()}
                  </span>
                )}
              </div>
            </div>
          </div>
        ))}

        {savedSearches.length === 0 && (
          <div className="text-center py-8">
            <Search className="w-12 h-12 text-gray-400 mx-auto mb-3" />
            <p className="text-gray-400">No saved searches yet</p>
            <button
              onClick={handleAddSearch}
              className="text-primary-400 hover:text-primary-300 mt-2"
            >
              Create your first search
            </button>
          </div>
        )}
      </div>

      {showFiltersModal && (
        <SearchFiltersModal
          search={editingSearch}
          onClose={() => setShowFiltersModal(false)}
          onSave={(searchData) => {
            console.log('Save search:', searchData);
            setShowFiltersModal(false);
          }}
        />
      )}
    </div>
  );
}