import React, { useState } from 'react';
import { X, Search, Filter, Phone, Mail, MessageSquare, Calendar, Clock, ChevronDown } from 'lucide-react';
import { format } from 'date-fns';

interface ViewAllCommunicationsModalProps {
  onClose: () => void;
  communications: any[];
}

export default function ViewAllCommunicationsModal({ onClose, communications }: ViewAllCommunicationsModalProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedType, setSelectedType] = useState('all');
  const [sortBy, setSortBy] = useState('date');

  const getIcon = (type: string) => {
    switch (type) {
      case 'call':
        return <Phone className="w-5 h-5 text-blue-400" />;
      case 'email':
        return <Mail className="w-5 h-5 text-green-400" />;
      case 'sms':
        return <MessageSquare className="w-5 h-5 text-yellow-400" />;
      default:
        return <Mail className="w-5 h-5 text-gray-400" />;
    }
  };

  const filteredCommunications = communications
    .filter(comm => 
      (selectedType === 'all' || comm.type === selectedType) &&
      (searchTerm === '' || 
        comm.content.toLowerCase().includes(searchTerm.toLowerCase()) ||
        comm.subject?.toLowerCase().includes(searchTerm.toLowerCase())
      )
    )
    .sort((a, b) => {
      if (sortBy === 'date') {
        return new Date(b.date).getTime() - new Date(a.date).getTime();
      }
      return 0;
    });

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-dark-800 rounded-lg w-full max-w-4xl max-h-[90vh] overflow-hidden">
        <div className="flex items-center justify-between p-6 border-b border-dark-700">
          <h3 className="text-lg font-semibold text-gray-100">Communication History</h3>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-300"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6">
          {/* Filters */}
          <div className="flex flex-col md:flex-row gap-4 mb-6">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                <input
                  type="text"
                  placeholder="Search communications..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200"
                />
              </div>
            </div>
            
            <div className="flex gap-3">
              <select
                value={selectedType}
                onChange={(e) => setSelectedType(e.target.value)}
                className="bg-dark-700 border border-dark-600 rounded-lg px-3 py-2 text-gray-200"
              >
                <option value="all">All Types</option>
                <option value="call">Calls</option>
                <option value="email">Emails</option>
                <option value="sms">SMS</option>
              </select>

              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
                className="bg-dark-700 border border-dark-600 rounded-lg px-3 py-2 text-gray-200"
              >
                <option value="date">Most Recent</option>
                <option value="type">Type</option>
              </select>
            </div>
          </div>

          {/* Communications List */}
          <div className="space-y-4 max-h-[calc(90vh-280px)] overflow-y-auto">
            {filteredCommunications.map((comm, index) => (
              <div 
                key={index}
                className="flex items-start gap-4 p-4 bg-dark-700/50 rounded-lg hover:bg-dark-700 transition-colors"
              >
                <div className="w-10 h-10 rounded-full bg-dark-700 flex items-center justify-center flex-shrink-0">
                  {getIcon(comm.type)}
                </div>
                
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-1">
                    <div className="font-medium text-gray-200">
                      {comm.type === 'email' ? 'Email' : 
                       comm.type === 'call' ? 'Phone Call' : 
                       'SMS Message'}
                    </div>
                    <span className="text-sm text-gray-400">
                      {format(new Date(comm.date), 'MMM dd, h:mm a')}
                    </span>
                  </div>
                  
                  {comm.subject && (
                    <div className="text-sm font-medium text-gray-300 mb-1">
                      {comm.subject}
                    </div>
                  )}
                  
                  <p className="text-sm text-gray-400">
                    {comm.content}
                  </p>
                  
                  <div className="mt-2 flex items-center gap-4">
                    {comm.duration && (
                      <span className="text-xs text-gray-500 flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        Duration: {comm.duration}
                      </span>
                    )}
                    {comm.status && (
                      <span className="text-xs text-green-400">
                        {comm.status}
                      </span>
                    )}
                    <button className="text-xs text-primary-400 hover:text-primary-300">
                      View Details
                    </button>
                  </div>
                </div>
              </div>
            ))}

            {filteredCommunications.length === 0 && (
              <div className="text-center py-8 text-gray-400">
                No communications found matching your filters
              </div>
            )}
          </div>
        </div>

        <div className="flex justify-end gap-3 p-6 border-t border-dark-700">
          <button onClick={onClose} className="btn-secondary">
            Close
          </button>
        </div>
      </div>
    </div>
  );
}