import React from 'react';
import { TrendingUp, Clock, Mail, MessageSquare, Phone } from 'lucide-react';

interface PerformanceMetricsProps {
  lead: any;
}

export default function PerformanceMetrics({ lead }: PerformanceMetricsProps) {
  return (
    <div className="bg-dark-800 rounded-lg border border-dark-700 p-6">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-semibold text-gray-100">Performance & Engagement</h3>
        <select className="bg-dark-700 border border-dark-600 rounded-lg text-sm text-gray-200 px-3 py-2">
          <option value="7">Last 7 days</option>
          <option value="30">Last 30 days</option>
          <option value="90">Last 90 days</option>
        </select>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <div className="bg-dark-700/50 rounded-lg p-4">
          <div className="flex items-center justify-between mb-2">
            <div className="text-sm text-gray-400">Engagement Score</div>
            <TrendingUp className="w-4 h-4 text-green-400" />
          </div>
          <div className="text-2xl font-semibold text-gray-100">{lead.leadScore}%</div>
          <div className="text-xs text-green-400 mt-1">+5% vs last week</div>
        </div>

        <div className="bg-dark-700/50 rounded-lg p-4">
          <div className="flex items-center justify-between mb-2">
            <div className="text-sm text-gray-400">Response Time</div>
            <Clock className="w-4 h-4 text-primary-400" />
          </div>
          <div className="text-2xl font-semibold text-gray-100">2.5h</div>
          <div className="text-xs text-gray-400 mt-1">Average response time</div>
        </div>

        <div className="bg-dark-700/50 rounded-lg p-4">
          <div className="flex items-center justify-between mb-2">
            <div className="text-sm text-gray-400">Email Opens</div>
            <Mail className="w-4 h-4 text-blue-400" />
          </div>
          <div className="text-2xl font-semibold text-gray-100">85%</div>
          <div className="text-xs text-gray-400 mt-1">Open rate</div>
        </div>

        <div className="bg-dark-700/50 rounded-lg p-4">
          <div className="flex items-center justify-between mb-2">
            <div className="text-sm text-gray-400">Communication</div>
            <MessageSquare className="w-4 h-4 text-yellow-400" />
          </div>
          <div className="text-2xl font-semibold text-gray-100">24</div>
          <div className="text-xs text-gray-400 mt-1">Total interactions</div>
        </div>
      </div>

      <div className="space-y-4">
        <h4 className="text-sm font-medium text-gray-400">Engagement Timeline</h4>
        <div className="h-48 bg-dark-700/50 rounded-lg p-4">
          {/* Add engagement chart here */}
          <div className="flex items-center justify-center h-full text-gray-400">
            Engagement chart placeholder
          </div>
        </div>
      </div>
    </div>
  );
}