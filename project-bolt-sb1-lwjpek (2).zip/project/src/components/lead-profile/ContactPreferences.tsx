import React from 'react';
import { Mail, Phone, MessageSquare } from 'lucide-react';

interface ContactPreferencesProps {
  preferences: {
    email: boolean;
    phone: boolean;
    sms: boolean;
  };
  onPreferenceChange: (type: 'email' | 'phone' | 'sms') => void;
}

export default function ContactPreferences({ preferences, onPreferenceChange }: ContactPreferencesProps) {
  return (
    <div className="flex gap-2">
      <button
        onClick={() => onPreferenceChange('email')}
        className={`flex items-center gap-2 px-3 py-1 rounded-full text-sm transition-colors ${
          preferences.email
            ? 'bg-primary-500/10 text-primary-400'
            : 'bg-dark-700 text-gray-400 hover:text-gray-300'
        }`}
      >
        <Mail className="w-4 h-4" />
        Prefers Email
      </button>

      <button
        onClick={() => onPreferenceChange('phone')}
        className={`flex items-center gap-2 px-3 py-1 rounded-full text-sm transition-colors ${
          preferences.phone
            ? 'bg-primary-500/10 text-primary-400'
            : 'bg-dark-700 text-gray-400 hover:text-gray-300'
        }`}
      >
        <Phone className="w-4 h-4" />
        Prefers Phone
      </button>

      <button
        onClick={() => onPreferenceChange('sms')}
        className={`flex items-center gap-2 px-3 py-1 rounded-full text-sm transition-colors ${
          preferences.sms
            ? 'bg-primary-500/10 text-primary-400'
            : 'bg-dark-700 text-gray-400 hover:text-gray-300'
        }`}
      >
        <MessageSquare className="w-4 h-4" />
        Prefers SMS
      </button>
    </div>
  );
}