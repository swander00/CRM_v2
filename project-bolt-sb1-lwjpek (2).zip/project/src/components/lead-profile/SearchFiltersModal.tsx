import React, { useState } from 'react';
import { X, Filter } from 'lucide-react';
import Select from 'react-select';

interface SearchFiltersModalProps {
  search?: any;
  onClose: () => void;
  onSave: (searchData: any) => void;
}

const customSelectStyles = {
  control: (base: any) => ({
    ...base,
    background: '#1F2937',
    borderColor: '#374151',
    '&:hover': {
      borderColor: '#4B5563'
    }
  }),
  menu: (base: any) => ({
    ...base,
    background: '#1F2937',
    border: '1px solid #374151'
  }),
  option: (base: any, state: { isSelected: boolean; isFocused: boolean }) => ({
    ...base,
    backgroundColor: state.isSelected ? '#3B82F6' : state.isFocused ? '#374151' : undefined,
    color: '#E5E7EB'
  }),
  multiValue: (base: any) => ({
    ...base,
    backgroundColor: '#374151'
  }),
  multiValueLabel: (base: any) => ({
    ...base,
    color: '#E5E7EB'
  }),
  multiValueRemove: (base: any) => ({
    ...base,
    color: '#9CA3AF',
    ':hover': {
      backgroundColor: '#4B5563',
      color: '#E5E7EB'
    }
  }),
  input: (base: any) => ({
    ...base,
    color: '#E5E7EB'
  })
};

const alertTimeOptions = [
  { value: '9am', label: '9:00 AM' },
  { value: '12pm', label: '12:00 PM' },
  { value: '3pm', label: '3:00 PM' },
  { value: '6pm', label: '6:00 PM' }
];

const frequencyOptions = [
  { value: 'daily', label: 'Daily' },
  { value: 'weekly', label: 'Weekly' },
  { value: 'monthly', label: 'Monthly' },
  { value: 'custom', label: 'Select Days of the Week' }
];

export default function SearchFiltersModal({ search, onClose, onSave }: SearchFiltersModalProps) {
  const [showAdvancedFilters, setShowAdvancedFilters] = useState(false);
  const [searchData, setSearchData] = useState({
    name: search?.name || '',
    location: search?.location || '',
    propertyType: null,
    priceMin: '',
    priceMax: '',
    alertFrequency: { value: 'daily', label: 'Daily' },
    alertTimes: [],
    customDays: []
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(searchData);
  };

  const AdvancedFiltersModal = () => (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-dark-800 rounded-lg w-full max-w-4xl p-6">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold text-gray-100">Advanced Filters</h3>
          <button
            onClick={() => setShowAdvancedFilters(false)}
            className="text-gray-400 hover:text-gray-300"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="grid grid-cols-4 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-400 mb-2">City</label>
            <Select
              styles={customSelectStyles}
              placeholder="Select City"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-400 mb-2">Price Range</label>
            <Select
              styles={customSelectStyles}
              placeholder="Select Price Range"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-400 mb-2">Timeline</label>
            <Select
              styles={customSelectStyles}
              placeholder="Select Timeline"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-400 mb-2">Assigned Agent</label>
            <Select
              styles={customSelectStyles}
              placeholder="Select Assigned Agent"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-400 mb-2">Property Type</label>
            <Select
              styles={customSelectStyles}
              placeholder="Select Property Type"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-400 mb-2">Bedrooms</label>
            <Select
              styles={customSelectStyles}
              placeholder="Select Bedrooms"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-400 mb-2">Bathrooms</label>
            <Select
              styles={customSelectStyles}
              placeholder="Select Bathrooms"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-400 mb-2">Task Status</label>
            <Select
              styles={customSelectStyles}
              placeholder="Select Task Status"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-400 mb-2">Follow-Up Status</label>
            <Select
              styles={customSelectStyles}
              placeholder="Select Follow-Up Status"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-400 mb-2">Tags</label>
            <Select
              isMulti
              styles={customSelectStyles}
              placeholder="Select Tags"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-400 mb-2">Registration Date</label>
            <Select
              styles={customSelectStyles}
              placeholder="Select Registration Date"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-400 mb-2">Square Footage</label>
            <Select
              styles={customSelectStyles}
              placeholder="Select Square Footage"
            />
          </div>
        </div>

        <div className="flex justify-end gap-3 mt-6">
          <button
            onClick={() => setShowAdvancedFilters(false)}
            className="btn-secondary"
          >
            Cancel
          </button>
          <button
            onClick={() => setShowAdvancedFilters(false)}
            className="btn-primary"
          >
            Apply Filters
          </button>
        </div>
      </div>
    </div>
  );

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-dark-800 rounded-lg w-full max-w-2xl p-6">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold text-gray-100">
            {search ? 'Edit Search' : 'Create New Search'}
          </h3>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-300"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Search Name */}
          <div>
            <label className="block text-sm font-medium text-gray-400 mb-2">
              Search Name
            </label>
            <input
              type="text"
              value={searchData.name}
              onChange={(e) => setSearchData({ ...searchData, name: e.target.value })}
              className="w-full px-4 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200"
              placeholder="e.g., Downtown Condos"
            />
          </div>

          {/* Location and Property Type */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-400 mb-2">
                Location
              </label>
              <input
                type="text"
                value={searchData.location}
                onChange={(e) => setSearchData({ ...searchData, location: e.target.value })}
                className="w-full px-4 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200"
                placeholder="City, neighborhood, or ZIP code"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-400 mb-2">
                Property Type
              </label>
              <Select
                value={searchData.propertyType}
                onChange={(option) => setSearchData({ ...searchData, propertyType: option })}
                options={[
                  { value: 'house', label: 'House' },
                  { value: 'condo', label: 'Condo' },
                  { value: 'townhouse', label: 'Townhouse' }
                ]}
                styles={customSelectStyles}
                placeholder="Select property type"
              />
            </div>
          </div>

          {/* Price Range */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-400 mb-2">
                Min Price
              </label>
              <input
                type="text"
                value={searchData.priceMin}
                onChange={(e) => setSearchData({ ...searchData, priceMin: e.target.value })}
                className="w-full px-4 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200"
                placeholder="$"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-400 mb-2">
                Max Price
              </label>
              <input
                type="text"
                value={searchData.priceMax}
                onChange={(e) => setSearchData({ ...searchData, priceMax: e.target.value })}
                className="w-full px-4 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200"
                placeholder="$"
              />
            </div>
          </div>

          {/* Alert Settings */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-400 mb-2">
                Alert Frequency
              </label>
              <Select
                value={searchData.alertFrequency}
                onChange={(option) => setSearchData({ ...searchData, alertFrequency: option })}
                options={frequencyOptions}
                styles={customSelectStyles}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-400 mb-2">
                Alert Times
              </label>
              <Select
                isMulti
                value={searchData.alertTimes}
                onChange={(selected) => setSearchData({ ...searchData, alertTimes: selected })}
                options={alertTimeOptions}
                styles={customSelectStyles}
                placeholder="Select alert times"
              />
            </div>
          </div>

          {/* Advanced Filters Button */}
          <button
            type="button"
            onClick={() => setShowAdvancedFilters(true)}
            className="w-full flex items-center justify-center gap-2 px-4 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200 hover:bg-dark-600 transition-colors"
          >
            <Filter className="w-4 h-4" />
            Advanced Filters
          </button>

          <div className="flex justify-end gap-3 pt-6 border-t border-dark-700">
            <button
              type="button"
              onClick={onClose}
              className="btn-secondary"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="btn-primary"
            >
              {search ? 'Update Search' : 'Save Search'}
            </button>
          </div>
        </form>
      </div>

      {showAdvancedFilters && <AdvancedFiltersModal />}
    </div>
  );
}