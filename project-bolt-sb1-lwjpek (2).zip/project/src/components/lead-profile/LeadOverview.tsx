import React, { useState } from 'react';
import { Edit, Tag, Star, User, ChevronDown, Phone, Mail, MessageSquare, MessageCircle, Share2, Copy, Check, Plus, X } from 'lucide-react';
import { Lead } from '../../types/lead';
import EditProfileModal from '../modals/EditProfileModal';

interface LeadOverviewProps {
  lead: Lead;
}

interface TagOption {
  value: string;
  label: string;
  category: string;
}

const predefinedTags: TagOption[] = [
  // Buyer Categories
  { value: 'ftb', label: 'First-Time Buyer', category: 'Buyer Type' },
  { value: 'inv', label: 'Investor', category: 'Buyer Type' },
  { value: 'ups', label: 'Upsizing', category: 'Buyer Type' },
  { value: 'dns', label: 'Downsizing', category: 'Buyer Type' },
  { value: 'rel', label: 'Relocating', category: 'Buyer Type' },
  { value: 'pre', label: 'Pre-Approved', category: 'Financial' },
  { value: 'cash', label: 'Cash Buyer', category: 'Financial' },
  { value: 'npa', label: 'Needs Pre-Approval', category: 'Financial' },
  
  // Seller Categories
  { value: 'ms', label: 'Motivated Seller', category: 'Seller Type' },
  { value: 'fsbo', label: 'For Sale By Owner', category: 'Seller Type' },
  { value: 'exp', label: 'Expired Listing', category: 'Seller Type' },
  { value: 'dis', label: 'Distressed Property', category: 'Property Status' },
  
  // Property Types
  { value: 'lux', label: 'Luxury Property', category: 'Property Type' },
  { value: 'com', label: 'Commercial Property', category: 'Property Type' },
  { value: 'th', label: 'Townhouse', category: 'Property Type' },
  { value: 'con', label: 'Condo Buyer', category: 'Property Type' },
  { value: 'land', label: 'Land/Development', category: 'Property Type' },
  
  // Lead Status
  { value: 'hot', label: 'Hot Lead', category: 'Lead Status' },
  { value: 'warm', label: 'Warm Lead', category: 'Lead Status' },
  { value: 'cold', label: 'Cold Lead', category: 'Lead Status' },
  { value: 'ltp', label: 'Long-Term Prospect', category: 'Lead Status' },
];

export default function LeadOverview({ lead }: LeadOverviewProps) {
  const [showTagModal, setShowTagModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showShareModal, setShowShareModal] = useState(false);
  const [customTagInput, setCustomTagInput] = useState('');
  const [selectedTags, setSelectedTags] = useState<string[]>(lead.tags);
  const [searchQuery, setSearchQuery] = useState('');

  const handleAddTag = (tag: string) => {
    if (!selectedTags.includes(tag)) {
      setSelectedTags([...selectedTags, tag]);
    }
  };

  const handleRemoveTag = (tag: string) => {
    setSelectedTags(selectedTags.filter(t => t !== tag));
  };

  const handleAddCustomTag = () => {
    if (customTagInput.trim() && !selectedTags.includes(customTagInput.trim())) {
      setSelectedTags([...selectedTags, customTagInput.trim()]);
      setCustomTagInput('');
    }
  };

  const handleSaveProfile = (updatedLead: Partial<Lead>) => {
    // Here you would typically update the lead in your backend
    console.log('Saving lead updates:', updatedLead);
  };

  const filteredTags = predefinedTags.filter(tag => 
    tag.label.toLowerCase().includes(searchQuery.toLowerCase()) ||
    tag.category.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const groupedTags = filteredTags.reduce((acc, tag) => {
    if (!acc[tag.category]) {
      acc[tag.category] = [];
    }
    acc[tag.category].push(tag);
    return acc;
  }, {} as Record<string, TagOption[]>);

  const renderStars = (score: number) => {
    return Array.from({ length: 5 }).map((_, index) => (
      <Star
        key={index}
        className={`w-4 h-4 ${
          index < Math.floor(score / 20) ? 'text-yellow-400 fill-current' : 'text-gray-400'
        }`}
      />
    ));
  };

  const ShareModal = () => (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-dark-800 rounded-lg p-6 w-full max-w-md">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold text-gray-100">Share App Link</h3>
          <button
            onClick={() => setShowShareModal(false)}
            className="text-gray-400 hover:text-gray-300"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="grid grid-cols-5 gap-4">
          <button className="flex flex-col items-center gap-2 p-4 rounded-lg bg-dark-700 hover:bg-dark-600 transition-colors">
            <Phone className="w-6 h-6 text-primary-400" />
            <span className="text-xs text-gray-300">Call</span>
          </button>
          <button className="flex flex-col items-center gap-2 p-4 rounded-lg bg-dark-700 hover:bg-dark-600 transition-colors">
            <MessageSquare className="w-6 h-6 text-green-400" />
            <span className="text-xs text-gray-300">SMS</span>
          </button>
          <button className="flex flex-col items-center gap-2 p-4 rounded-lg bg-dark-700 hover:bg-dark-600 transition-colors">
            <MessageCircle className="w-6 h-6 text-blue-400" />
            <span className="text-xs text-gray-300">WhatsApp</span>
          </button>
          <button className="flex flex-col items-center gap-2 p-4 rounded-lg bg-dark-700 hover:bg-dark-600 transition-colors">
            <Mail className="w-6 h-6 text-yellow-400" />
            <span className="text-xs text-gray-300">Email</span>
          </button>
          <button className="flex flex-col items-center gap-2 p-4 rounded-lg bg-dark-700 hover:bg-dark-600 transition-colors">
            <Copy className="w-6 h-6 text-gray-400" />
            <span className="text-xs text-gray-300">Copy</span>
          </button>
        </div>

        <div className="mt-6 text-center text-sm text-gray-400">
          Choose how you want to share the app link with {lead.name}
        </div>
      </div>
    </div>
  );

  const TagModal = () => (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-dark-800 rounded-lg w-full max-w-2xl p-6 shadow-xl max-h-[80vh] overflow-hidden">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold text-gray-100">Manage Tags</h3>
          <button
            onClick={() => setShowTagModal(false)}
            className="text-gray-400 hover:text-gray-300 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="mb-4">
          <div className="relative">
            <input
              type="text"
              placeholder="Search tags..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-dark-700 border border-dark-600 rounded-lg pl-10 pr-4 py-2 text-gray-200 placeholder-gray-500 focus:ring-2 focus:ring-primary-500 focus:border-transparent"
            />
            <Tag className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
          </div>
        </div>

        <div className="flex flex-wrap gap-2 mb-4 p-4 bg-dark-700/50 rounded-lg">
          {selectedTags.map((tag) => (
            <span
              key={tag}
              className="inline-flex items-center gap-1 px-3 py-1 rounded-full text-sm bg-primary-500/10 text-primary-400"
            >
              {tag}
              <button
                onClick={() => handleRemoveTag(tag)}
                className="hover:text-primary-300"
              >
                <X className="w-3 h-3" />
              </button>
            </span>
          ))}
        </div>

        <div className="mb-4">
          <div className="flex gap-2">
            <input
              type="text"
              placeholder="Create custom tag..."
              value={customTagInput}
              onChange={(e) => setCustomTagInput(e.target.value)}
              className="flex-1 bg-dark-700 border border-dark-600 rounded-lg px-4 py-2 text-gray-200 placeholder-gray-500 focus:ring-2 focus:ring-primary-500 focus:border-transparent"
            />
            <button
              onClick={handleAddCustomTag}
              disabled={!customTagInput.trim()}
              className="btn-primary disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Add Custom Tag
            </button>
          </div>
        </div>

        <div className="overflow-y-auto max-h-[40vh] space-y-4">
          {Object.entries(groupedTags).map(([category, tags]) => (
            <div key={category}>
              <h4 className="text-sm font-medium text-gray-400 mb-2">{category}</h4>
              <div className="flex flex-wrap gap-2">
                {tags.map((tag) => (
                  <button
                    key={tag.value}
                    onClick={() => handleAddTag(tag.label)}
                    disabled={selectedTags.includes(tag.label)}
                    className={`px-3 py-1 rounded-full text-sm transition-colors ${
                      selectedTags.includes(tag.label)
                        ? 'bg-primary-500/10 text-primary-400 cursor-not-allowed'
                        : 'bg-dark-700 text-gray-400 hover:bg-dark-600 hover:text-gray-300'
                    }`}
                  >
                    {tag.label}
                  </button>
                ))}
              </div>
            </div>
          ))}
        </div>

        <div className="flex justify-end gap-3 mt-6 pt-4 border-t border-dark-700">
          <button
            onClick={() => setShowTagModal(false)}
            className="btn-secondary"
          >
            Cancel
          </button>
          <button
            onClick={() => {
              // Here you would typically save the tags to your backend
              lead.tags = selectedTags;
              setShowTagModal(false);
            }}
            className="btn-primary"
          >
            Save Tags
          </button>
        </div>
      </div>
    </div>
  );

  return (
    <div className="bg-dark-800 rounded-lg border border-dark-700 p-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 bg-primary-500/10 rounded-full flex items-center justify-center">
            <User className="w-8 h-8 text-primary-400" />
          </div>
          <div>
            <div className="flex items-center gap-3">
              <h2 className="text-xl font-semibold text-gray-100">{lead.name}</h2>
              <span className="px-2 py-1 bg-primary-500/10 text-primary-400 text-sm rounded-full">
                {lead.leadType}
              </span>
            </div>
            <div className="flex items-center gap-4 mt-1">
              <div className="flex items-center gap-1">
                {renderStars(lead.leadScore)}
              </div>
              <span className="text-sm text-gray-400">
                Lead Score: {lead.leadScore}
              </span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => setShowShareModal(true)}
            className="btn-secondary flex items-center gap-2"
          >
            <Share2 className="w-4 h-4" />
            Send App Link
          </button>
          <button
            onClick={() => setShowEditModal(true)}
            className="btn-primary flex items-center gap-2"
          >
            <Edit className="w-4 h-4" />
            Edit Profile
          </button>
        </div>
      </div>

      <div className="grid grid-cols-4 gap-4 mt-6">
        <button className="flex flex-col items-center gap-2 p-4 rounded-lg bg-dark-700 hover:bg-dark-600 transition-colors">
          <Phone className="w-6 h-6 text-primary-400" />
          <span className="text-sm text-gray-300">Call</span>
        </button>
        <button className="flex flex-col items-center gap-2 p-4 rounded-lg bg-dark-700 hover:bg-dark-600 transition-colors">
          <MessageSquare className="w-6 h-6 text-green-400" />
          <span className="text-sm text-gray-300">SMS</span>
        </button>
        <button className="flex flex-col items-center gap-2 p-4 rounded-lg bg-dark-700 hover:bg-dark-600 transition-colors">
          <MessageCircle className="w-6 h-6 text-blue-400" />
          <span className="text-sm text-gray-300">WhatsApp</span>
        </button>
        <button className="flex flex-col items-center gap-2 p-4 rounded-lg bg-dark-700 hover:bg-dark-600 transition-colors">
          <Mail className="w-6 h-6 text-yellow-400" />
          <span className="text-sm text-gray-300">Email</span>
        </button>
      </div>

      <div className="mt-6">
        <div className="flex items-center justify-between mb-2">
          <h4 className="text-sm font-medium text-gray-400">Tags</h4>
          <button
            onClick={() => setShowTagModal(true)}
            className="text-sm text-primary-400 hover:text-primary-300"
          >
            Manage Tags
          </button>
        </div>
        <div className="flex flex-wrap gap-2">
          {selectedTags.map((tag) => (
            <span
              key={tag}
              className="px-3 py-1 rounded-full text-sm bg-primary-500/10 text-primary-400"
            >
              {tag}
            </span>
          ))}
          <button
            onClick={() => setShowTagModal(true)}
            className="w-8 h-8 rounded-full bg-dark-700 hover:bg-dark-600 flex items-center justify-center text-gray-400 hover:text-gray-300 transition-colors"
          >
            <Plus className="w-4 h-4" />
          </button>
        </div>
      </div>

      {showTagModal && <TagModal />}
      {showShareModal && <ShareModal />}
      {showEditModal && (
        <EditProfileModal
          lead={lead}
          isOpen={showEditModal}
          onClose={() => setShowEditModal(false)}
          onSave={handleSaveProfile}
        />
      )}
    </div>
  );
}