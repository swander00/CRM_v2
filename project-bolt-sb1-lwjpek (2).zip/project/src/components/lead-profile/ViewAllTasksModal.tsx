import React, { useState } from 'react';
import { X, Search, Filter, Calendar, Clock, CheckCircle, Trash2, AlertCircle } from 'lucide-react';
import { format } from 'date-fns';
import Select from 'react-select';

interface ViewAllTasksModalProps {
  onClose: () => void;
  tasks: any[];
  onTaskComplete: (taskId: number) => void;
  onTaskDelete: (taskId: number) => void;
}

const customSelectStyles = {
  control: (base: any) => ({
    ...base,
    background: '#1F2937',
    borderColor: '#374151',
    '&:hover': {
      borderColor: '#4B5563'
    }
  }),
  menu: (base: any) => ({
    ...base,
    background: '#1F2937',
    border: '1px solid #374151'
  }),
  option: (base: any, state: { isSelected: boolean; isFocused: boolean }) => ({
    ...base,
    backgroundColor: state.isSelected ? '#3B82F6' : state.isFocused ? '#374151' : undefined,
    color: '#E5E7EB'
  }),
  input: (base: any) => ({
    ...base,
    color: '#E5E7EB'
  })
};

export default function ViewAllTasksModal({ onClose, tasks, onTaskComplete, onTaskDelete }: ViewAllTasksModalProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState({ value: 'all', label: 'All Status' });
  const [priorityFilter, setPriorityFilter] = useState({ value: 'all', label: 'All Priorities' });

  const statusOptions = [
    { value: 'all', label: 'All Status' },
    { value: 'pending', label: 'Pending' },
    { value: 'completed', label: 'Completed' },
    { value: 'overdue', label: 'Overdue' }
  ];

  const priorityOptions = [
    { value: 'all', label: 'All Priorities' },
    { value: 'high', label: 'High Priority' },
    { value: 'medium', label: 'Medium Priority' },
    { value: 'low', label: 'Low Priority' }
  ];

  const getTaskPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high':
        return 'text-red-400';
      case 'medium':
        return 'text-orange-400';
      case 'low':
        return 'text-green-400';
      default:
        return 'text-gray-400';
    }
  };

  const filteredTasks = tasks.filter(task => {
    const matchesSearch = task.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         task.title?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter.value === 'all' || task.status === statusFilter.value;
    const matchesPriority = priorityFilter.value === 'all' || task.priority === priorityFilter.value;
    
    return matchesSearch && matchesStatus && matchesPriority;
  });

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-dark-800 rounded-lg w-full max-w-4xl max-h-[90vh] overflow-hidden">
        <div className="flex items-center justify-between p-6 border-b border-dark-700">
          <h3 className="text-lg font-semibold text-gray-100">All Tasks</h3>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-300"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6">
          {/* Filters */}
          <div className="flex flex-col md:flex-row gap-4 mb-6">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                <input
                  type="text"
                  placeholder="Search tasks..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200"
                />
              </div>
            </div>
            
            <div className="flex gap-3">
              <Select
                value={statusFilter}
                onChange={(option) => setStatusFilter(option || statusOptions[0])}
                options={statusOptions}
                styles={customSelectStyles}
                className="w-40"
              />

              <Select
                value={priorityFilter}
                onChange={(option) => setPriorityFilter(option || priorityOptions[0])}
                options={priorityOptions}
                styles={customSelectStyles}
                className="w-40"
              />
            </div>
          </div>

          {/* Tasks List */}
          <div className="space-y-4 max-h-[calc(90vh-280px)] overflow-y-auto">
            {filteredTasks.map((task) => (
              <div 
                key={task.id}
                className={`p-4 bg-dark-700/50 rounded-lg border border-dark-600 ${
                  task.status === 'completed' ? 'opacity-60' : ''
                }`}
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-start gap-3">
                    {task.status === 'completed' ? (
                      <CheckCircle className="w-5 h-5 mt-1 text-green-400" />
                    ) : (
                      <AlertCircle className={`w-5 h-5 mt-1 ${getTaskPriorityColor(task.priority)}`} />
                    )}
                    
                    <div>
                      <h4 className={`font-medium text-gray-200 ${
                        task.status === 'completed' ? 'line-through' : ''
                      }`}>
                        {task.description}
                      </h4>
                      
                      <div className="mt-2 flex items-center gap-4 text-sm">
                        <div className="flex items-center gap-1 text-gray-400">
                          <Calendar className="w-4 h-4" />
                          <span>
                            {task.status === 'completed' 
                              ? `Completed ${format(new Date(task.completedAt), 'MMM dd')}`
                              : format(new Date(task.dueDate), 'MMM dd')}
                          </span>
                        </div>
                        
                        {task.status !== 'completed' && (
                          <div className="flex items-center gap-1 text-gray-400">
                            <Clock className="w-4 h-4" />
                            <span>{format(new Date(task.dueDate), 'h:mm a')}</span>
                          </div>
                        )}
                        
                        {task.assignee && (
                          <div className="text-gray-400">
                            Assigned to: {task.assignee.label}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    {task.status !== 'completed' && (
                      <button
                        onClick={() => onTaskComplete(task.id)}
                        className="p-1 text-primary-400 hover:text-primary-300"
                      >
                        <CheckCircle className="w-4 h-4" />
                      </button>
                    )}
                    <button
                      onClick={() => onTaskDelete(task.id)}
                      className="p-1 text-red-400 hover:text-red-300"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            ))}

            {filteredTasks.length === 0 && (
              <div className="text-center py-8 text-gray-400">
                No tasks found matching your filters
              </div>
            )}
          </div>
        </div>

        <div className="flex justify-end gap-3 p-6 border-t border-dark-700">
          <button onClick={onClose} className="btn-secondary">
            Close
          </button>
        </div>
      </div>
    </div>
  );
}