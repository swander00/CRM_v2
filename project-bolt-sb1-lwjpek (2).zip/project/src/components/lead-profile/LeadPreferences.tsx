import React, { useState } from 'react';
import { Home, DollarSign, MapPin, Calendar, Edit, FileText, Plus } from 'lucide-react';
import EditPreferencesModal from './EditPreferencesModal';

interface LeadPreferencesProps {
  lead: any;
}

export default function LeadPreferences({ lead }: LeadPreferencesProps) {
  const [activeView, setActiveView] = useState<'buy' | 'sell'>('buy');
  const [showAddNote, setShowAddNote] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [preferences, setPreferences] = useState(lead);

  const buyingDetails = {
    priceRange: `${preferences.price.minBuy} - ${preferences.price.maxBuy}`,
    location: preferences.source.location,
    propertyType: preferences.propertyPreferences.type,
    bedrooms: preferences.propertyPreferences.bedrooms,
    bathrooms: preferences.propertyPreferences.bathrooms,
    size: preferences.propertyPreferences.squareFootage,
    lotSize: preferences.propertyPreferences.lotSize,
    timeline: preferences.timeline.urgency,
    notes: [
      {
        id: 1,
        date: '2024-02-15',
        note: 'Client prefers modern architecture with open floor plan. Must have a home office.',
        author: 'Sarah Wilson'
      },
      {
        id: 2,
        date: '2024-02-10',
        note: 'Looking for properties with pool or space to add one.',
        author: 'John Davis'
      }
    ]
  };

  const sellingDetails = {
    expectedPrice: '1.2M - 1.5M',
    location: '123 Main Street, Beverly Hills',
    propertyType: 'Single Family Home',
    bedrooms: 4,
    bathrooms: 3,
    size: '2,500 sqft',
    lotSize: '0.25 acres',
    timeline: '3-6 months',
    notes: [
      {
        id: 1,
        date: '2024-02-15',
        note: 'Property has been recently renovated with new kitchen appliances and hardwood floors throughout.',
        author: 'Sarah Wilson'
      },
      {
        id: 2,
        date: '2024-02-10',
        note: 'Basement was waterproofed in 2023. All documentation available.',
        author: 'John Davis'
      }
    ]
  };

  const activeDetails = activeView === 'buy' ? buyingDetails : sellingDetails;

  const handleSavePreferences = (updatedPreferences: any) => {
    setPreferences(prev => ({
      ...prev,
      ...updatedPreferences
    }));
    setShowEditModal(false);
  };

  return (
    <div className="bg-dark-800 rounded-lg border border-dark-700 p-6">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-semibold text-gray-100">Property Preferences</h3>
        <button 
          onClick={() => setShowEditModal(true)}
          className="btn-secondary flex items-center gap-2"
        >
          <Edit className="w-4 h-4" />
          Edit Preferences
        </button>
      </div>

      {/* Rest of the component remains the same until the end */}
      <div className="flex gap-3 mb-6">
        <button
          onClick={() => setActiveView('buy')}
          className={`flex-1 py-3 px-4 rounded-lg font-medium transition-all ${
            activeView === 'buy'
              ? 'bg-primary-500 text-white shadow-glow'
              : 'bg-dark-700/50 text-gray-400 hover:bg-dark-700'
          }`}
        >
          Property to Buy
        </button>
        <button
          onClick={() => setActiveView('sell')}
          className={`flex-1 py-3 px-4 rounded-lg font-medium transition-all ${
            activeView === 'sell'
              ? 'bg-primary-500 text-white shadow-glow'
              : 'bg-dark-700/50 text-gray-400 hover:bg-dark-700'
          }`}
        >
          Property to Sell
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-4">
          <div className="flex items-start gap-3 p-4 bg-dark-700/50 rounded-lg">
            <DollarSign className="w-5 h-5 text-primary-400 mt-1" />
            <div>
              <h4 className="text-sm font-medium text-gray-400">
                {activeView === 'buy' ? 'Budget Range' : 'Expected Price'}
              </h4>
              <div className="mt-1 text-gray-200">
                ${activeDetails.priceRange}
              </div>
            </div>
          </div>

          <div className="flex items-start gap-3 p-4 bg-dark-700/50 rounded-lg">
            <Home className="w-5 h-5 text-primary-400 mt-1" />
            <div>
              <h4 className="text-sm font-medium text-gray-400">Property Details</h4>
              <div className="mt-1 space-y-1 text-gray-200">
                <div>Type: {activeDetails.propertyType}</div>
                <div>Bedrooms: {activeDetails.bedrooms}</div>
                <div>Bathrooms: {activeDetails.bathrooms}</div>
                <div>Size: {activeDetails.size}</div>
                {activeDetails.lotSize && (
                  <div>Lot Size: {activeDetails.lotSize}</div>
                )}
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-4">
          <div className="flex items-start gap-3 p-4 bg-dark-700/50 rounded-lg">
            <MapPin className="w-5 h-5 text-primary-400 mt-1" />
            <div>
              <h4 className="text-sm font-medium text-gray-400">
                {activeView === 'buy' ? 'Preferred Location' : 'Property Location'}
              </h4>
              <div className="mt-1 text-gray-200">{activeDetails.location}</div>
            </div>
          </div>

          <div className="flex items-start gap-3 p-4 bg-dark-700/50 rounded-lg">
            <Calendar className="w-5 h-5 text-primary-400 mt-1" />
            <div>
              <h4 className="text-sm font-medium text-gray-400">Timeline</h4>
              <div className="mt-1 space-y-1 text-gray-200">
                <div>Intent: {activeView === 'buy' ? 'Buying' : 'Selling'}</div>
                <div>Timeline: {activeDetails.timeline}</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {activeView === 'sell' && (
        <div className="mt-6 p-4 bg-primary-500/10 rounded-lg">
          <h4 className="text-sm font-medium text-gray-200 mb-2">Property Features</h4>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center p-3 bg-dark-700/50 rounded-lg">
              <div className="text-primary-400 font-semibold">2018</div>
              <div className="text-xs text-gray-400 mt-1">Year Built</div>
            </div>
            <div className="text-center p-3 bg-dark-700/50 rounded-lg">
              <div className="text-primary-400 font-semibold">2</div>
              <div className="text-xs text-gray-400 mt-1">Car Garage</div>
            </div>
            <div className="text-center p-3 bg-dark-700/50 rounded-lg">
              <div className="text-primary-400 font-semibold">Yes</div>
              <div className="text-xs text-gray-400 mt-1">Pool</div>
            </div>
            <div className="text-center p-3 bg-dark-700/50 rounded-lg">
              <div className="text-primary-400 font-semibold">Central</div>
              <div className="text-xs text-gray-400 mt-1">A/C</div>
            </div>
          </div>
        </div>
      )}

      <div className="mt-6">
        <div className="flex items-center justify-between mb-4">
          <h4 className="text-sm font-medium text-gray-200">Property Notes</h4>
          <button 
            onClick={() => setShowAddNote(!showAddNote)}
            className="btn-secondary flex items-center gap-2 text-sm"
          >
            <Plus className="w-4 h-4" />
            Add Note
          </button>
        </div>

        {showAddNote && (
          <div className="mb-4 p-4 bg-dark-700/50 rounded-lg">
            <textarea
              placeholder="Enter your note here..."
              className="w-full bg-dark-800 border border-dark-600 rounded-lg p-3 text-gray-200 placeholder-gray-500 focus:ring-2 focus:ring-primary-500 focus:border-transparent"
              rows={3}
            />
            <div className="flex justify-end gap-2 mt-3">
              <button 
                onClick={() => setShowAddNote(false)}
                className="btn-secondary text-sm"
              >
                Cancel
              </button>
              <button className="btn-primary text-sm">
                Save Note
              </button>
            </div>
          </div>
        )}

        <div className="space-y-3">
          {activeDetails.notes.map((note) => (
            <div key={note.id} className="p-4 bg-dark-700/50 rounded-lg">
              <div className="flex items-start gap-3">
                <FileText className="w-5 h-5 text-primary-400 mt-1" />
                <div>
                  <p className="text-gray-200 text-sm">{note.note}</p>
                  <div className="flex items-center gap-4 mt-2">
                    <span className="text-xs text-gray-400">Added by {note.author}</span>
                    <span className="text-xs text-gray-400">{note.date}</span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {showEditModal && (
        <EditPreferencesModal
          lead={preferences}
          onClose={() => setShowEditModal(false)}
          onSave={handleSavePreferences}
        />
      )}
    </div>
  );
}