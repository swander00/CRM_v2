import React, { useState } from 'react';
import { Calendar, Eye, FileText, Phone, Mail, MessageSquare, Clock } from 'lucide-react';
import { format } from 'date-fns';
import ViewFullTimelineModal from './ViewFullTimelineModal';

interface LeadActivityTimelineProps {
  lead: any;
}

export default function LeadActivityTimeline({ lead }: LeadActivityTimelineProps) {
  const [showFullTimeline, setShowFullTimeline] = useState(false);

  const mockActivities = [
    {
      type: 'view',
      date: new Date().toISOString(),
      title: 'Viewed Property',
      description: 'Viewed details of 123 Main Street, Beverly Hills',
      metadata: {
        duration: '5 minutes'
      }
    },
    {
      type: 'call',
      date: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(),
      title: 'Phone Call',
      description: 'Discussed property requirements and budget constraints',
      metadata: {
        duration: '15 minutes'
      }
    },
    {
      type: 'email',
      date: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
      title: 'Email Sent',
      description: 'Sent property listings matching requirements',
      metadata: {
        status: 'Opened • 2 clicks'
      }
    },
    {
      type: 'registration',
      date: new Date(lead.registrationDate).toISOString(),
      title: 'Lead Registration',
      description: 'Registered through website contact form',
      metadata: {
        source: lead.source.type
      }
    }
  ];

  return (
    <div className="bg-dark-800 rounded-lg border border-dark-700 p-6">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-semibold text-gray-100">Activity Timeline</h3>
        <div className="flex gap-2">
          <select className="bg-dark-700 border border-dark-600 rounded-lg text-sm text-gray-200 px-3 py-2">
            <option value="all">All Activities</option>
            <option value="property">Property Views</option>
            <option value="communication">Communications</option>
            <option value="documents">Documents</option>
          </select>
        </div>
      </div>

      <div className="relative">
        <div className="absolute top-0 bottom-0 left-4 w-px bg-dark-600"></div>
        
        <div className="space-y-6">
          {/* Today */}
          <div className="relative pl-10">
            <div className="absolute left-0 w-8 h-8 rounded-full bg-primary-500/10 flex items-center justify-center">
              <Eye className="w-4 h-4 text-primary-400" />
            </div>
            <div className="bg-dark-700/50 rounded-lg p-4">
              <div className="flex items-center justify-between mb-2">
                <span className="font-medium text-gray-200">Viewed Property</span>
                <span className="text-sm text-gray-400">2 hours ago</span>
              </div>
              <p className="text-sm text-gray-400">
                Viewed details of 123 Main Street, Beverly Hills
              </p>
              <div className="mt-2 text-xs text-gray-500">
                Spent 5 minutes on listing
              </div>
            </div>
          </div>

          {/* Yesterday */}
          <div className="relative pl-10">
            <div className="absolute left-0 w-8 h-8 rounded-full bg-blue-500/10 flex items-center justify-center">
              <Phone className="w-4 h-4 text-blue-400" />
            </div>
            <div className="bg-dark-700/50 rounded-lg p-4">
              <div className="flex items-center justify-between mb-2">
                <span className="font-medium text-gray-200">Phone Call</span>
                <span className="text-sm text-gray-400">Yesterday at 2:30 PM</span>
              </div>
              <p className="text-sm text-gray-400">
                Discussed property requirements and budget constraints
              </p>
              <div className="mt-2 text-xs text-gray-500">
                Duration: 15 minutes
              </div>
            </div>
          </div>

          {/* Registration */}
          <div className="relative pl-10">
            <div className="absolute left-0 w-8 h-8 rounded-full bg-green-500/10 flex items-center justify-center">
              <Calendar className="w-4 h-4 text-green-400" />
            </div>
            <div className="bg-dark-700/50 rounded-lg p-4">
              <div className="flex items-center justify-between mb-2">
                <span className="font-medium text-gray-200">Lead Registration</span>
                <span className="text-sm text-gray-400">
                  {format(new Date(lead.registrationDate), 'MMM dd, yyyy')}
                </span>
              </div>
              <p className="text-sm text-gray-400">
                Registered through website contact form
              </p>
              <div className="mt-2 text-xs text-gray-500">
                Source: {lead.source.type}
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="mt-6 text-center">
        <button 
          onClick={() => setShowFullTimeline(true)}
          className="text-primary-400 hover:text-primary-300 text-sm"
        >
          View Full Timeline
        </button>
      </div>

      {showFullTimeline && (
        <ViewFullTimelineModal
          onClose={() => setShowFullTimeline(false)}
          activities={mockActivities}
        />
      )}
    </div>
  );
}