import React from 'react';
import { Home, MapPin, DollarSign, Bed, Bath, Square, Plus, ExternalLink } from 'lucide-react';

interface PropertyMatchesProps {
  lead: any;
}

export default function PropertyMatches({ lead }: PropertyMatchesProps) {
  return (
    <div className="bg-dark-800 rounded-lg border border-dark-700 p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-semibold text-gray-100">Property Matches</h3>
          <p className="text-sm text-gray-400 mt-1">Based on lead preferences</p>
        </div>
        <button className="btn-secondary flex items-center gap-2">
          <Plus className="w-4 h-4" />
          Add Property
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Example Property Card */}
        <div className="bg-dark-700/50 rounded-lg overflow-hidden">
          <div className="aspect-video bg-dark-600 relative">
            <img
              src="https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
              alt="Property"
              className="w-full h-full object-cover"
            />
            <div className="absolute top-2 right-2">
              <span className="px-2 py-1 bg-green-500 text-white text-xs rounded-full">
                New Listing
              </span>
            </div>
          </div>
          <div className="p-4">
            <div className="flex items-start justify-between mb-2">
              <h4 className="font-medium text-gray-200">123 Main Street</h4>
              <span className="text-primary-400 font-semibold">$1.2M</span>
            </div>
            <div className="flex items-center gap-2 text-sm text-gray-400 mb-3">
              <MapPin className="w-4 h-4" />
              <span>Beverly Hills, CA</span>
            </div>
            <div className="grid grid-cols-3 gap-2 mb-4">
              <div className="flex items-center gap-1 text-sm text-gray-400">
                <Bed className="w-4 h-4" />
                <span>4 beds</span>
              </div>
              <div className="flex items-center gap-1 text-sm text-gray-400">
                <Bath className="w-4 h-4" />
                <span>3 baths</span>
              </div>
              <div className="flex items-center gap-1 text-sm text-gray-400">
                <Square className="w-4 h-4" />
                <span>2,500 sqft</span>
              </div>
            </div>
            <div className="flex items-center justify-between">
              <button className="text-sm text-primary-400 hover:text-primary-300 flex items-center gap-1">
                <ExternalLink className="w-4 h-4" />
                View Details
              </button>
              <button className="text-sm text-primary-400 hover:text-primary-300">
                Share with Lead
              </button>
            </div>
          </div>
        </div>

        {/* Add more property cards here */}
      </div>

      <div className="mt-6 text-center">
        <button className="text-primary-400 hover:text-primary-300 text-sm">
          View All Matches
        </button>
      </div>
    </div>
  );
}