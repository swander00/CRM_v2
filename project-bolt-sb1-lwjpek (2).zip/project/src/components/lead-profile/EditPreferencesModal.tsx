import React, { useState } from 'react';
import { X, DollarSign, MapPin, Home, Calendar } from 'lucide-react';
import Select from 'react-select';

interface EditPreferencesModalProps {
  lead: any;
  onClose: () => void;
  onSave: (preferences: any) => void;
}

const customSelectStyles = {
  control: (base: any) => ({
    ...base,
    background: '#1F2937',
    borderColor: '#374151',
    '&:hover': {
      borderColor: '#4B5563'
    }
  }),
  menu: (base: any) => ({
    ...base,
    background: '#1F2937',
    border: '1px solid #374151'
  }),
  option: (base: any, state: { isSelected: boolean; isFocused: boolean }) => ({
    ...base,
    backgroundColor: state.isSelected ? '#3B82F6' : state.isFocused ? '#374151' : undefined,
    color: '#E5E7EB'
  }),
  input: (base: any) => ({
    ...base,
    color: '#E5E7EB'
  })
};

const propertyTypeOptions = [
  { value: 'single-family', label: 'Single Family Home' },
  { value: 'condo', label: 'Condo' },
  { value: 'townhouse', label: 'Townhouse' },
  { value: 'multi-family', label: 'Multi-Family' },
  { value: 'luxury', label: 'Luxury Property' }
];

const timelineOptions = [
  { value: 'immediate', label: 'Immediate' },
  { value: '1-3-months', label: '1-3 Months' },
  { value: '3-6-months', label: '3-6 Months' },
  { value: '6-plus-months', label: '6+ Months' }
];

export default function EditPreferencesModal({ lead, onClose, onSave }: EditPreferencesModalProps) {
  const [preferences, setPreferences] = useState({
    priceRange: {
      min: lead.price.minBuy,
      max: lead.price.maxBuy
    },
    location: lead.source.location,
    propertyType: {
      value: lead.propertyPreferences.type.toLowerCase(),
      label: lead.propertyPreferences.type
    },
    bedrooms: lead.propertyPreferences.bedrooms,
    bathrooms: lead.propertyPreferences.bathrooms,
    squareFootage: lead.propertyPreferences.squareFootage,
    lotSize: lead.propertyPreferences.lotSize || '',
    timeline: {
      value: lead.timeline.urgency.replace(/\s/g, '-'),
      label: lead.timeline.urgency
    }
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({
      price: {
        ...lead.price,
        minBuy: preferences.priceRange.min,
        maxBuy: preferences.priceRange.max
      },
      source: {
        ...lead.source,
        location: preferences.location
      },
      propertyPreferences: {
        type: preferences.propertyType.label,
        bedrooms: preferences.bedrooms,
        bathrooms: preferences.bathrooms,
        squareFootage: preferences.squareFootage,
        lotSize: preferences.lotSize
      },
      timeline: {
        ...lead.timeline,
        urgency: preferences.timeline.label
      }
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-dark-800 rounded-lg w-full max-w-2xl max-h-[90vh] overflow-hidden">
        <div className="flex items-center justify-between p-6 border-b border-dark-700">
          <h3 className="text-lg font-semibold text-gray-100">Edit Property Preferences</h3>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-300"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 overflow-y-auto max-h-[calc(90vh-140px)]">
          <div className="space-y-6">
            {/* Price Range */}
            <div>
              <label className="block text-sm font-medium text-gray-400 mb-2">
                Price Range
              </label>
              <div className="grid grid-cols-2 gap-4">
                <div className="relative">
                  <DollarSign className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                  <input
                    type="text"
                    value={preferences.priceRange.min}
                    onChange={(e) => setPreferences({
                      ...preferences,
                      priceRange: { ...preferences.priceRange, min: e.target.value }
                    })}
                    className="w-full pl-10 pr-4 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200"
                    placeholder="Min Price"
                  />
                </div>
                <div className="relative">
                  <DollarSign className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                  <input
                    type="text"
                    value={preferences.priceRange.max}
                    onChange={(e) => setPreferences({
                      ...preferences,
                      priceRange: { ...preferences.priceRange, max: e.target.value }
                    })}
                    className="w-full pl-10 pr-4 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200"
                    placeholder="Max Price"
                  />
                </div>
              </div>
            </div>

            {/* Location */}
            <div>
              <label className="block text-sm font-medium text-gray-400 mb-2">
                Preferred Location
              </label>
              <div className="relative">
                <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                <input
                  type="text"
                  value={preferences.location}
                  onChange={(e) => setPreferences({ ...preferences, location: e.target.value })}
                  className="w-full pl-10 pr-4 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200"
                  placeholder="Enter location"
                />
              </div>
            </div>

            {/* Property Type */}
            <div>
              <label className="block text-sm font-medium text-gray-400 mb-2">
                Property Type
              </label>
              <Select
                value={preferences.propertyType}
                onChange={(option) => setPreferences({ ...preferences, propertyType: option })}
                options={propertyTypeOptions}
                styles={customSelectStyles}
              />
            </div>

            {/* Property Details */}
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-400 mb-2">
                  Bedrooms
                </label>
                <select
                  value={preferences.bedrooms}
                  onChange={(e) => setPreferences({ ...preferences, bedrooms: parseInt(e.target.value) })}
                  className="w-full px-4 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200"
                >
                  {[1, 2, 3, 4, 5, 6].map(num => (
                    <option key={num} value={num}>{num}+ beds</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-400 mb-2">
                  Bathrooms
                </label>
                <select
                  value={preferences.bathrooms}
                  onChange={(e) => setPreferences({ ...preferences, bathrooms: parseFloat(e.target.value) })}
                  className="w-full px-4 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200"
                >
                  {[1, 1.5, 2, 2.5, 3, 3.5, 4].map(num => (
                    <option key={num} value={num}>{num}+ baths</option>
                  ))}
                </select>
              </div>
            </div>

            {/* Square Footage & Lot Size */}
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-400 mb-2">
                  Square Footage
                </label>
                <input
                  type="text"
                  value={preferences.squareFootage}
                  onChange={(e) => setPreferences({ ...preferences, squareFootage: e.target.value })}
                  className="w-full px-4 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200"
                  placeholder="Enter square footage"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-400 mb-2">
                  Lot Size
                </label>
                <input
                  type="text"
                  value={preferences.lotSize}
                  onChange={(e) => setPreferences({ ...preferences, lotSize: e.target.value })}
                  className="w-full px-4 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200"
                  placeholder="Enter lot size"
                />
              </div>
            </div>

            {/* Timeline */}
            <div>
              <label className="block text-sm font-medium text-gray-400 mb-2">
                Timeline
              </label>
              <Select
                value={preferences.timeline}
                onChange={(option) => setPreferences({ ...preferences, timeline: option })}
                options={timelineOptions}
                styles={customSelectStyles}
              />
            </div>
          </div>

          <div className="flex justify-end gap-3 mt-6 pt-6 border-t border-dark-700">
            <button
              type="button"
              onClick={onClose}
              className="btn-secondary"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="btn-primary"
            >
              Save Changes
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}