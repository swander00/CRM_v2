import React from 'react';
import { MapPin, Bed, Bath, Square, Heart } from 'lucide-react';
import { Link } from 'react-router-dom';

const mockListings = [
  {
    id: 1,
    title: 'Modern Luxury Villa',
    address: '123 Beverly Hills Dr, Los Angeles',
    price: '$2,500,000',
    beds: 5,
    baths: 4,
    sqft: '4,500',
    type: 'house',
    image: 'https://images.unsplash.com/photo-1613490493576-7fde63acd811?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 2,
    title: 'Downtown Penthouse',
    address: '456 Main St, Los Angeles',
    price: '$1,800,000',
    beds: 3,
    baths: 2,
    sqft: '2,200',
    type: 'apartment',
    image: 'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 3,
    title: 'Beachfront Villa',
    address: '789 Ocean Drive, Malibu',
    price: '$3,200,000',
    beds: 4,
    baths: 3,
    sqft: '3,800',
    type: 'house',
    image: 'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 4,
    title: 'Modern Condo',
    address: '321 Downtown Ave, Los Angeles',
    price: '$950,000',
    beds: 2,
    baths: 2,
    sqft: '1,500',
    type: 'condo',
    image: 'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 5,
    title: 'Hillside Estate',
    address: '555 Hollywood Hills, Los Angeles',
    price: '$4,500,000',
    beds: 6,
    baths: 5,
    sqft: '6,000',
    type: 'house',
    image: 'https://images.unsplash.com/photo-1600607687644-c7171b42498f?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 6,
    title: 'Urban Loft',
    address: '789 Arts District, Los Angeles',
    price: '$1,200,000',
    beds: 2,
    baths: 2,
    sqft: '1,800',
    type: 'loft',
    image: 'https://images.unsplash.com/photo-1600607687920-4e2a09cf159d?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 7,
    title: 'Coastal Retreat',
    address: '123 Pacific Coast Hwy, Malibu',
    price: '$3,800,000',
    beds: 4,
    baths: 3,
    sqft: '3,500',
    type: 'house',
    image: 'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 8,
    title: 'City View Apartment',
    address: '444 Downtown Blvd, Los Angeles',
    price: '$1,500,000',
    beds: 2,
    baths: 2,
    sqft: '1,700',
    type: 'apartment',
    image: 'https://images.unsplash.com/photo-1600607687644-c7171b42498f?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 9,
    title: 'Mountain Estate',
    address: '888 Canyon Rd, Beverly Hills',
    price: '$5,200,000',
    beds: 7,
    baths: 6,
    sqft: '7,200',
    type: 'house',
    image: 'https://images.unsplash.com/photo-1600607687920-4e2a09cf159d?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 10,
    title: 'Luxury Townhouse',
    address: '777 Wilshire Blvd, Beverly Hills',
    price: '$2,800,000',
    beds: 3,
    baths: 3,
    sqft: '2,800',
    type: 'townhouse',
    image: 'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&w=800&q=80'
  }
];

export default function PropertyGrid() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
      {mockListings.map((listing) => (
        <Link 
          key={listing.id} 
          to={`/property/${listing.id}`}
          className="bg-dark-800 rounded-lg border border-dark-700 overflow-hidden hover:border-dark-600 transition-colors"
        >
          <div className="relative aspect-[4/3]">
            <img
              src={listing.image}
              alt={listing.title}
              className="w-full h-full object-cover"
            />
            <button className="absolute top-3 right-3 p-2 bg-dark-800/80 rounded-full text-gray-400 hover:text-red-400">
              <Heart className="w-5 h-5" />
            </button>
            <div className="absolute bottom-3 left-3 px-2 py-1 bg-primary-500 text-white text-sm rounded-lg">
              For Sale
            </div>
          </div>

          <div className="p-4">
            <div className="flex items-center justify-between mb-2">
              <div className="text-xl font-semibold text-gray-100">{listing.price}</div>
              <span className="text-xs text-gray-400">{listing.type}</span>
            </div>
            
            <h3 className="text-gray-200 font-medium mb-2">{listing.title}</h3>
            
            <div className="flex items-center gap-1 text-gray-400 text-sm mb-3">
              <MapPin className="w-4 h-4" />
              {listing.address}
            </div>

            <div className="flex items-center justify-between pt-3 border-t border-dark-700">
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-1 text-gray-400">
                  <Bed className="w-4 h-4" />
                  <span>{listing.beds}</span>
                </div>
                <div className="flex items-center gap-1 text-gray-400">
                  <Bath className="w-4 h-4" />
                  <span>{listing.baths}</span>
                </div>
                <div className="flex items-center gap-1 text-gray-400">
                  <Square className="w-4 h-4" />
                  <span>{listing.sqft}</span>
                </div>
              </div>
            </div>
          </div>
        </Link>
      ))}
    </div>
  );
}