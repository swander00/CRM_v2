import React, { useState } from 'react';
import { X } from 'lucide-react';
import Select from 'react-select';

interface FilterOptionsProps {
  isOpen: boolean;
  onClose: () => void;
}

const customSelectStyles = {
  control: (base: any) => ({
    ...base,
    background: '#1F2937',
    borderColor: '#374151',
    '&:hover': {
      borderColor: '#4B5563'
    }
  }),
  menu: (base: any) => ({
    ...base,
    background: '#1F2937',
    border: '1px solid #374151'
  }),
  option: (base: any, state: { isSelected: boolean; isFocused: boolean }) => ({
    ...base,
    backgroundColor: state.isSelected ? '#3B82F6' : state.isFocused ? '#374151' : undefined,
    color: '#E5E7EB'
  }),
  input: (base: any) => ({
    ...base,
    color: '#E5E7EB'
  })
};

export default function FilterOptions({ isOpen, onClose }: FilterOptionsProps) {
  const [selectedFilters, setSelectedFilters] = useState<Record<string, any>>({});

  if (!isOpen) return null;

  const filterSections = [
    {
      title: 'Property Details',
      filters: [
        {
          label: 'Property Class',
          options: ['Residential', 'Commercial', 'Industrial', 'Land']
        },
        {
          label: 'Style of Home',
          options: ['1 Story', '2 Stories', '3+ Stories', 'Split Level']
        },
        {
          label: 'Year Built',
          type: 'range',
          min: 1900,
          max: new Date().getFullYear()
        },
        {
          label: 'Lot Size',
          options: ['Under 0.25 acres', '0.25-0.5 acres', '0.5-1 acre', '1+ acres']
        }
      ]
    },
    {
      title: 'Interior Features',
      filters: [
        {
          label: 'Basement',
          options: ['Finished', 'Unfinished', 'Partial', 'None']
        },
        {
          label: 'Heating Type',
          options: ['Forced Air', 'Radiant', 'Heat Pump', 'Electric']
        },
        {
          label: 'Cooling Type',
          options: ['Central Air', 'Window Units', 'Split System', 'None']
        }
      ]
    },
    {
      title: 'Exterior Features',
      filters: [
        {
          label: 'Garage Type',
          options: ['Attached', 'Detached', 'Carport', 'None']
        },
        {
          label: 'Parking Spaces',
          options: ['1', '2', '3', '4+']
        }
      ]
    },
    {
      title: 'Property Status',
      filters: [
        {
          label: 'Listing Type',
          options: ['For Sale', 'For Rent', 'New Construction', 'Foreclosure']
        },
        {
          label: 'Days on Market',
          options: ['1-7 days', '8-14 days', '15-30 days', '30+ days']
        }
      ]
    },
    {
      title: 'Commercial Specific',
      filters: [
        {
          label: 'Zoning',
          options: ['Commercial', 'Mixed Use', 'Industrial', 'Office']
        },
        {
          label: 'Total Area',
          type: 'range',
          min: 0,
          max: 100000,
          step: 1000
        },
        {
          label: 'Gross Income',
          type: 'range',
          min: 0,
          max: 1000000,
          step: 10000
        }
      ]
    }
  ];

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-dark-800 rounded-lg w-full max-w-4xl max-h-[90vh] overflow-hidden">
        <div className="flex items-center justify-between p-6 border-b border-dark-700">
          <h3 className="text-lg font-semibold text-gray-100">Advanced Filters</h3>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-300">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 overflow-y-auto max-h-[calc(90vh-140px)]">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {filterSections.map((section) => (
              <div key={section.title} className="space-y-4">
                <h4 className="text-sm font-medium text-gray-400">{section.title}</h4>
                <div className="space-y-3">
                  {section.filters.map((filter) => (
                    <div key={filter.label}>
                      <label className="block text-sm text-gray-300 mb-1">
                        {filter.label}
                      </label>
                      {filter.type === 'range' ? (
                        <div className="flex items-center gap-2">
                          <input
                            type="number"
                            min={filter.min}
                            max={filter.max}
                            step={filter.step}
                            className="w-full bg-dark-700 border border-dark-600 rounded px-3 py-2 text-gray-200"
                          />
                          <span className="text-gray-400">to</span>
                          <input
                            type="number"
                            min={filter.min}
                            max={filter.max}
                            step={filter.step}
                            className="w-full bg-dark-700 border border-dark-600 rounded px-3 py-2 text-gray-200"
                          />
                        </div>
                      ) : (
                        <Select
                          options={filter.options.map(opt => ({ value: opt, label: opt }))}
                          styles={customSelectStyles}
                          placeholder={`Select ${filter.label}`}
                          isClearable
                        />
                      )}
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="flex items-center justify-between p-6 border-t border-dark-700">
          <button className="text-gray-400 hover:text-gray-300">
            Clear All Filters
          </button>
          <div className="flex gap-3">
            <button onClick={onClose} className="btn-secondary">
              Cancel
            </button>
            <button className="btn-primary">
              Apply Filters
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}