import React, { useState, useCallback } from 'react';
import { X, Circle, Square, Trash2 } from 'lucide-react';
import { LoadScript, GoogleMap, DrawingManager } from '@react-google-maps/api';

interface DrawAreaModalProps {
  onClose: () => void;
  onAreaSelect: (area: { type: 'circle' | 'polygon'; coordinates: any; radius?: number }) => void;
}

const GOOGLE_MAPS_API_KEY = import.meta.env.VITE_GOOGLE_MAPS_API_KEY || '';

const mapContainerStyle = {
  width: '100%',
  height: '600px'
};

const center = {
  lat: 34.0522,
  lng: -118.2437
};

const libraries: ("drawing" | "geometry" | "localContext" | "places" | "visualization")[] = ["drawing"];

export default function DrawAreaModal({ onClose, onAreaSelect }: DrawAreaModalProps) {
  const [drawingMode, setDrawingMode] = useState<any>(null);
  const [currentShape, setCurrentShape] = useState<any>(null);
  const [map, setMap] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);

  const onLoad = useCallback((map: any) => {
    setMap(map);
    setIsLoading(false);
  }, []);

  const onLoadError = (error: Error) => {
    console.error('Failed to load Google Maps:', error);
    setIsLoading(false);
  };

  const onDrawingComplete = (shape: any) => {
    if (currentShape) {
      currentShape.setMap(null);
    }
    setCurrentShape(shape);
    setDrawingMode(null);
  };

  const clearShape = () => {
    if (currentShape) {
      currentShape.setMap(null);
      setCurrentShape(null);
    }
  };

  const handleSave = () => {
    if (!currentShape) return;

    if ('getCenter' in currentShape && typeof currentShape.getCenter === 'function') {
      const center = currentShape.getCenter();
      const radius = currentShape.getRadius();
      onAreaSelect({
        type: 'circle',
        coordinates: { lat: center?.lat(), lng: center?.lng() },
        radius
      });
    } else if ('getPath' in currentShape && typeof currentShape.getPath === 'function') {
      const path = currentShape.getPath();
      const coordinates = Array.from({ length: path.getLength() }, (_, i) => {
        const point = path.getAt(i);
        return [point.lng(), point.lat()];
      });
      onAreaSelect({
        type: 'polygon',
        coordinates
      });
    }
    onClose();
  };

  if (!GOOGLE_MAPS_API_KEY) {
    return (
      <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
        <div className="bg-dark-800 rounded-lg p-6 max-w-md">
          <h3 className="text-lg font-semibold text-gray-100 mb-4">Configuration Error</h3>
          <p className="text-gray-400">Google Maps API key is not configured. Please add your API key to the environment variables.</p>
          <div className="mt-6 flex justify-end">
            <button onClick={onClose} className="btn-secondary">Close</button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-dark-800 rounded-lg w-full max-w-4xl p-6">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold text-gray-100">Draw Search Area</h3>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-300"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex gap-4 mb-4">
          <button
            onClick={() => setDrawingMode('circle')}
            className={`btn-secondary flex items-center gap-2 ${
              drawingMode === 'circle' ? 'bg-primary-500 text-white' : ''
            }`}
          >
            <Circle className="w-4 h-4" />
            Draw Circle
          </button>
          <button
            onClick={() => setDrawingMode('polygon')}
            className={`btn-secondary flex items-center gap-2 ${
              drawingMode === 'polygon' ? 'bg-primary-500 text-white' : ''
            }`}
          >
            <Square className="w-4 h-4" />
            Draw Polygon
          </button>
          {currentShape && (
            <button
              onClick={clearShape}
              className="btn-secondary flex items-center gap-2 text-red-400 hover:text-red-300"
            >
              <Trash2 className="w-4 h-4" />
              Clear
            </button>
          )}
        </div>

        <div className="rounded-lg overflow-hidden mb-6 relative">
          {isLoading && (
            <div className="absolute inset-0 bg-dark-700 flex items-center justify-center">
              <div className="text-gray-400">Loading map...</div>
            </div>
          )}
          <LoadScript
            googleMapsApiKey={GOOGLE_MAPS_API_KEY}
            libraries={libraries}
            onError={onLoadError}
          >
            <GoogleMap
              mapContainerStyle={mapContainerStyle}
              center={center}
              zoom={12}
              onLoad={onLoad}
              options={{
                styles: [
                  {
                    featureType: 'all',
                    elementType: 'all',
                    stylers: [{ saturation: -100 }]
                  }
                ]
              }}
            >
              {map && (
                <DrawingManager
                  onLoad={(drawingManager) => {
                    console.log('DrawingManager loaded');
                  }}
                  drawingMode={drawingMode}
                  options={{
                    drawingControl: false,
                    polygonOptions: {
                      fillColor: '#1563df',
                      fillOpacity: 0.2,
                      strokeColor: '#1563df',
                      strokeWeight: 2,
                      clickable: true,
                      editable: true,
                      draggable: true,
                      zIndex: 1
                    },
                    circleOptions: {
                      fillColor: '#1563df',
                      fillOpacity: 0.2,
                      strokeColor: '#1563df',
                      strokeWeight: 2,
                      clickable: true,
                      editable: true,
                      draggable: true,
                      zIndex: 1
                    }
                  }}
                  onCircleComplete={(circle) => onDrawingComplete(circle)}
                  onPolygonComplete={(polygon) => onDrawingComplete(polygon)}
                />
              )}
            </GoogleMap>
          </LoadScript>
        </div>

        <div className="flex justify-end gap-3">
          <button onClick={onClose} className="btn-secondary">
            Cancel
          </button>
          <button
            onClick={handleSave}
            className="btn-primary"
            disabled={!currentShape}
          >
            Apply Area Filter
          </button>
        </div>
      </div>
    </div>
  );
}