import React from 'react';

interface PropertyTypeButtonsProps {
  selectedType: string;
  onTypeSelect: (type: string) => void;
}

const propertyTypes = [
  { id: 'all', label: 'All' },
  { id: 'detached', label: 'Detached' },
  { id: 'semi-detached', label: 'Semi Detached' },
  { id: 'townhouse', label: 'Townhouse' },
  { id: 'condo', label: 'Condo' },
  { id: 'commercial', label: 'Commercial' }
];

export default function PropertyTypeButtons({ selectedType, onTypeSelect }: PropertyTypeButtonsProps) {
  return (
    <div className="flex flex-wrap gap-3">
      {propertyTypes.map((type) => (
        <button
          key={type.id}
          onClick={() => onTypeSelect(type.id)}
          className={`px-6 py-2 rounded-full transition-colors ${
            selectedType === type.id
              ? 'bg-primary-500 text-white'
              : 'bg-dark-800 text-gray-400 hover:bg-dark-700 border border-dark-700'
          }`}
        >
          {type.label}
        </button>
      ))}
    </div>
  );
}