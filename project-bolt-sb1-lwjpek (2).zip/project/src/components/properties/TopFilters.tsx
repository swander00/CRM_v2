import React, { useState } from 'react';
import { Search, MapPin, DollarSign, Filter, ChevronDown } from 'lucide-react';
import DrawAreaModal from './DrawAreaModal';

interface TopFiltersProps {
  onFilterClick: () => void;
}

export default function TopFilters({ onFilterClick }: TopFiltersProps) {
  const [showDrawArea, setShowDrawArea] = useState(false);

  const handleAreaSelect = (area: { type: 'circle' | 'polygon'; coordinates: any; radius?: number }) => {
    // Handle the selected area - you can pass this up to a parent component
    console.log('Selected area:', area);
  };

  return (
    <div className="space-y-4">
      {/* Main Search Bar */}
      <div className="flex gap-3">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
          <input
            type="text"
            placeholder="Search by address, neighborhood, city, or ZIP code..."
            className="w-full pl-10 pr-4 py-2.5 bg-dark-800 border border-dark-700 text-gray-200 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
          />
        </div>
        <button
          onClick={() => setShowDrawArea(true)}
          className="btn-secondary flex items-center gap-2"
        >
          <MapPin className="w-4 h-4" />
          Draw Area
        </button>
      </div>

      {/* Quick Filters */}
      <div className="flex flex-wrap gap-3">
        {/* Price Range */}
        <div className="relative min-w-[200px]">
          <DollarSign className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <select className="w-full pl-9 pr-4 py-2 bg-dark-800 border border-dark-700 rounded-lg text-gray-200 appearance-none">
            <option>Any Price</option>
            <option>$0 - $250k</option>
            <option>$250k - $500k</option>
            <option>$500k - $750k</option>
            <option>$750k - $1M</option>
            <option>$1M+</option>
          </select>
          <ChevronDown className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
        </div>

        {/* Property Type */}
        <select className="min-w-[150px] px-4 py-2 bg-dark-800 border border-dark-700 rounded-lg text-gray-200">
          <option>All Types</option>
          <option>Single Family</option>
          <option>Condo</option>
          <option>Townhouse</option>
          <option>Multi-Family</option>
          <option>Commercial</option>
        </select>

        {/* Beds */}
        <select className="min-w-[100px] px-4 py-2 bg-dark-800 border border-dark-700 rounded-lg text-gray-200">
          <option>Beds</option>
          <option>1+</option>
          <option>2+</option>
          <option>3+</option>
          <option>4+</option>
          <option>5+</option>
        </select>

        {/* Baths */}
        <select className="min-w-[100px] px-4 py-2 bg-dark-800 border border-dark-700 rounded-lg text-gray-200">
          <option>Baths</option>
          <option>1+</option>
          <option>1.5+</option>
          <option>2+</option>
          <option>3+</option>
          <option>4+</option>
        </select>

        {/* Square Footage */}
        <select className="min-w-[150px] px-4 py-2 bg-dark-800 border border-dark-700 rounded-lg text-gray-200">
          <option>Any Size</option>
          <option>Under 1,000 sqft</option>
          <option>1,000 - 2,000 sqft</option>
          <option>2,000 - 3,000 sqft</option>
          <option>3,000+ sqft</option>
        </select>

        {/* More Filters Button */}
        <button
          onClick={onFilterClick}
          className="flex items-center gap-2 px-4 py-2 bg-dark-800 border border-dark-700 rounded-lg text-gray-200 hover:bg-dark-700"
        >
          <Filter className="w-4 h-4" />
          More Filters
          <span className="bg-primary-500 text-white text-xs px-2 py-0.5 rounded-full">12</span>
        </button>
      </div>

      {showDrawArea && (
        <DrawAreaModal
          onClose={() => setShowDrawArea(false)}
          onAreaSelect={handleAreaSelect}
        />
      )}
    </div>
  );
}