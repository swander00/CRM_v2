import React, { useState } from 'react';
import { DragDropContext, Droppable, Draggable, DropResult } from '@hello-pangea/dnd';
import { Home, DollarSign, Calendar, User, MoreHorizontal } from 'lucide-react';

const pipelineStages = [
  { id: 'new-leads', title: 'New Lead', color: 'bg-blue-500/10 text-blue-400 border-blue-500/20' },
  { id: 'contacted', title: 'Tried Contacting', color: 'bg-purple-500/10 text-purple-400 border-purple-500/20' },
  { id: 'qualified', title: 'Qualified', color: 'bg-green-500/10 text-green-400 border-green-500/20' },
  { id: 'warm', title: 'Warm/Nurturing', color: 'bg-yellow-500/10 text-yellow-400 border-yellow-500/20' },
  { id: 'hot', title: 'Hot/Ready', color: 'bg-red-500/10 text-red-400 border-red-500/20' },
  { id: 'showing', title: 'Showing', color: 'bg-pink-500/10 text-pink-400 border-pink-500/20' },
  { id: 'negotiating', title: 'Negotiating', color: 'bg-orange-500/10 text-orange-400 border-orange-500/20' },
  { id: 'pending', title: 'Pending', color: 'bg-indigo-500/10 text-indigo-400 border-indigo-500/20' },
  { id: 'closed', title: 'Closed', color: 'bg-teal-500/10 text-teal-400 border-teal-500/20' }
];

const initialLeads = {
  'new-leads': [
    {
      id: '1',
      title: 'Beverly Hills Mansion',
      client: 'John Smith',
      value: '$2.5M',
      dueDate: '2024-03-01',
      agent: 'Sarah Wilson'
    }
  ],
  'contacted': [
    {
      id: '2',
      title: 'Downtown Penthouse',
      client: 'Emma Davis',
      value: '$1.8M',
      dueDate: '2024-03-15',
      agent: 'Mike Johnson'
    }
  ],
  // Initialize other stages with empty arrays
  'qualified': [],
  'warm': [],
  'hot': [],
  'showing': [],
  'negotiating': [],
  'pending': [],
  'closed': []
};

export default function PipelineBoard() {
  const [leads, setLeads] = useState(initialLeads);

  const onDragEnd = (result: DropResult) => {
    if (!result.destination) return;

    const { source, destination } = result;

    if (source.droppableId === destination.droppableId) {
      const items = Array.from(leads[source.droppableId]);
      const [removed] = items.splice(source.index, 1);
      items.splice(destination.index, 0, removed);

      setLeads({
        ...leads,
        [source.droppableId]: items
      });
    } else {
      const sourceItems = Array.from(leads[source.droppableId]);
      const destItems = Array.from(leads[destination.droppableId]);
      const [removed] = sourceItems.splice(source.index, 1);
      destItems.splice(destination.index, 0, removed);

      setLeads({
        ...leads,
        [source.droppableId]: sourceItems,
        [destination.droppableId]: destItems
      });
    }
  };

  return (
    <div className="h-full overflow-y-auto p-4">
      <DragDropContext onDragEnd={onDragEnd}>
        <div className="space-y-6">
          {pipelineStages.map((stage) => (
            <div key={stage.id} className="bg-dark-800 rounded-lg border border-dark-700 p-4">
              <div className="flex items-center justify-between mb-4">
                <div className={`px-3 py-1 rounded-full text-sm ${stage.color}`}>
                  {stage.title} ({leads[stage.id].length})
                </div>
                <div className="text-sm text-gray-400">
                  ${leads[stage.id].reduce((sum, lead) => sum + parseInt(lead.value.replace(/[^0-9]/g, '')), 0).toLocaleString()}
                </div>
              </div>

              <Droppable droppableId={stage.id} direction="horizontal">
                {(provided) => (
                  <div
                    ref={provided.innerRef}
                    {...provided.droppableProps}
                    className="flex gap-4 overflow-x-auto pb-4"
                  >
                    {leads[stage.id].map((lead, index) => (
                      <Draggable key={lead.id} draggableId={lead.id} index={index}>
                        {(provided) => (
                          <div
                            ref={provided.innerRef}
                            {...provided.draggableProps}
                            {...provided.dragHandleProps}
                            className="bg-dark-700 rounded-lg border border-dark-600 p-4 w-80 flex-shrink-0"
                          >
                            <div className="flex items-center justify-between mb-3">
                              <h4 className="font-medium text-gray-200">{lead.title}</h4>
                              <button className="text-gray-400 hover:text-gray-300">
                                <MoreHorizontal className="w-4 h-4" />
                              </button>
                            </div>

                            <div className="space-y-2">
                              <div className="flex items-center gap-2 text-sm text-gray-400">
                                <User className="w-4 h-4" />
                                <span>{lead.client}</span>
                              </div>
                              <div className="flex items-center gap-2 text-sm text-gray-400">
                                <DollarSign className="w-4 h-4" />
                                <span>{lead.value}</span>
                              </div>
                              <div className="flex items-center gap-2 text-sm text-gray-400">
                                <Calendar className="w-4 h-4" />
                                <span>{lead.dueDate}</span>
                              </div>
                              <div className="flex items-center gap-2 text-sm text-gray-400">
                                <Home className="w-4 h-4" />
                                <span>{lead.agent}</span>
                              </div>
                            </div>
                          </div>
                        )}
                      </Draggable>
                    ))}
                    {provided.placeholder}
                  </div>
                )}
              </Droppable>
            </div>
          ))}
        </div>
      </DragDropContext>
    </div>
  );
}