import React from 'react';
import { DollarSign, TrendingUp, Clock, Users } from 'lucide-react';

export default function PipelineStats() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
      <div className="bg-dark-800 rounded-lg border border-dark-700 p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-gray-400">Total Pipeline Value</p>
            <p className="text-2xl font-semibold text-gray-100 mt-1">$24.5M</p>
          </div>
          <div className="p-3 bg-primary-500/10 rounded-full">
            <DollarSign className="w-6 h-6 text-primary-400" />
          </div>
        </div>
        <div className="mt-4 flex items-center gap-1">
          <TrendingUp className="w-4 h-4 text-green-400" />
          <span className="text-sm text-green-400">12%</span>
          <span className="text-sm text-gray-400 ml-1">vs last month</span>
        </div>
      </div>

      <div className="bg-dark-800 rounded-lg border border-dark-700 p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-gray-400">Active Leads</p>
            <p className="text-2xl font-semibold text-gray-100 mt-1">42</p>
          </div>
          <div className="p-3 bg-blue-500/10 rounded-full">
            <Clock className="w-6 h-6 text-blue-400" />
          </div>
        </div>
        <div className="mt-4 flex items-center gap-1">
          <TrendingUp className="w-4 h-4 text-green-400" />
          <span className="text-sm text-green-400">8</span>
          <span className="text-sm text-gray-400 ml-1">new this month</span>
        </div>
      </div>

      <div className="bg-dark-800 rounded-lg border border-dark-700 p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-gray-400">Win Rate</p>
            <p className="text-2xl font-semibold text-gray-100 mt-1">68%</p>
          </div>
          <div className="p-3 bg-green-500/10 rounded-full">
            <TrendingUp className="w-6 h-6 text-green-400" />
          </div>
        </div>
        <div className="mt-4 flex items-center gap-1">
          <TrendingUp className="w-4 h-4 text-green-400" />
          <span className="text-sm text-green-400">5%</span>
          <span className="text-sm text-gray-400 ml-1">increase</span>
        </div>
      </div>

      <div className="bg-dark-800 rounded-lg border border-dark-700 p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-gray-400">Total Clients</p>
            <p className="text-2xl font-semibold text-gray-100 mt-1">156</p>
          </div>
          <div className="p-3 bg-purple-500/10 rounded-full">
            <Users className="w-6 h-6 text-purple-400" />
          </div>
        </div>
        <div className="mt-4 flex items-center gap-1">
          <TrendingUp className="w-4 h-4 text-green-400" />
          <span className="text-sm text-green-400">15</span>
          <span className="text-sm text-gray-400 ml-1">new this month</span>
        </div>
      </div>
    </div>
  );
}