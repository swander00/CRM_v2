import React from 'react';
import { Search, Filter, Plus, Download, ChevronDown } from 'lucide-react';

export default function PipelineHeader() {
  return (
    <div className="bg-dark-800 border-b border-dark-700 p-4">
      <div className="flex flex-col lg:flex-row gap-4">
        <div className="flex-1">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="text"
              placeholder="Search leads by name, property, or status..."
              className="w-full pl-10 pr-4 py-2.5 bg-dark-700 border border-dark-700 text-gray-200 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent transition-all"
            />
          </div>
        </div>
        
        <div className="flex items-center gap-3">
          <select className="bg-dark-700 border border-dark-700 rounded-lg px-3 py-2 text-gray-200">
            <option>All Agents</option>
            <option>My Leads</option>
            <option>Team Leads</option>
          </select>

          <select className="bg-dark-700 border border-dark-700 rounded-lg px-3 py-2 text-gray-200">
            <option>All Types</option>
            <option>Residential</option>
            <option>Commercial</option>
            <option>Land</option>
          </select>

          <button className="btn-secondary flex items-center gap-2">
            <Filter className="w-4 h-4" />
            More Filters
            <ChevronDown className="w-4 h-4" />
          </button>

          <button className="btn-secondary flex items-center gap-2">
            <Download className="w-4 h-4" />
            Export
          </button>

          <button className="btn-primary flex items-center gap-2">
            <Plus className="w-4 h-4" />
            Add Lead
          </button>
        </div>
      </div>
    </div>
  );
}