import React, { useState } from 'react';
import { X, Calculator, DollarSign, Percent, Calendar } from 'lucide-react';

interface CommissionCalculatorProps {
  onClose: () => void;
}

export default function CommissionCalculator({ onClose }: CommissionCalculatorProps) {
  const [dealValue, setDealValue] = useState('');
  const [commissionRate, setCommissionRate] = useState('');
  const [splitCommission, setSplitCommission] = useState(false);
  const [splitRatio, setSplitRatio] = useState('50');

  const calculateCommission = () => {
    const value = parseFloat(dealValue.replace(/[^0-9.]/g, ''));
    const rate = parseFloat(commissionRate) / 100;
    const totalCommission = value * rate;
    
    if (splitCommission) {
      const ratio = parseFloat(splitRatio) / 100;
      return {
        total: totalCommission,
        yourShare: totalCommission * ratio,
        coAgentShare: totalCommission * (1 - ratio)
      };
    }

    return {
      total: totalCommission,
      yourShare: totalCommission,
      coAgentShare: 0
    };
  };

  const commission = calculateCommission();

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-dark-800 rounded-lg w-full max-w-md p-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <Calculator className="w-6 h-6 text-primary-400" />
            <h3 className="text-lg font-semibold text-gray-100">Commission Calculator</h3>
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-300"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-6">
          {/* Deal Value */}
          <div>
            <label className="block text-sm font-medium text-gray-400 mb-2">
              Deal Value
            </label>
            <div className="relative">
              <DollarSign className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="text"
                value={dealValue}
                onChange={(e) => {
                  const value = e.target.value.replace(/[^0-9.]/g, '');
                  setDealValue(value ? `$${value}` : '');
                }}
                className="w-full pl-10 pr-4 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200"
                placeholder="Enter deal value..."
              />
            </div>
          </div>

          {/* Commission Rate */}
          <div>
            <label className="block text-sm font-medium text-gray-400 mb-2">
              Commission Rate
            </label>
            <div className="relative">
              <Percent className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="number"
                value={commissionRate}
                onChange={(e) => setCommissionRate(e.target.value)}
                className="w-full pl-10 pr-4 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200"
                placeholder="Enter commission rate..."
                step="0.1"
                min="0"
                max="100"
              />
            </div>
          </div>

          {/* Split Commission */}
          <div>
            <label className="flex items-center gap-2 text-sm font-medium text-gray-400 mb-2">
              <input
                type="checkbox"
                checked={splitCommission}
                onChange={(e) => setSplitCommission(e.target.checked)}
                className="rounded border-dark-600"
              />
              Split Commission with Co-Agent
            </label>
            {splitCommission && (
              <div className="mt-2">
                <label className="block text-sm font-medium text-gray-400 mb-2">
                  Your Split Percentage
                </label>
                <input
                  type="range"
                  value={splitRatio}
                  onChange={(e) => setSplitRatio(e.target.value)}
                  className="w-full"
                  min="0"
                  max="100"
                  step="5"
                />
                <div className="flex justify-between text-sm text-gray-400 mt-1">
                  <span>You: {splitRatio}%</span>
                  <span>Co-Agent: {100 - parseFloat(splitRatio)}%</span>
                </div>
              </div>
            )}
          </div>

          {/* Results */}
          <div className="p-4 bg-dark-700/50 rounded-lg space-y-3">
            <div className="flex justify-between">
              <span className="text-sm text-gray-400">Total Commission:</span>
              <span className="text-sm font-medium text-gray-200">
                ${commission.total.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-sm text-gray-400">Your Share:</span>
              <span className="text-sm font-medium text-primary-400">
                ${commission.yourShare.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </span>
            </div>
            {splitCommission && (
              <div className="flex justify-between">
                <span className="text-sm text-gray-400">Co-Agent Share:</span>
                <span className="text-sm font-medium text-gray-200">
                  ${commission.coAgentShare.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </span>
              </div>
            )}
          </div>

          {/* Save Button */}
          <button className="w-full btn-primary">
            Save Calculation
          </button>
        </div>
      </div>
    </div>
  );
}