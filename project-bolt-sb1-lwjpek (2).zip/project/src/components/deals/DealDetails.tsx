import React from 'react';
import { 
  X, 
  DollarSign, 
  Calendar, 
  Users, 
  FileText, 
  MessageSquare, 
  Phone, 
  Mail,
  MapPin,
  Clock,
  ChevronRight,
  Building,
  CheckSquare,
  AlertCircle
} from 'lucide-react';

interface DealDetailsProps {
  deal: any;
  onClose: () => void;
  onMoveToNextStage: () => void;
  currentStage: string;
}

const stageOrder = ['new', 'negotiation', 'contract', 'closing'];

export default function DealDetails({ deal, onClose, onMoveToNextStage, currentStage }: DealDetailsProps) {
  const isLastStage = currentStage === stageOrder[stageOrder.length - 1];
  const nextStageName = stageOrder[stageOrder.indexOf(currentStage) + 1];

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-dark-800 rounded-lg w-full max-w-4xl max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-dark-700">
          <h2 className="text-xl font-semibold text-gray-100">{deal.title}</h2>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-300"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto max-h-[calc(90vh-140px)]">
          <div className="grid grid-cols-3 gap-6">
            {/* Left Column - Main Details */}
            <div className="col-span-2 space-y-6">
              {/* Key Information */}
              <div className="bg-dark-700/50 rounded-lg p-4">
                <h3 className="text-sm font-medium text-gray-400 mb-4">Key Information</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div className="flex items-center gap-2">
                    <DollarSign className="w-4 h-4 text-primary-400" />
                    <div>
                      <div className="text-sm text-gray-400">Deal Value</div>
                      <div className="text-gray-200">{deal.value}</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Building className="w-4 h-4 text-primary-400" />
                    <div>
                      <div className="text-sm text-gray-400">Property Type</div>
                      <div className="text-gray-200">{deal.type}</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Calendar className="w-4 h-4 text-primary-400" />
                    <div>
                      <div className="text-sm text-gray-400">Due Date</div>
                      <div className="text-gray-200">{deal.dueDate}</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Users className="w-4 h-4 text-primary-400" />
                    <div>
                      <div className="text-sm text-gray-400">Assigned Agent</div>
                      <div className="text-gray-200">{deal.agent}</div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Tasks */}
              <div className="bg-dark-700/50 rounded-lg p-4">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-sm font-medium text-gray-400">Tasks</h3>
                  <button className="text-primary-400 hover:text-primary-300 text-sm">Add Task</button>
                </div>
                <div className="space-y-3">
                  <div className="flex items-center justify-between p-2 bg-dark-700 rounded-lg">
                    <div className="flex items-center gap-2">
                      <CheckSquare className="w-4 h-4 text-green-400" />
                      <span className="text-gray-200">Review contract documents</span>
                    </div>
                    <span className="text-sm text-gray-400">Due Today</span>
                  </div>
                  <div className="flex items-center justify-between p-2 bg-dark-700 rounded-lg">
                    <div className="flex items-center gap-2">
                      <AlertCircle className="w-4 h-4 text-yellow-400" />
                      <span className="text-gray-200">Schedule property inspection</span>
                    </div>
                    <span className="text-sm text-gray-400">Tomorrow</span>
                  </div>
                </div>
              </div>

              {/* Documents */}
              <div className="bg-dark-700/50 rounded-lg p-4">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-sm font-medium text-gray-400">Documents</h3>
                  <button className="text-primary-400 hover:text-primary-300 text-sm">Upload</button>
                </div>
                <div className="space-y-2">
                  {Array.from({ length: deal.documents }).map((_, i) => (
                    <div key={i} className="flex items-center justify-between p-2 bg-dark-700 rounded-lg">
                      <div className="flex items-center gap-2">
                        <FileText className="w-4 h-4 text-primary-400" />
                        <span className="text-gray-200">Document {i + 1}</span>
                      </div>
                      <button className="text-gray-400 hover:text-gray-300">
                        <ChevronRight className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Right Column - Client & Communication */}
            <div className="space-y-6">
              {/* Client Information */}
              <div className="bg-dark-700/50 rounded-lg p-4">
                <h3 className="text-sm font-medium text-gray-400 mb-4">Client Information</h3>
                <div className="space-y-3">
                  <div className="flex items-center gap-2">
                    <Users className="w-4 h-4 text-primary-400" />
                    <span className="text-gray-200">{deal.client}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Phone className="w-4 h-4 text-primary-400" />
                    <span className="text-gray-200">+1 (555) 123-4567</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Mail className="w-4 h-4 text-primary-400" />
                    <span className="text-gray-200">client@example.com</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <MapPin className="w-4 h-4 text-primary-400" />
                    <span className="text-gray-200">Los Angeles, CA</span>
                  </div>
                </div>
              </div>

              {/* Recent Communications */}
              <div className="bg-dark-700/50 rounded-lg p-4">
                <h3 className="text-sm font-medium text-gray-400 mb-4">Recent Communications</h3>
                <div className="space-y-3">
                  <div className="flex items-start gap-3">
                    <Phone className="w-4 h-4 text-primary-400 mt-1" />
                    <div>
                      <div className="text-gray-200">Phone Call</div>
                      <div className="text-sm text-gray-400">Yesterday at 2:30 PM</div>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <Mail className="w-4 h-4 text-primary-400 mt-1" />
                    <div>
                      <div className="text-gray-200">Email Sent</div>
                      <div className="text-sm text-gray-400">2 days ago</div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Timeline */}
              <div className="bg-dark-700/50 rounded-lg p-4">
                <h3 className="text-sm font-medium text-gray-400 mb-4">Timeline</h3>
                <div className="space-y-4">
                  <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4 text-primary-400" />
                    <div className="text-sm">
                      <span className="text-gray-400">Created: </span>
                      <span className="text-gray-200">Jan 15, 2024</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4 text-primary-400" />
                    <div className="text-sm">
                      <span className="text-gray-400">Last Updated: </span>
                      <span className="text-gray-200">2 days ago</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="flex items-center justify-between p-6 border-t border-dark-700">
          <div className="flex items-center gap-2">
            <div className="px-3 py-1 rounded-full text-sm bg-primary-500/10 text-primary-400">
              Current Stage: {currentStage}
            </div>
          </div>
          <div className="flex items-center gap-3">
            <button className="btn-secondary">
              Edit Deal
            </button>
            {!isLastStage && (
              <button 
                onClick={onMoveToNextStage}
                className="btn-primary flex items-center gap-2"
              >
                Move to {nextStageName}
                <ChevronRight className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}