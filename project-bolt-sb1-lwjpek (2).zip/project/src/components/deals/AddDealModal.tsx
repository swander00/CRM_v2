import React, { useState, useEffect } from 'react';
import { X, DollarSign, Users, Calendar, Building2, MapPin, FileText, Calculator } from 'lucide-react';
import Select from 'react-select';

interface AddDealModalProps {
  onClose: () => void;
  onAdd: (deal: any) => void;
}

const dealTypes = [
  { value: 'residential', label: 'Residential Sale' },
  { value: 'commercial', label: 'Commercial Sale' },
  { value: 'rental', label: 'Rental' },
  { value: 'land', label: 'Land' },
  { value: 'development', label: 'Development Project' }
];

const customSelectStyles = {
  control: (base: any) => ({
    ...base,
    background: '#1F2937',
    borderColor: '#374151',
    '&:hover': {
      borderColor: '#4B5563'
    }
  }),
  menu: (base: any) => ({
    ...base,
    background: '#1F2937',
    border: '1px solid #374151'
  }),
  option: (base: any, state: { isSelected: boolean; isFocused: boolean }) => ({
    ...base,
    backgroundColor: state.isSelected ? '#3B82F6' : state.isFocused ? '#374151' : undefined,
    color: '#E5E7EB'
  }),
  singleValue: (base: any) => ({
    ...base,
    color: '#E5E7EB'
  }),
  input: (base: any) => ({
    ...base,
    color: '#E5E7EB'
  })
};

export default function AddDealModal({ onClose, onAdd }: AddDealModalProps) {
  const [dealData, setDealData] = useState({
    title: '',
    type: null,
    client: '',
    value: '',
    commission: '',
    commissionAmount: '0',
    dueDate: '',
    location: '',
    description: '',
    agent: '',
    stage: 'new'
  });

  const [showCommissionCalculator, setShowCommissionCalculator] = useState(false);

  // Calculate commission amount whenever deal value or commission rate changes
  useEffect(() => {
    if (dealData.value && dealData.commission) {
      const value = parseFloat(dealData.value.replace(/[^0-9.]/g, ''));
      const rate = parseFloat(dealData.commission) / 100;
      const amount = value * rate;
      setDealData(prev => ({
        ...prev,
        commissionAmount: amount.toLocaleString('en-US', {
          style: 'currency',
          currency: 'USD'
        })
      }));
    }
  }, [dealData.value, dealData.commission]);

  const handleValueChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value.replace(/[^0-9.]/g, '');
    const formattedValue = value ? new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(parseFloat(value)) : '';

    setDealData(prev => ({
      ...prev,
      value: formattedValue
    }));
  };

  const handleCommissionChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value.replace(/[^0-9.]/g, '');
    if (parseFloat(value) <= 100) {
      setDealData(prev => ({
        ...prev,
        commission: value
      }));
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onAdd({
      ...dealData,
      id: Date.now().toString(),
      documents: 0,
      messages: 0
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-dark-800 rounded-lg w-full max-w-3xl max-h-[90vh] overflow-hidden">
        <div className="flex items-center justify-between p-6 border-b border-dark-700">
          <h3 className="text-lg font-semibold text-gray-100">Add New Deal</h3>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-300"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 overflow-y-auto max-h-[calc(90vh-130px)]">
          <div className="space-y-6">
            {/* Basic Information */}
            <div className="grid grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-400 mb-2">
                  Deal Title
                </label>
                <input
                  type="text"
                  value={dealData.title}
                  onChange={(e) => setDealData({ ...dealData, title: e.target.value })}
                  className="w-full px-4 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200"
                  placeholder="e.g., 123 Main Street Sale"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-400 mb-2">
                  Deal Type
                </label>
                <Select
                  options={dealTypes}
                  value={dealTypes.find(type => type.value === dealData.type)}
                  onChange={(option) => setDealData({ ...dealData, type: option?.value })}
                  styles={customSelectStyles}
                  placeholder="Select deal type..."
                  required
                />
              </div>
            </div>

            {/* Client & Value */}
            <div className="grid grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-400 mb-2">
                  Client Name
                </label>
                <div className="relative">
                  <Users className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                  <input
                    type="text"
                    value={dealData.client}
                    onChange={(e) => setDealData({ ...dealData, client: e.target.value })}
                    className="w-full pl-10 pr-4 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200"
                    placeholder="Enter client name..."
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-400 mb-2">
                  Deal Value
                </label>
                <div className="relative">
                  <DollarSign className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                  <input
                    type="text"
                    value={dealData.value}
                    onChange={handleValueChange}
                    className="w-full pl-10 pr-4 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200"
                    placeholder="Enter deal value..."
                    required
                  />
                </div>
              </div>
            </div>

            {/* Commission & Due Date */}
            <div className="grid grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-400 mb-2">
                  Commission Rate & Amount
                </label>
                <div className="space-y-2">
                  <div className="flex gap-2">
                    <div className="relative flex-1">
                      <input
                        type="text"
                        value={dealData.commission}
                        onChange={handleCommissionChange}
                        className="w-full pl-4 pr-8 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200"
                        placeholder="Enter rate..."
                        required
                      />
                      <span className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400">%</span>
                    </div>
                  </div>
                  {dealData.commissionAmount !== '0' && (
                    <div className="p-3 bg-primary-500/10 rounded-lg">
                      <div className="text-sm text-gray-400">Commission Amount:</div>
                      <div className="text-lg font-semibold text-primary-400">
                        {dealData.commissionAmount}
                      </div>
                    </div>
                  )}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-400 mb-2">
                  Due Date
                </label>
                <div className="relative">
                  <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                  <input
                    type="date"
                    value={dealData.dueDate}
                    onChange={(e) => setDealData({ ...dealData, dueDate: e.target.value })}
                    className="w-full pl-10 pr-4 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200"
                    required
                  />
                </div>
              </div>
            </div>

            {/* Location & Agent */}
            <div className="grid grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-400 mb-2">
                  Location
                </label>
                <div className="relative">
                  <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                  <input
                    type="text"
                    value={dealData.location}
                    onChange={(e) => setDealData({ ...dealData, location: e.target.value })}
                    className="w-full pl-10 pr-4 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200"
                    placeholder="Enter property location..."
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-400 mb-2">
                  Assigned Agent
                </label>
                <div className="relative">
                  <Users className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                  <input
                    type="text"
                    value={dealData.agent}
                    onChange={(e) => setDealData({ ...dealData, agent: e.target.value })}
                    className="w-full pl-10 pr-4 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200"
                    placeholder="Enter agent name..."
                    required
                  />
                </div>
              </div>
            </div>

            {/* Description */}
            <div>
              <label className="block text-sm font-medium text-gray-400 mb-2">
                Description
              </label>
              <div className="relative">
                <FileText className="absolute left-3 top-3 text-gray-400 w-5 h-5" />
                <textarea
                  value={dealData.description}
                  onChange={(e) => setDealData({ ...dealData, description: e.target.value })}
                  className="w-full pl-10 pr-4 py-2 bg-dark-700 border border-dark-600 rounded-lg text-gray-200 resize-none"
                  placeholder="Enter deal description..."
                  rows={4}
                />
              </div>
            </div>
          </div>

          <div className="flex justify-end gap-3 mt-6 pt-6 border-t border-dark-700">
            <button
              type="button"
              onClick={onClose}
              className="btn-secondary"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="btn-primary"
            >
              Add Deal
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}