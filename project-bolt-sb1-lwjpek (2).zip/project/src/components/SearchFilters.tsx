import React, { useState } from 'react';
import { Search, Filter, ChevronDown, Save } from 'lucide-react';
import FilterDropdown from './dropdowns/FilterDropdown';
import PipelineDropdown from './dropdowns/PipelineDropdown';
import LeadSourceDropdown from './dropdowns/LeadSourceDropdown';
import LeadTypeDropdown from './dropdowns/LeadTypeDropdown';

export default function SearchFilters() {
  const [showAdvancedFilters, setShowAdvancedFilters] = useState(false);

  return (
    <div className="space-y-4 mb-6">
      <div className="flex flex-col lg:flex-row gap-4">
        <div className="flex-1">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="text"
              placeholder="Search by name, phone, email, or tags..."
              className="w-full pl-10 pr-4 py-2.5 bg-dark-800 border border-dark-700 text-gray-200 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent transition-all"
            />
          </div>
        </div>
        
        <div className="flex flex-wrap gap-3">
          <PipelineDropdown />
          <LeadSourceDropdown />
          <LeadTypeDropdown />

          <button className="btn-secondary flex items-center gap-2">
            <Save className="w-4 h-4" />
            Saved Views
          </button>
          
          <button 
            className="btn-secondary flex items-center gap-2"
            onClick={() => setShowAdvancedFilters(!showAdvancedFilters)}
          >
            <Filter className="w-4 h-4" />
            More Filters
            <ChevronDown className="w-4 h-4" />
          </button>
        </div>
      </div>

      {showAdvancedFilters && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mt-4 p-4 bg-dark-800 rounded-lg border border-dark-700">
          <FilterDropdown
            label="City"
            options={['Toronto', 'Vancouver', 'Montreal', 'Calgary']}
          />
          <FilterDropdown
            label="Price Range"
            options={['$0-$500k', '$500k-$1M', '$1M-$2M', '$2M+']}
          />
          <FilterDropdown
            label="Timeline"
            options={['Immediate', '1-3 months', '3-6 months', '6+ months']}
          />
          <FilterDropdown
            label="Assigned Agent"
            options={['John Doe', 'Jane Smith', 'Mike Johnson']}
          />
          <FilterDropdown
            label="Property Type"
            options={['House', 'Condo', 'Townhouse', 'Land']}
          />
          <FilterDropdown
            label="Bedrooms"
            options={['1', '2', '3', '4+']}
          />
          <FilterDropdown
            label="Bathrooms"
            options={['1', '2', '3', '4+']}
          />
          <FilterDropdown
            label="Task Status"
            options={['Not Started', 'In Progress', 'Completed']}
          />
          <FilterDropdown
            label="Follow-Up Status"
            options={['Due Today', 'Overdue', 'Completed', 'None']}
          />
          <FilterDropdown
            label="Tags"
            options={['VIP', 'Hot Lead', 'First Time Buyer', 'Investor']}
          />
          <FilterDropdown
            label="Registration Date"
            options={['Last 7 days', 'Last 30 days', 'Last 90 days', 'Custom']}
          />
          <FilterDropdown
            label="Square Footage"
            options={['Under 1000', '1000-2000', '2000-3000', '3000+']}
          />
        </div>
      )}
    </div>
  );
}