import React, { useState } from 'react';
import { Plus, UserPlus, Users, Briefcase } from 'lucide-react';
import AddLeadModal from './modals/AddLeadModal';
import AddContactModal from './contacts/modals/AddContactModal';
import AddDealModal from './deals/AddDealModal';

export default function FloatingActionButton() {
  const [isOpen, setIsOpen] = useState(false);
  const [showLeadModal, setShowLeadModal] = useState(false);
  const [showContactModal, setShowContactModal] = useState(false);
  const [showDealModal, setShowDealModal] = useState(false);

  const handleAddLead = (leadData: any) => {
    console.log('New lead:', leadData);
    setShowLeadModal(false);
    setIsOpen(false);
  };

  const handleAddContact = (contactData: any) => {
    console.log('New contact:', contactData);
    setShowContactModal(false);
    setIsOpen(false);
  };

  const handleAddDeal = (dealData: any) => {
    console.log('New deal:', dealData);
    setShowDealModal(false);
    setIsOpen(false);
  };

  const options = [
    {
      icon: UserPlus,
      label: 'New Lead',
      color: 'bg-blue-500 hover:bg-blue-600',
      onClick: () => setShowLeadModal(true)
    },
    {
      icon: Users,
      label: 'New Contact',
      color: 'bg-green-500 hover:bg-green-600',
      onClick: () => setShowContactModal(true)
    },
    {
      icon: Briefcase,
      label: 'New Deal',
      color: 'bg-purple-500 hover:bg-purple-600',
      onClick: () => setShowDealModal(true)
    }
  ];

  return (
    <>
      <div className="fixed bottom-8 right-8 z-50">
        {/* Action Buttons */}
        <div className="relative">
          {/* Option Bubbles */}
          <div className={`absolute bottom-16 right-0 space-y-4 transition-all duration-200 ${
            isOpen ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4 pointer-events-none'
          }`}>
            {options.map((option, index) => {
              const Icon = option.icon;
              return (
                <button
                  key={index}
                  onClick={option.onClick}
                  className={`flex items-center gap-2 px-4 py-2 rounded-full text-white shadow-lg transform transition-all duration-200 ${option.color} ${
                    isOpen ? 'scale-100' : 'scale-0'
                  }`}
                  style={{
                    transitionDelay: `${(options.length - index) * 50}ms`
                  }}
                >
                  <Icon className="w-5 h-5" />
                  <span className="text-sm font-medium">{option.label}</span>
                </button>
              );
            })}
          </div>

          {/* Main Button */}
          <button
            onClick={() => setIsOpen(!isOpen)}
            className={`w-14 h-14 bg-gradient-to-br from-indigo-500 via-purple-500 to-pink-500 rounded-full flex items-center justify-center text-white shadow-lg transition-all duration-200 hover:shadow-xl hover:scale-105 ${
              isOpen ? 'rotate-45' : ''
            }`}
          >
            <Plus className="w-7 h-7" />
          </button>
        </div>
      </div>

      {/* Modals */}
      {showLeadModal && (
        <AddLeadModal
          onClose={() => setShowLeadModal(false)}
          onAdd={handleAddLead}
        />
      )}

      {showContactModal && (
        <AddContactModal
          onClose={() => setShowContactModal(false)}
          onAdd={handleAddContact}
        />
      )}

      {showDealModal && (
        <AddDealModal
          onClose={() => setShowDealModal(false)}
          onAdd={handleAddDeal}
        />
      )}
    </>
  );
}