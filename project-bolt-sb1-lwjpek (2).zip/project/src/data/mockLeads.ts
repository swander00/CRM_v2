import { Lead } from '../types/lead';

export const mockLeads: Lead[] = [
  {
    id: 1,
    name: 'John Smith',
    email: 'john.smith@example.com',
    phone: '+1 (555) 123-4567',
    status: 'Active',
    pipelineStatus: 'warm',
    source: {
      url: 'https://google.com',
      type: 'Google Ads',
      location: 'Beverly Hills'
    },
    price: {
      minBuy: '800K',
      maxBuy: '1.2M',
      buy: 'Yes',
      sell: 'No'
    },
    timeline: {
      date: '2024-01-15T14:30:00',
      time: '2:30 PM',
      intent: 'buying',
      urgency: '1-3 months'
    },
    activity: {
      days: 2,
      calls: 3,
      emails: { total: 5, unread: 2 },
      messages: { total: 8, unread: 1 },
      lastContact: {
        date: '2024-01-14T10:30:00',
        method: 'call'
      }
    },
    tasks: {
      completed: 3,
      total: 5,
      nextTask: {
        type: 'call',
        dueDate: '2024-01-16T15:00:00',
        description: 'Follow up on property viewing',
        priority: 'high'
      }
    },
    assigned: {
      name: 'Sarah Wilson',
      completed: 12
    },
    leadType: 'Luxury Buyer',
    leadScore: 85,
    propertyPreferences: {
      type: 'Detached House',
      bedrooms: 4,
      bathrooms: 3,
      squareFootage: '3000-4000',
      lotSize: '0.5 acres'
    },
    registrationDate: '2024-01-01T09:00:00',
    tags: ['VIP', 'PA', 'LUX']
  },
  {
    id: 2,
    name: 'Emma Davis',
    email: 'emma.davis@example.com',
    phone: '+1 (555) 987-6543',
    status: 'New',
    pipelineStatus: 'new',
    source: {
      url: 'https://facebook.com',
      type: 'Facebook Ads',
      location: 'Manhattan'
    },
    price: {
      minBuy: '500K',
      maxBuy: '750K',
      buy: 'Yes',
      sell: 'No'
    },
    timeline: {
      date: '2024-01-16T10:00:00',
      time: '10:00 AM',
      intent: 'buying',
      urgency: '3-6 months'
    },
    activity: {
      days: 1,
      calls: 1,
      emails: { total: 2, unread: 0 },
      messages: { total: 3, unread: 2 },
      lastContact: {
        date: '2024-01-15T14:30:00',
        method: 'email'
      }
    },
    tasks: {
      completed: 1,
      total: 4,
      nextTask: {
        type: 'email',
        dueDate: '2024-01-17T11:00:00',
        description: 'Send property recommendations',
        priority: 'medium'
      }
    },
    assigned: {
      name: 'Michael Brown',
      completed: 8
    },
    leadType: 'First-Time Buyer',
    leadScore: 65,
    propertyPreferences: {
      type: 'Condo',
      bedrooms: 2,
      bathrooms: 2,
      squareFootage: '1000-1500'
    },
    registrationDate: '2024-01-10T15:30:00',
    tags: ['FTB', 'PQ']
  },
  {
    id: 3,
    name: 'Michael Johnson',
    email: 'michael.j@example.com',
    phone: '+1 (555) 234-5678',
    status: 'Active',
    pipelineStatus: 'hot',
    source: {
      url: 'https://instagram.com',
      type: 'Instagram Ads',
      location: 'Los Angeles'
    },
    price: {
      minBuy: '1.5M',
      maxBuy: '2M',
      buy: 'No',
      sell: 'Yes'
    },
    timeline: {
      date: '2024-01-18T09:00:00',
      time: '9:00 AM',
      intent: 'selling',
      urgency: 'immediate'
    },
    activity: {
      days: 0,
      calls: 5,
      emails: { total: 8, unread: 3 },
      messages: { total: 4, unread: 0 },
      lastContact: {
        date: '2024-01-15T16:45:00',
        method: 'call'
      }
    },
    tasks: {
      completed: 4,
      total: 6,
      nextTask: {
        type: 'meeting',
        dueDate: '2024-01-16T13:00:00',
        description: 'Property valuation meeting',
        priority: 'high'
      }
    },
    assigned: {
      name: 'David Brown',
      completed: 15
    },
    leadType: 'Luxury Seller',
    leadScore: 95,
    propertyPreferences: {
      type: 'Mansion',
      bedrooms: 6,
      bathrooms: 5,
      squareFootage: '6000+',
      lotSize: '1.2 acres'
    },
    registrationDate: '2024-01-05T11:20:00',
    tags: ['LS', 'HOT', 'VIP']
  },
  {
    id: 4,
    name: 'Sarah Wilson',
    email: 'sarah.w@example.com',
    phone: '+1 (555) 345-6789',
    status: 'Active',
    pipelineStatus: 'qualified',
    source: {
      url: 'https://linkedin.com',
      type: 'LinkedIn Ads',
      location: 'San Francisco'
    },
    price: {
      minBuy: '900K',
      maxBuy: '1.1M',
      buy: 'Yes',
      sell: 'No'
    },
    timeline: {
      date: '2024-02-01T11:00:00',
      time: '11:00 AM',
      intent: 'buying',
      urgency: '3-6 months'
    },
    activity: {
      days: 3,
      calls: 2,
      emails: { total: 6, unread: 1 },
      messages: { total: 5, unread: 2 },
      lastContact: {
        date: '2024-01-13T14:20:00',
        method: 'email'
      }
    },
    tasks: {
      completed: 2,
      total: 5,
      nextTask: {
        type: 'call',
        dueDate: '2024-01-17T10:00:00',
        description: 'Discuss mortgage pre-approval',
        priority: 'medium'
      }
    },
    assigned: {
      name: 'Emma Taylor',
      completed: 9
    },
    leadType: 'Move-Up Buyer',
    leadScore: 75,
    propertyPreferences: {
      type: 'Townhouse',
      bedrooms: 3,
      bathrooms: 2.5,
      squareFootage: '2000-2500'
    },
    registrationDate: '2024-01-08T13:45:00',
    tags: ['MUB', 'PQ']
  },
  {
    id: 5,
    name: 'David Brown',
    email: 'david.b@example.com',
    phone: '+1 (555) 456-7890',
    status: 'Active',
    pipelineStatus: 'showing',
    source: {
      url: 'https://referral.com',
      type: 'Referral',
      location: 'Chicago'
    },
    price: {
      minBuy: '400K',
      maxBuy: '600K',
      buy: 'Yes',
      sell: 'No'
    },
    timeline: {
      date: '2024-01-20T15:30:00',
      time: '3:30 PM',
      intent: 'buying',
      urgency: '1-3 months'
    },
    activity: {
      days: 1,
      calls: 4,
      emails: { total: 7, unread: 0 },
      messages: { total: 6, unread: 1 },
      lastContact: {
        date: '2024-01-15T09:15:00',
        method: 'sms'
      }
    },
    tasks: {
      completed: 5,
      total: 7,
      nextTask: {
        type: 'showing',
        dueDate: '2024-01-18T14:00:00',
        description: 'Property showing at 123 Main St',
        priority: 'high'
      }
    },
    assigned: {
      name: 'John Davis',
      completed: 11
    },
    leadType: 'First-Time Buyer',
    leadScore: 80,
    propertyPreferences: {
      type: 'Condo',
      bedrooms: 2,
      bathrooms: 2,
      squareFootage: '1200-1500'
    },
    registrationDate: '2024-01-12T10:30:00',
    tags: ['FTB', 'HOT']
  },
  {
    id: 6,
    name: 'Olivia Taylor',
    email: 'olivia.t@example.com',
    phone: '+1 (555) 567-8901',
    status: 'Active',
    pipelineStatus: 'contacted',
    source: {
      url: 'https://website.com',
      type: 'Website',
      location: 'Miami'
    },
    price: {
      minBuy: '600K',
      maxBuy: '800K',
      buy: 'No',
      sell: 'Yes'
    },
    timeline: {
      date: '2024-02-15T13:00:00',
      time: '1:00 PM',
      intent: 'selling',
      urgency: '3-6 months'
    },
    activity: {
      days: 4,
      calls: 1,
      emails: { total: 3, unread: 1 },
      messages: { total: 2, unread: 0 },
      lastContact: {
        date: '2024-01-12T11:30:00',
        method: 'email'
      }
    },
    tasks: {
      completed: 1,
      total: 4,
      nextTask: {
        type: 'call',
        dueDate: '2024-01-17T09:30:00',
        description: 'Follow up on listing presentation',
        priority: 'medium'
      }
    },
    assigned: {
      name: 'Sarah Wilson',
      completed: 7
    },
    leadType: 'Relocation Seller',
    leadScore: 70,
    propertyPreferences: {
      type: 'Single Family',
      bedrooms: 4,
      bathrooms: 3,
      squareFootage: '2500-3000'
    },
    registrationDate: '2024-01-11T14:15:00',
    tags: ['RS', 'REL']
  },
  {
    id: 7,
    name: 'William Chen',
    email: 'william.c@example.com',
    phone: '+1 (555) 678-9012',
    status: 'Active',
    pipelineStatus: 'warm',
    source: {
      url: 'https://zillow.com',
      type: 'Zillow',
      location: 'Seattle'
    },
    price: {
      minBuy: '700K',
      maxBuy: '900K',
      buy: 'Yes',
      sell: 'No'
    },
    timeline: {
      date: '2024-03-01T10:00:00',
      time: '10:00 AM',
      intent: 'buying',
      urgency: '3-6 months'
    },
    activity: {
      days: 2,
      calls: 3,
      emails: { total: 5, unread: 2 },
      messages: { total: 4, unread: 1 },
      lastContact: {
        date: '2024-01-14T15:45:00',
        method: 'call'
      }
    },
    tasks: {
      completed: 3,
      total: 6,
      nextTask: {
        type: 'email',
        dueDate: '2024-01-17T16:00:00',
        description: 'Send neighborhood market analysis',
        priority: 'low'
      }
    },
    assigned: {
      name: 'Michael Brown',
      completed: 10
    },
    leadType: 'Investor Buyer',
    leadScore: 85,
    propertyPreferences: {
      type: 'Multi-Family',
      bedrooms: 6,
      bathrooms: 4,
      squareFootage: '3500-4000'
    },
    registrationDate: '2024-01-13T09:45:00',
    tags: ['INV', 'PQ', 'HOT']
  },
  {
    id: 8,
    name: 'Isabella Martinez',
    email: 'isabella.m@example.com',
    phone: '+1 (555) 789-0123',
    status: 'Active',
    pipelineStatus: 'hot',
    source: {
      url: 'https://realtor.com',
      type: 'Realtor.com',
      location: 'Austin'
    },
    price: {
      minBuy: '1M',
      maxBuy: '1.5M',
      buy: 'Yes',
      sell: 'Yes'
    },
    timeline: {
      date: '2024-02-01T14:00:00',
      time: '2:00 PM',
      intent: 'buying',
      urgency: 'immediate'
    },
    activity: {
      days: 0,
      calls: 6,
      emails: { total: 9, unread: 2 },
      messages: { total: 7, unread: 3 },
      lastContact: {
        date: '2024-01-15T17:30:00',
        method: 'call'
      }
    },
    tasks: {
      completed: 4,
      total: 5,
      nextTask: {
        type: 'showing',
        dueDate: '2024-01-16T11:00:00',
        description: 'Virtual tour of 456 Park Ave',
        priority: 'high'
      }
    },
    assigned: {
      name: 'Emma Taylor',
      completed: 13
    },
    leadType: 'Move-Up Buyer',
    leadScore: 90,
    propertyPreferences: {
      type: 'Luxury Condo',
      bedrooms: 3,
      bathrooms: 3.5,
      squareFootage: '2800-3200'
    },
    registrationDate: '2024-01-14T16:20:00',
    tags: ['MUB', 'LUX', 'HOT']
  }
];