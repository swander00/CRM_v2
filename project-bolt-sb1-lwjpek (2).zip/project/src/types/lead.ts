export interface Lead {
  id: number;
  name: string;
  email: string;
  phone: string;
  status: string;
  pipelineStatus: string;
  source: {
    url: string;
    type: string;
    location: string;
  };
  price: {
    minBuy: string;
    maxBuy: string;
    buy: string;
    sell: string;
  };
  timeline: {
    date: string;
    time: string;
    intent: 'buying' | 'selling';
    urgency: 'immediate' | '1-3 months' | '3-6 months' | '6+ months';
  };
  activity: {
    days: number;
    calls: number;
    emails: { total: number; unread: number };
    messages: { total: number; unread: number };
    lastContact: {
      date: string;
      method: 'call' | 'email' | 'sms';
    };
  };
  tasks: {
    completed: number;
    total: number;
    nextTask?: {
      type: string;
      dueDate: string;
      description: string;
      priority: 'high' | 'medium' | 'low';
    };
  };
  assigned: {
    name: string;
    completed: number;
    avatar?: string;
  };
  leadType: string;
  leadScore: number;
  propertyPreferences: {
    type: string;
    bedrooms: number;
    bathrooms: number;
    squareFootage: string;
    lotSize?: string;
  };
  registrationDate: string;
  tags: string[];
}