import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { ThemeProvider } from './contexts/ThemeContext';
import { LeadProvider } from './contexts/LeadContext';
import MainLayout from './components/layout/MainLayout';
import Dashboard from './pages/Dashboard';
import Revenue from './pages/Revenue';
import Contacts from './pages/Contacts';
import Pipeline from './pages/Pipeline';
import Tasks from './pages/Tasks';
import Calendar from './pages/Calendar';
import Communications from './pages/Communications';
import Properties from './pages/Properties';
import PropertyDetails from './pages/PropertyDetails';
import Analytics from './pages/Analytics';
import Marketing from './pages/Marketing';
import Documents from './pages/Documents';
import Deals from './pages/Deals';
import Settings from './pages/Settings';
import LeadProfile from './pages/LeadProfile';
import LeadManagement from './pages/LeadManagement';
import DripCampaignBuilder from './pages/DripCampaignBuilder';
import EmailCampaignBuilder from './pages/EmailCampaignBuilder';
import SMSCampaignBuilder from './pages/SMSCampaignBuilder';
import SocialCampaignBuilder from './pages/SocialCampaignBuilder';
import EmailTemplates from './pages/templates/EmailTemplates';
import SMSTemplates from './pages/templates/SMSTemplates';
import Integrations from './pages/Integrations';
import Marketplace from './pages/Marketplace';
import DripCampaignHistory from './pages/campaigns/DripCampaignHistory';
import EmailCampaignHistory from './pages/campaigns/EmailCampaignHistory';
import SMSCampaignHistory from './pages/campaigns/SMSCampaignHistory';
import SocialCampaignHistory from './pages/campaigns/SocialCampaignHistory';
import TeamManagement from './pages/settings/TeamManagement';
import BillingPlans from './pages/settings/BillingPlans';

export default function App() {
  return (
    <ThemeProvider>
      <LeadProvider>
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<MainLayout />}>
              <Route index element={<Dashboard />} />
              <Route path="revenue" element={<Revenue />} />
              <Route path="leads" element={<LeadManagement />} />
              <Route path="contacts" element={<Contacts />} />
              <Route path="pipeline" element={<Pipeline />} />
              <Route path="tasks" element={<Tasks />} />
              <Route path="calendar" element={<Calendar />} />
              <Route path="communications" element={<Communications />} />
              <Route path="properties" element={<Properties />} />
              <Route path="property/:id" element={<PropertyDetails />} />
              <Route path="analytics" element={<Analytics />} />
              <Route path="marketing" element={<Marketing />} />
              <Route path="marketplace" element={<Marketplace />} />
              <Route path="documents" element={<Documents />} />
              <Route path="deals" element={<Deals />} />
              <Route path="settings" element={<Settings />} />
              <Route path="settings/team" element={<TeamManagement />} />
              <Route path="settings/billing" element={<BillingPlans />} />
              <Route path="campaigns/drip" element={<DripCampaignBuilder />} />
              <Route path="campaigns/email" element={<EmailCampaignBuilder />} />
              <Route path="campaigns/sms" element={<SMSCampaignBuilder />} />
              <Route path="campaigns/social" element={<SocialCampaignBuilder />} />
              <Route path="campaigns/drip/history" element={<DripCampaignHistory />} />
              <Route path="campaigns/email/history" element={<EmailCampaignHistory />} />
              <Route path="campaigns/sms/history" element={<SMSCampaignHistory />} />
              <Route path="campaigns/social/history" element={<SocialCampaignHistory />} />
              <Route path="templates/email" element={<EmailTemplates />} />
              <Route path="templates/sms" element={<SMSTemplates />} />
              <Route path="integrations" element={<Integrations />} />
            </Route>
            <Route path="/lead/:id" element={<LeadProfile />} />
          </Routes>
        </BrowserRouter>
      </LeadProvider>
    </ThemeProvider>
  );
}