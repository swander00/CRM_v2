/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        dark: {
          50: '#f7f7f7',
          100: '#e3e3e3',
          200: '#c8c8c8',
          300: '#a4a4a4',
          400: '#818181',
          500: '#666666',
          600: '#515151',
          700: '#434343',
          800: '#383838',
          900: '#121212',
          950: '#0a0a0a',
        },
        primary: {
          50: '#f0f9ff',
          100: '#e0f2fe',
          200: '#bae6fd',
          300: '#7dd3fc',
          400: '#38bdf8',
          500: '#1563df',
          600: '#0c4da3',
          700: '#0369a1',
          800: '#075985',
          900: '#0c4a6e',
        }
      },
      boxShadow: {
        'glow-sm': '0 0 10px -1px rgba(21, 99, 223, 0.3)',
        'glow': '0 0 15px -2px rgba(21, 99, 223, 0.4)',
        'glow-lg': '0 0 20px -3px rgba(21, 99, 223, 0.5)',
        'dark-glow-sm': '0 0 10px -1px rgba(21, 99, 223, 0.2)',
        'dark-glow': '0 0 15px -2px rgba(21, 99, 223, 0.3)',
        'dark-glow-lg': '0 0 20px -3px rgba(21, 99, 223, 0.4)',
        'dark-lg': '0 10px 15px -3px rgba(0, 0, 0, 0.4), 0 4px 6px -2px rgba(0, 0, 0, 0.2)',
        'dark-xl': '0 20px 25px -5px rgba(0, 0, 0, 0.4), 0 10px 10px -5px rgba(0, 0, 0, 0.2)',
      },
      backgroundColor: {
        'dark-overlay': 'rgba(0, 0, 0, 0.7)',
      }
    },
  },
  plugins: [],
};